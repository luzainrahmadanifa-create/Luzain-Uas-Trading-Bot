// Jalankan satu siklus bot secara lokal (dry run) memakai handler Vercel.
// Berguna untuk uji koneksi & menghasilkan log sebelum/selama forward test.
//   node scripts/local_tick.mjs
// State & log ditulis ke ./logs/local
import path from 'node:path';
import handler from '../api/tick.js';

process.env.CRON_SECRET = process.env.CRON_SECRET || 'local-dev-secret';
process.env.LOCAL_STORE_DIR = process.env.LOCAL_STORE_DIR || './logs/local';

function mockRes() {
  const out = { statusCode: 200, body: null };
  return {
    status(code) { out.statusCode = code; return this; },
    json(obj) { out.body = obj; return out; },
    _out: out
  };
}

const req = {
  method: 'GET',
  headers: { authorization: `Bearer ${process.env.CRON_SECRET}` },
  query: { secret: process.env.CRON_SECRET }
};

const res = mockRes();
await handler(req, res);
console.log(JSON.stringify(res._out.body, null, 2));
console.log('\nState:', path.resolve(process.env.LOCAL_STORE_DIR, 'state.json'));
