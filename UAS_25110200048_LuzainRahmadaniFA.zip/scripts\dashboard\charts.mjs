// Pembuat grafik SVG statis (tanpa library). Dipakai build_dashboard.mjs.
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

export function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function fmtDateShort(ms) {
  const d = new Date(ms + 7 * 3600 * 1000); // WIB
  return MONTHS[d.getUTCMonth()] + ' ' + String(d.getUTCFullYear()).slice(2);
}

function pathFrom(points, px, py) {
  return points.map((p, i) => (i ? 'L' : 'M') + px(p[0]).toFixed(1) + ' ' + py(p[1]).toFixed(1)).join(' ');
}

/**
 * Grafik garis multi-seri.
 * @param {object} o
 * @param {{name:string,color:string,points:[number,number][],dash?:boolean}[]} o.series
 */
export function lineChart(o) {
  const w = o.width || 980;
  const h = o.height || 340;
  const padL = o.padL || 62;
  const padR = o.padR || 20;
  const padT = o.padT || 16;
  const padB = o.padB || 34;
  const yTicks = o.yTicks || 5;
  const xTicks = o.xTicks || 6;
  const series = o.series || [];
  const all = series.flatMap((s) => s.points);
  if (!all.length) return '<p class="note">Tidak ada data.</p>';

  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const [x, y] of all) {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  }
  if (minX === maxX) maxX = minX + 1;
  if (minY === maxY) { minY -= 1; maxY += 1; }
  if (o.forceMin !== undefined) minY = o.forceMin;
  if (o.forceMax !== undefined) maxY = o.forceMax;
  if (o.forceMin === undefined) minY -= (maxY - minY) * 0.07;
  if (o.forceMax === undefined) maxY += (maxY - minY) * 0.07;

  const px = (t) => padL + ((t - minX) / (maxX - minX)) * (w - padL - padR);
  const py = (v) => padT + (1 - (v - minY) / (maxY - minY)) * (h - padT - padB);
  const yFmt = o.yFmt || ((v) => String(Math.round(v)));

  let grid = '';
  for (let i = 0; i <= yTicks; i++) {
    const v = minY + (i / yTicks) * (maxY - minY);
    const y = py(v);
    grid += '<line class="grid-line" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + (w - padR) + '" y2="' + y.toFixed(1) + '"/>';
    grid += '<text x="' + (padL - 8) + '" y="' + (y + 3.5).toFixed(1) + '" text-anchor="end">' + esc(yFmt(v)) + '</text>';
  }
  let xAxis = '';
  for (let i = 0; i <= xTicks; i++) {
    const t = minX + (i / xTicks) * (maxX - minX);
    const x = px(t);
    xAxis += '<text x="' + x.toFixed(1) + '" y="' + (h - padB + 16) + '" text-anchor="middle">' + esc(fmtDateShort(t)) + '</text>';
  }
  if (o.baseline !== undefined) {
    const y = py(o.baseline);
    xAxis += '<line class="axis" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + (w - padR) + '" y2="' + y.toFixed(1) + '" stroke-dasharray="4 4"/>';
  }

  let body = grid + xAxis;
  series.forEach((s, idx) => {
    if (!s.points.length) return;
    if (o.fillFirst && idx === 0) {
      const base = o.baseline !== undefined ? o.baseline : minY;
      const d = pathFrom(s.points, px, py) +
        ' L' + px(s.points[s.points.length - 1][0]).toFixed(1) + ' ' + py(base).toFixed(1) +
        ' L' + px(s.points[0][0]).toFixed(1) + ' ' + py(base).toFixed(1) + ' Z';
      body += '<path d="' + d + '" fill="' + s.color + '" opacity="0.10"/>';
    }
    body += '<path d="' + pathFrom(s.points, px, py) + '" fill="none" stroke="' + s.color +
      '" stroke-width="' + (s.width || 1.8) + '"' + (s.dash ? ' stroke-dasharray="5 4"' : '') +
      ' stroke-linejoin="round" stroke-linecap="round"/>';
  });

  return '<svg class="chart" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(o.label || 'grafik') + '">' + body + '</svg>';
}

/** Histogram batang vertikal. bars: [{label,count,positive}] */
export function histogram(o) {
  const w = o.width || 980;
  const h = o.height || 250;
  const padL = 46, padR = 16, padT = 16, padB = 44;
  const bars = o.bars || [];
  const max = Math.max(1, ...bars.map((b) => b.count));
  const bw = (w - padL - padR) / bars.length;
  let out = '';
  for (let i = 0; i <= 4; i++) {
    const v = (i / 4) * max;
    const y = padT + (1 - v / max) * (h - padT - padB);
    out += '<line class="grid-line" x1="' + padL + '" y1="' + y.toFixed(1) + '" x2="' + (w - padR) + '" y2="' + y.toFixed(1) + '"/>';
    out += '<text x="' + (padL - 8) + '" y="' + (y + 3.5).toFixed(1) + '" text-anchor="end">' + Math.round(v) + '</text>';
  }
  bars.forEach((b, i) => {
    const x = padL + i * bw + bw * 0.12;
    const barW = bw * 0.76;
    const bh = (b.count / max) * (h - padT - padB);
    const y = h - padB - bh;
    out += '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + barW.toFixed(1) + '" height="' + Math.max(0, bh).toFixed(1) +
      '" rx="3" fill="' + (b.positive ? '#22c55e' : '#ef4444') + '" opacity="0.75"/>';
    if (b.count > 0) {
      out += '<text x="' + (x + barW / 2).toFixed(1) + '" y="' + (y - 4).toFixed(1) + '" text-anchor="middle">' + b.count + '</text>';
    }
    out += '<text x="' + (x + barW / 2).toFixed(1) + '" y="' + (h - padB + 15) + '" text-anchor="middle" style="font-size:9.5px">' + esc(b.label) + '</text>';
  });
  out += '<text x="' + (w / 2) + '" y="' + (h - 8) + '" text-anchor="middle" style="font-size:10px">' + esc(o.xLabel || '') + '</text>';
  return '<svg class="chart" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(o.label || 'histogram') + '">' + out + '</svg>';
}

/** Warna sel heatmap berdasarkan return %. */
export function heatColor(v) {
  if (v === null || v === undefined || !isFinite(v)) return 'background:#0b1526;color:#475569';
  const a = Math.min(1, Math.abs(v) / 12);
  if (v >= 0) return 'background:rgba(34,197,94,' + (0.10 + 0.55 * a).toFixed(3) + ');color:#dcfce7';
  return 'background:rgba(239,68,68,' + (0.10 + 0.55 * a).toFixed(3) + ');color:#fee2e2';
}
