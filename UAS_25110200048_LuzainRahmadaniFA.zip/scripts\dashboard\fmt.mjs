// Format angka & tanggal (id-ID, WIB) untuk dashboard.
const nf0 = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 });
const nf2 = new Intl.NumberFormat('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

export function idr(n) {
  if (n === null || n === undefined || !isFinite(n)) return 'n/a';
  return 'Rp ' + nf0.format(Math.round(n));
}
export function idrShort(n) {
  if (n === null || n === undefined || !isFinite(n)) return 'n/a';
  const a = Math.abs(n);
  if (a >= 1e9) return 'Rp ' + nf2.format(n / 1e9) + ' M';
  if (a >= 1e6) return 'Rp ' + nf2.format(n / 1e6) + ' jt';
  if (a >= 1e3) return 'Rp ' + nf2.format(n / 1e3) + ' rb';
  return 'Rp ' + nf0.format(n);
}
export function pct(n, d = 2) {
  if (n === null || n === undefined || !isFinite(n)) return 'n/a';
  return (n >= 0 ? '+' : '') + Number(n).toFixed(d) + '%';
}
export function pctRaw(n, d = 2) {
  if (n === null || n === undefined || !isFinite(n)) return 'n/a';
  return Number(n).toFixed(d) + '%';
}
export function num(n, d = 0) {
  if (n === null || n === undefined || !isFinite(n)) return 'n/a';
  return Number(n).toFixed(d).replace('.', ',');
}
export function cls(n) { return n > 0 ? 'pos' : (n < 0 ? 'neg' : ''); }
export function dateWib(iso) {
  if (!iso) return '-';
  try {
    return new Date(iso).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    }).replace(/\./g, ':') + ' WIB';
  } catch { return iso; }
}
export function dateShortWib(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  const w = new Date(d.getTime() + 7 * 3600 * 1000);
  return w.getUTCDate() + ' ' + MONTHS[w.getUTCMonth()] + ' ' + w.getUTCFullYear();
}
export function timeWibOnly(iso) {
  try {
    return new Date(iso).toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit' }).replace(/\./g, ':');
  } catch { return iso; }
}
export function monthName(m) { return MONTHS[m - 1] || m; }
