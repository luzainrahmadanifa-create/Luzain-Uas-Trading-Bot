// Ukur median spread & slippage dari snapshot order book mentah.
// Slippage dihitung untuk ukuran order referensi (default Rp25.000.000).
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { CONFIG } from '../lib/config.js';
import { simulateBuy, simulateSell } from '../lib/execution.js';

const REF_NOTIONAL = Number(process.env.REF_NOTIONAL_IDR || 25_000_000);
const snapDir = path.resolve('data/snapshots');

function median(arr) {
  if (!arr.length) return null;
  const a = [...arr].sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

async function readAllSnapshots() {
  const files = (await fs.readdir(snapDir).catch(() => [])).filter((f) => f.endsWith('.jsonl'));
  const rows = [];
  for (const f of files) {
    const txt = await fs.readFile(path.join(snapDir, f), 'utf8');
    for (const line of txt.split('\n')) {
      if (!line.trim()) continue;
      try { rows.push(JSON.parse(line)); } catch { /* ignore */ }
    }
  }
  return rows;
}

async function main() {
  const rows = await readAllSnapshots();
  if (!rows.length) {
    throw new Error('Belum ada snapshot. Jalankan scripts/snapshot_orderbook.mjs minimal 3x sehari.');
  }

  const byPair = new Map();
  for (const r of rows) {
    if (!byPair.has(r.pair)) byPair.set(r.pair, []);
    byPair.get(r.pair).push(r);
  }

  const perPair = {};
  for (const u of CONFIG.universe) {
    const snaps = byPair.get(u.symbol) || [];
    const spreads = [];
    const buySlips = [];
    const sellSlips = [];
    for (const s of snaps) {
      const bids = (s.depth.buy || []).map(([p, q]) => ({ p: Number(p), q: Number(q) }));
      const asks = (s.depth.sell || []).map(([p, q]) => ({ p: Number(p), q: Number(q) }));
      const book = { bids, asks };
      spreads.push(s.spreadBps);
      const b = simulateBuy(book, REF_NOTIONAL);
      if (b.ok) buySlips.push(((b.avgPrice - s.bestAsk) / s.bestAsk) * 10000);
      // jual kuantitas setara notional referensi
      const qty = REF_NOTIONAL / s.bestBid;
      const sl = simulateSell(book, qty);
      if (sl.ok) sellSlips.push(((s.bestBid - sl.avgPrice) / s.bestBid) * 10000);
    }
    const spreadBps = median(spreads) ?? 10;
    const slipBuy = median(buySlips) ?? 0;
    const slipSell = median(sellSlips) ?? 0;
    perPair[u.symbol] = {
      pairId: u.pairId,
      snapshots: snaps.length,
      medianSpreadBps: Number(spreadBps.toFixed(3)),
      medianBuySlippageBps: Number(slipBuy.toFixed(3)),
      medianSellSlippageBps: Number(slipSell.toFixed(3)),
      // slippage dipakai konservatif: rata-rata dua sisi
      slippageBps: Number(((slipBuy + slipSell) / 2).toFixed(3)),
      firstSnapshot: snaps.length ? snaps.map(s=>s.ts).sort()[0] : null,
      lastSnapshot: snaps.length ? snaps.map(s=>s.ts).sort().slice(-1)[0] : null
    };
  }

  const out = {
    generatedAt: new Date().toISOString(),
    referenceOrderIdr: REF_NOTIONAL,
    method: 'Median spread (ask-bid)/mid dan slippage hasil menyapu level order book untuk order referensi. Slippage = selisih harga fill rata-rata terhadap best bid/ask.',
    source: 'https://indodax.com/api/depth/{pairId}',
    perPair
  };
  await fs.mkdir(path.resolve('data'), { recursive: true });
  await fs.writeFile(path.resolve('data/costs.json'), JSON.stringify(out, null, 2));

  console.log(`Order referensi: Rp${REF_NOTIONAL.toLocaleString('id-ID')}`);
  console.log('pair        snap  spread(bps)  slipBuy  slipSell');
  for (const [k, v] of Object.entries(perPair)) {
    console.log(`${k.padEnd(10)} ${String(v.snapshots).padStart(4)}  ${String(v.medianSpreadBps).padStart(10)}  ${String(v.medianBuySlippageBps).padStart(7)}  ${String(v.medianSellSlippageBps).padStart(8)}`);
  }
  console.log('\nDitulis ke data/costs.json');
}

main().catch((e) => { console.error(e); process.exit(1); });
