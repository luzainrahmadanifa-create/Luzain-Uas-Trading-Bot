// Pilih universe 3-10 pasangan IDR secara point-in-time.
// Likuiditas diukur pada AWAL periode backtest (30 hari sebelum 2023-11-07),
// bukan pada hari ini -> mengurangi survivorship bias.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { getCandles } from '../lib/indodax.js';

const FROM = Math.floor(Date.parse('2023-10-01T00:00:00Z') / 1000);
const TO = Math.floor(Date.parse('2023-11-07T00:00:00Z') / 1000);

// Kandidat: aset besar yang sudah terdaftar di Indodax sebelum November 2023.
const CANDIDATES = [
  'BTCIDR', 'ETHIDR', 'XRPIDR', 'SOLIDR', 'ADAIDR', 'DOGEIDR',
  'AVAXIDR', 'LINKIDR', 'BNBIDR', 'TONIDR', 'DOTIDR', 'TRXIDR',
  'MATICIDR', 'ATOMIDR', 'LTCIDR', 'BCHIDR'
];

const OUT_DIR = path.resolve('data');

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true });
  const rows = [];

  for (const symbol of CANDIDATES) {
    let candles = [];
    try {
      candles = await getCandles(symbol, '1D', FROM, TO);
    } catch (e) {
      rows.push({ symbol, ok: false, error: e.message });
      console.log(`- ${symbol}: gagal (${e.message})`);
      continue;
    }
    const valid = candles.filter((c) => c.c > 0 && c.v >= 0);
    // Jendela 30 hari yang berakhir tepat sebelum periode backtest dimulai.
    const measFrom = Math.floor(Date.parse('2023-10-01T00:00:00Z') / 1000);
    const measTo = Math.floor(Date.parse('2023-11-01T00:00:00Z') / 1000);
    const win = valid.filter((c) => c.t >= measFrom && c.t < measTo);
    const turnover = win.reduce((s, c) => s + c.c * c.v, 0);
    const days = win.length;
    const avgTurnover = days ? turnover / days : 0;
    const coverage = valid.length / 37;
    rows.push({
      symbol,
      ok: days >= 20,
      days,
      coverage: Number(coverage.toFixed(3)),
      turnover30d: Math.round(turnover),
      avgDailyTurnoverIdr: Math.round(avgTurnover),
      firstCandle: valid[0] ? new Date(valid[0].t * 1000).toISOString() : null,
      lastCandle: valid[valid.length - 1] ? new Date(valid[valid.length - 1].t * 1000).toISOString() : null
    });
    console.log(`- ${symbol}: ${days} hari, turnover 30d=Rp${Math.round(turnover).toLocaleString('id-ID')}`);
  }

  const eligible = rows
    .filter((r) => r.ok && r.coverage >= 0.9 && r.firstCandle && r.firstCandle <= '2023-10-05')
    .sort((a, b) => b.turnover30d - a.turnover30d)
    .slice(0, 5);

  const universe = eligible.map((r) => ({
    symbol: r.symbol,
    pairId: r.symbol.toLowerCase(),
    label: r.symbol.replace('IDR', '/IDR'),
    selection: {
      turnover30dIdr: r.turnover30d,
      avgDailyTurnoverIdr: r.avgDailyTurnoverIdr,
      measuredFrom: '2023-10-01',
      measuredTo: '2023-11-07'
    }
  }));

  await fs.writeFile(path.join(OUT_DIR, 'universe.json'), JSON.stringify({
    method: 'Peringkat turnover IDR 30 hari yang berakhir 2023-11-07 (point-in-time), kandidat aset besar yang sudah ada sebelum Nov 2023. 5 teratas.',
    cutoff: '2023-11-07',
    universe,
    allCandidates: rows
  }, null, 2));

  const csv = ['symbol,ok,days,coverage,turnover30d_idr,avg_daily_turnover_idr,first_candle,last_candle']
    .concat(rows.map((r) => [r.symbol, r.ok, r.days ?? '', r.coverage ?? '', r.turnover30d ?? '', r.avgDailyTurnoverIdr ?? '', r.firstCandle ?? '', r.lastCandle ?? ''].join(',')))
    .join('\n');
  await fs.writeFile(path.join(OUT_DIR, 'universe_selection.csv'), csv);

  console.log('\nUniverse terpilih:');
  for (const u of universe) console.log(`  ${u.symbol}  (turnover 30d Rp${u.selection.turnover30dIdr.toLocaleString('id-ID')})`);
  console.log('\nTempel ke lib/config.js:');
  console.log('  universe: [');
  for (const u of universe) console.log(`    { symbol: '${u.symbol}', pairId: '${u.pairId}', label: '${u.label}' },`);
  console.log('  ],');
}

main().catch((e) => { console.error(e); process.exit(1); });
