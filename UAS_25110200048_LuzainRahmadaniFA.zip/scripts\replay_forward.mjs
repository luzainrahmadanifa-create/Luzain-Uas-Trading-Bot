// Replay BACKTEST pada jendela forward test (bukan forward test live).
// Tujuannya: menyediakan pembanding candle-demi-candle untuk log sinyal bot.
//   node scripts/replay_forward.mjs --from 2026-11-05T04:00:00Z --to 2026-11-19T05:00:00Z
// Catatan: bar 4 jam pertama yang tertutup setelah freeze (5 Nov 12.00 WIB)
// adalah bar yang dibuka 04:00Z dan ditutup 08:00Z (15.00 WIB).
import { spawn } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';

function arg(name, fallback) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

const from = arg('from', '2026-11-05T04:00:00Z');
const to = arg('to', '2026-11-19T05:00:00Z');

const env = {
  ...process.env,
  BT_OUT: 'forward_replay',
  BT_OVERRIDES: JSON.stringify({ backtestStart: new Date(from).toISOString(), backtestEnd: new Date(to).toISOString() })
};

console.log(`Replay backtest jendela forward: ${from} .. ${to}`);
const child = spawn(process.execPath, ['scripts/backtest.mjs'], { stdio: 'inherit', env });
child.on('exit', async (code) => {
  if (code === 0) {
    const summaryPath = path.resolve('data/forward_replay/summary.json');
    const s = JSON.parse(await fs.readFile(summaryPath, 'utf8'));
    await fs.writeFile(path.resolve('data/forward_replay/NOTE.txt'),
      'Ini adalah REPLAY BACKTEST pada jendela forward test, bukan forward test live.\n' +
      'Dipakai sebagai pembanding sinyal candle-demi-candle terhadap log bot.\n' +
      'Jendela forward: 5 Nov 2026 12.00 WIB - 19 Nov 2026 12.00 WIB.\n' +
      `Periode data yang tersedia saat replay dijalankan: ${s.period.start} .. ${s.period.end}\n` +
      'Data setelah tanggal tersebut belum ada; jalankan ulang setelah 19 Nov untuk perbandingan penuh.\n');
    console.log(`\nSelesai. Periode data aktual: ${s.period.start} .. ${s.period.end}`);
  }
  process.exit(code);
});
