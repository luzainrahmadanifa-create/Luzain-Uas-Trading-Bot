// Bagian 6-7 dashboard: Aturan & Perubahan, Refleksi.
import { idr, idrShort, pct, pctRaw, num, dateWib } from './fmt.mjs';
import { esc } from './charts.mjs';

function card(title, sub, body, extra = '') {
  return '<div class="card ' + extra + '">' +
    '<div class="card-head"><h3>' + title + '</h3></div>' +
    (sub ? '<p class="sub">' + sub + '</p>' : '') + body + '</div>';
}

export function renderAturan(c) {
  const p = c.freeze.parameters || {};
  const paramRows = [
    ['Timeframe', p.timeframe === '240' ? '4 jam (tf=240)' : p.timeframe, 'Cukup trade untuk forward 14 hari; 1 jam ditolak karena fee drag.'],
    ['Universe', (p.universe || []).join(', '), '5 pasangan IDR likuid, dipilih point-in-time.'],
    ['EMA fast / slow / trend', p.emaFast + ' / ' + p.emaSlow + ' / ' + p.emaTrend, 'Golden cross 9/21 dengan filter tren EMA50.'],
    ['ATR period / multiplier', p.atrPeriod + ' / ' + p.atrMult, 'Trailing stop = close &minus; 3 &times; ATR14.'],
    ['Filter volatilitas', 'ATR/close &le; ' + num(p.maxAtrPct * 100, 0) + '%', 'Menghindari entry saat volatilitas ekstrem.'],
    ['Filter slope EMA50', p.trendSlopeBars + ' bar', 'EMA50 harus naik dibanding 6 bar lalu.'],
    ['Filter likuiditas', idr(p.minTurnover24hIdr) + ' / 24 jam', 'Turnover dari candle (close &times; volume), point-in-time.'],
    ['Modal awal', idr(p.startingEquityIdr), 'Virtual, tidak ada uang sungguhan.'],
    ['Maks posisi', p.maxPositions, 'Tidak pernah lebih dari 4 posisi terbuka.'],
    ['Ukuran per posisi', num(p.allocPctPerPosition * 100, 0) + '% ekuitas', 'Maksimum, dihitung dari ekuitas berjalan.'],
    ['Minimum order', idr(p.minOrderIdr), 'Lebih ketat dari minimum API Rp10.000.'],
    ['Fee taker per sisi', num(p.feeTakerPctPerSide, 2) + '%', 'Beli di ask, jual di bid.'],
    ['Daily loss limit', num(p.dailyLossLimitPct, 1) + '%', 'Diukur dari ekuitas anchor 00.00 WIB.'],
    ['Batas spread entry', num(p.maxSpreadPct, 1) + '%', 'Entry ditolak bila bid-ask terlalu lebar.'],
    ['Benchmark', 'BTC/IDR buy &amp; hold', 'Periode yang sama, fee 0,2% per sisi.']
  ].map((x) => '<tr><td><b>' + x[0] + '</b></td><td class="num mono">' + x[1] + '</td><td class="note">' + x[2] + '</td></tr>').join('');

  const changeRows = [
    ['Pasar', 'Saham BEI (Kompas100), data harian', 'Kripto IDR Indodax, candle 4 jam', 'Pasar 24/7, volatilitas lebih tinggi, fee lebih besar.'],
    ['Universe', '10 tahun, saham Kompas100', '5 pasangan IDR likuid', 'Dipilih point-in-time dari turnover 30 hari.'],
    ['Sinyal masuk', 'Golden cross EMA 9/21 + close &gt; EMA50', 'Sama, ditambah slope EMA50, filter ATR%, dan filter turnover', 'Mengurangi whipsaw dan entry di aset sepi.'],
    ['Sinyal keluar', 'Trailing stop ATR 3.0', 'Trailing stop ATR 3.0 ATAU death cross EMA 9/21', 'Exit lebih cepat saat momentum berbalik.'],
    ['Sizing', 'Alokasi per saham', 'Maks 4 posisi &times; 15% ekuitas', 'Kontrol eksposur portofolio kripto.'],
    ['Biaya', 'Fee beli 0,15%, jual 0,25% + spread 1 tick', 'Fee taker 0,2%/sisi + spread &amp; slippage terukur', 'Fee kripto jauh lebih besar; diukur dari order book.'],
    ['Eksekusi', 'Backtest saham', 'Bot dry run di Vercel, fill dari bid/ask live', 'Latensi, cron, dan ketersediaan API harus ditangani.'],
    ['Risk', 'Trailing stop per posisi', '+ daily loss limit 3% WIB, kill switch, retry, idempotency', 'Wajib sesuai PDF.'],
    ['Otomasi', 'Tidak ada', 'Endpoint /api/tick + GitHub Actions tiap jam', 'Fungsi Vercel tidak berjalan terus-menerus.']
  ].map((x) => '<tr><td><b>' + x[0] + '</b></td><td>' + x[1] + '</td><td>' + x[2] + '</td><td class="note">' + x[3] + '</td></tr>').join('');

  const fileRows = (c.freeze.files || []).map((f) =>
    '<tr><td class="mono">' + f.file + '</td><td class="num">' + num(f.bytes) + '</td><td class="hash">' + f.sha256 + '</td></tr>').join('');

  return '' +
    '<section class="tab-panel" id="panel-aturan" data-panel="aturan">' +
    '<div class="banner ok"><div><h3>Aturan beku — tidak boleh berubah selama forward test</h3>' +
    '<p>Freeze date: <b>' + dateWib(c.frozenAt) + '</b>. Perubahan parameter setelah titik ini akan menggugurkan komponen kecocokan. Bug fix yang tidak mengubah aturan dicatat terpisah.</p></div>' +
    '<div class="big">v' + c.version + '</div></div>' +

    '<h2 class="section-title">Parameter lengkap <small>sumber tunggal: lib/config.js</small></h2>' +
    '<div class="card"><div class="table-wrap"><table><thead><tr><th>Parameter</th><th class="num">Nilai</th><th>Alasan / catatan</th></tr></thead><tbody>' + paramRows + '</tbody></table></div></div>' +

    '<div class="grid g2 mt24">' +
    card('Aturan masuk (entry)',
      'Semua kondisi harus benar pada candle tertutup yang sama.',
      '<ol class="rule-list">' +
      '<li><b>Golden cross:</b> EMA9 memotong ke atas EMA21 pada candle tertutup.</li>' +
      '<li><b>Tren:</b> close &gt; EMA50.</li>' +
      '<li><b>Slope:</b> EMA50 sekarang &gt; EMA50 ' + p.trendSlopeBars + ' bar lalu.</li>' +
      '<li><b>Volatilitas:</b> ATR14 / close &le; ' + num(p.maxAtrPct * 100, 0) + '%.</li>' +
      '<li><b>Likuiditas:</b> turnover 24 jam &ge; ' + idrShort(p.minTurnover24hIdr) + '.</li>' +
      '<li><b>Risiko:</b> posisi &lt; ' + p.maxPositions + ', tidak kena daily loss limit, kill switch mati, spread &le; ' + num(p.maxSpreadPct * 100, 0) + '%.</li>' +
      '<li><b>Order:</b> beli di ask, ukuran = 15% ekuitas berjalan (min Rp25.000), menyapu level book.</li>' +
      '</ol>') +
    card('Aturan keluar (exit)',
      'Dievaluasi pada setiap candle tertutup untuk posisi yang terbuka.',
      '<ol class="rule-list">' +
      '<li><b>Trailing stop:</b> stop awal = fill &minus; 3 &times; ATR14. Stop hanya naik (ratchet), tidak pernah turun.</li>' +
      '<li><b>Stop hit:</b> close &lt; stop &rarr; jual di bid pada candle berikutnya.</li>' +
      '<li><b>Death cross:</b> EMA9 memotong ke bawah EMA21 &rarr; jual.</li>' +
      '<li><b>Eksekusi:</b> jual menyapu level bid; fee taker 0,2%.</li>' +
      '<li><b>Tidak ada short.</b> Setelah keluar, posisi menjadi kas sampai sinyal entry berikutnya.</li>' +
      '</ol>') +
    '</div>' +

    '<h2 class="section-title">Risk management <small>wajib di kode, terlihat di log</small></h2>' +
    '<div class="card"><div class="table-wrap"><table><thead><tr><th>Kontrol</th><th>Implementasi</th><th>Bukti / log</th></tr></thead><tbody>' +
    '<tr><td><b>Batas posisi</b></td><td>Maks ' + p.maxPositions + ' posisi; entry ditolak bila penuh.</td><td><span class="mono">entry_blocked</span> di respons + <span class="mono">calls.jsonl</span></td></tr>' +
    '<tr><td><b>Batas ukuran</b></td><td>15% ekuitas berjalan per posisi; tidak ada leverage.</td><td>notional order di <span class="mono">orders.jsonl</span></td></tr>' +
    '<tr><td><b>Daily loss limit</b></td><td>3% dari ekuitas anchor 00.00 WIB. Bila terlampaui, tidak ada entry sampai hari berikutnya.</td><td><span class="mono">dailyLossTripped</span> di state + <span class="mono">calls.jsonl</span></td></tr>' +
    '<tr><td><b>Kill switch</b></td><td>Env <span class="mono">KILL_SWITCH=1</span> atau state <span class="mono">killSwitch</span> via POST <span class="mono">/api/admin</span> (tanpa deploy ulang).</td><td><span class="mono">killswitch.jsonl</span> + flag di setiap call</td></tr>' +
    '<tr><td><b>Retry terbatas</b></td><td>3 percobaan, backoff eksponensial, timeout 12 detik. Error 4xx tidak di-retry.</td><td><span class="mono">errors.jsonl</span></td></tr>' +
    '<tr><td><b>Idempotency</b></td><td><span class="mono">lastCandle[pair]</span>; candle yang sama tidak diproses dua kali.</td><td><span class="mono">signals.jsonl</span> (<span class="mono">newCandle:false</span>)</td></tr>' +
    '<tr><td><b>Validasi data</b></td><td>Buang candle berjalan; tolak data basi &gt; 2&times; tf, gap, duplikat, harga/volume nol, book kosong, spread &gt; 2%.</td><td><span class="mono">issues</span> di log sinyal</td></tr>' +
    '</tbody></table></div></div>' +

    '<h2 class="section-title">Perubahan dari strategi UTS <small>saham harian &rarr; kripto 4 jam</small></h2>' +
    '<div class="card"><div class="table-wrap"><table><thead><tr><th>Aspek</th><th>UTS</th><th>UAS</th><th>Alasan</th></tr></thead><tbody>' + changeRows + '</tbody></table></div>' +
    '<p class="note tiny mt8">Inti strategi tetap: trend following golden cross + trailing stop ATR. Yang berubah adalah pasar, timeframe, filter, sizing, biaya, dan otomasi.</p></div>' +

    '<h2 class="section-title">Arsitektur &amp; keamanan <small>satu endpoint tick, state persisten, secret di env</small></h2>' +
    '<div class="grid g2">' +
    card('Alur &amp; file',
      'Fungsi Vercel tidak berjalan terus-menerus; semua kerja terjadi di dalam satu panggilan.',
      '<div class="table-wrap"><table><thead><tr><th>File</th><th>Peran</th></tr></thead><tbody>' +
      '<tr><td class="mono">api/tick.js</td><td>Ambil data &rarr; validasi &rarr; sinyal &rarr; risk &rarr; order simulasi &rarr; simpan state/log.</td></tr>' +
      '<tr><td class="mono">api/admin.js</td><td>Kill switch manual tanpa deploy ulang (butuh CRON_SECRET).</td></tr>' +
      '<tr><td class="mono">api/dashboard.js</td><td>Halaman dashboard server-rendered untuk Vercel.</td></tr>' +
      '<tr><td class="mono">lib/strategy.js</td><td>Fungsi sinyal yang sama untuk bot dan backtest.</td></tr>' +
      '<tr><td class="mono">lib/execution.js</td><td>Fill order book + model biaya backtest.</td></tr>' +
      '<tr><td class="mono">lib/risk.js</td><td>Daily loss, batas posisi, kill switch, sizing.</td></tr>' +
      '<tr><td class="mono">lib/store.js</td><td>Upstash Redis (produksi) / filesystem (lokal).</td></tr>' +
      '<tr><td class="mono">scripts/hitung_ulang.mjs</td><td>Hitung ulang semua angka dari log mentah.</td></tr>' +
      '</tbody></table></div>') +
    card('Keamanan',
      'Tidak ada secret di repositori atau dashboard.',
      '<ul class="rule-list">' +
      '<li><span class="mono">CRON_SECRET</span> wajib untuk <span class="mono">/api/tick</span> dan <span class="mono">/api/admin</span> (header <span class="mono">Authorization: Bearer ...</span>).</li>' +
      '<li>Tanpa secret yang benar &rarr; HTTP 401; bot tidak jalan.</li>' +
      '<li><span class="mono">.env</span> masuk <span class="mono">.gitignore</span>; yang dikumpulkan hanya <span class="mono">.env.example</span> tanpa nilai rahasia.</li>' +
      '<li>Log tidak menulis token, URL Redis, atau isi environment.</li>' +
      '<li>Dashboard publik hanya membaca state/log; tidak menerima perintah.</li>' +
      '<li>Kill switch bisa dinyalakan lewat state tanpa deploy ulang; setiap penggunaan dicatat.</li>' +
      '</ul>') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Deploy ke Vercel (belum dilakukan)',
      'Status saat file ini dibuat: kode siap, belum ada akun/kredensial Vercel di mesin penyusunan.',
      '<ol class="rule-list">' +
      '<li>Buat Redis di Vercel Marketplace (Upstash) atau Upstash Console; salin REST URL + token.</li>' +
      '<li><span class="mono">vercel link</span> lalu set environment variable: <span class="mono">CRON_SECRET</span>, <span class="mono">UPSTASH_REDIS_REST_URL</span>, <span class="mono">UPSTASH_REDIS_REST_TOKEN</span>, <span class="mono">KILL_SWITCH=0</span>.</li>' +
      '<li><span class="mono">vercel --prod</span>; uji <span class="mono">/api/tick</span> dengan header secret.</li>' +
      '<li>Set GitHub Actions secrets <span class="mono">VERCEL_URL</span> dan <span class="mono">CRON_SECRET</span>; aktifkan workflow tiap jam.</li>' +
      '<li>Catat URL Vercel + commit hash di README setelah deploy.</li>' +
      '<li>Biarkan sampai 19 Nov 12.00 WIB tanpa mengubah aturan.</li>' +
      '</ol>' +
      '<div class="code-box mt8">vercel env add CRON_SECRET production\nvercel env add UPSTASH_REDIS_REST_URL production\nvercel env add UPSTASH_REDIS_REST_TOKEN production\nvercel --prod</div>' +
      '<button class="btn mt8" data-copy="vercel --prod" type="button">Salin</button>') +
    card('Kill switch &amp; operasi',
      'Bisa dinyalakan tanpa deploy ulang.',
      '<div class="code-box"># aktifkan\ncurl -X POST https://&lt;project&gt;.vercel.app/api/admin \\\n  -H "Authorization: Bearer $CRON_SECRET" \\\n  -H "Content-Type: application/json" \\\n  -d \'{"killSwitch":true}\'\n\n# cek status\ncurl -H "Authorization: Bearer $CRON_SECRET" \\\n  https://&lt;project&gt;.vercel.app/api/admin</div>' +
      '<p class="note tiny mt8">Env <span class="mono">KILL_SWITCH=1</span> juga berfungsi, tetapi mengubah env Vercel memerlukan redeploy. Karena itu state flag disediakan.</p>') +
    '</div>' +

    '<h2 class="section-title">Bukti freeze <small>hash file + catatan commit</small></h2>' +
    '<div class="card">' +
    '<div class="table-wrap"><table><thead><tr><th>File</th><th class="num">Byte</th><th>SHA-256</th></tr></thead><tbody>' + fileRows + '</tbody></table></div>' +
    '<p class="note tiny mt8">Commit git: ' + (c.freeze.git && c.freeze.git.commit ? '<span class="mono">' + c.freeze.git.commit + '</span>' : '<b>belum tersedia</b> — git tidak terpasang di mesin penyusunan. Setelah repo dibuat, jalankan <span class="mono">git rev-parse HEAD</span> dan isi ke data/freeze.json + README.') + '</p>' +
    '<p class="note tiny mt8">' + esc(c.freeze.integrityNote || '') + '</p>' +
    '</div>' +

    '<div class="card mt16">' +
    '<div class="card-head"><h3>Struktur deliverable ZIP</h3></div>' +
    '<div class="code-box">UAS_25110200048_LuzainRahmadaniFA.zip\n├─ README.md                  # cara jalan, deploy, link\n├─ strategy.md                # aturan lengkap + perubahan dari UTS\n├─ package.json\n├─ vercel.json\n├─ .env.example               # tanpa secret\n├─ api/                       # tick.js, dashboard.js, admin.js\n├─ lib/                       # config, strategy, execution, risk, store, metrics\n├─ scripts/                   # fetch, backtest, replay, hitung_ulang, dashboard, variants\n├─ data/\n│  ├─ freeze.json             # hash + waktu freeze\n│  ├─ universe.json           # audit pemilihan universe\n│  ├─ costs.json              # spread & slippage terukur\n│  ├─ instruments.json        # fee & minimum order\n│  ├─ backtest/               # summary.json, trades.csv, equity_daily.csv, benchmark, signals\n│  ├─ forward_replay/         # replay jendela forward (pembanding)\n│  ├─ variants.json           # uji ketahanan parameter\n│  └─ candles/                # candle mentah 4 jam\n├─ logs/\n│  ├─ local/                  # log uji lokal (bukan produksi)\n│  └─ export/                 # log produksi setelah diekspor\n└─ dashboard/\n   └─ UAS_25110200048_LuzainRahmadaniFA.html   # offline, mandiri\n</div>' +
    '</div>' +
    '</section>';
}

export function renderRefleksi(c) {
  const bt = c.bt;
  const x = c.extra;

  return '' +
    '<section class="tab-panel" id="panel-refleksi" data-panel="refleksi">' +
    '<div class="card">' +
    '<h2 style="margin-top:0">Refleksi: apa yang berhasil, apa yang tidak, dan mengapa</h2>' +
    '<p class="note">Ditulis berdasarkan angka di dashboard ini. Tidak ada klaim return masa depan.</p>' +

    '<div class="archive"><h4>1. Strategi yang sama, pasar yang berbeda</h4>' +
    '<p>Di UTS, golden cross EMA 9/21 + trailing stop ATR 3.0 diuji pada saham Kompas100 harian. Untuk UAS, inti itu dipindahkan ke kripto IDR 4 jam. Yang paling terasa berbeda bukan sinyalnya, tetapi <b>biaya</b>: fee taker 0,2% per sisi berarti bolak-balik 0,4% sebelum spread. Pada timeframe 1 jam, strategi menghasilkan <b>&minus;74,18%</b> dengan 2.359 trade; biaya memakan hampir seluruh edge. Di 4 jam, dengan filter slope EMA50 dan maksimum 4 posisi &times; 15%, hasilnya <b>' + pct(bt.totalReturnPct) + '</b> dengan ' + num(bt.trades) + ' trade. Pelajarannya: frekuensi harus disesuaikan dengan biaya, bukan sebaliknya.</p></div>' +

    '<div class="archive"><h4>2. Return kalah dari BTC, tetapi risiko lebih kecil</h4>' +
    '<p>BTC/IDR beli-dan-tahan pada periode yang sama menghasilkan <b>' + pct(c.bench.returnPct) + '</b> dengan MDD <b>' + pct(c.bench.mddPct) + '</b>. Strategi hanya <b>' + pct(bt.totalReturnPct) + '</b> (CAGR ' + pct(bt.cagrPct) + ') dengan MDD <b>' + pct(bt.mddPct) + '</b>. Jadi secara return, strategi ini <b>tidak mengalahkan</b> benchmark. Saya tidak akan membingkai ini sebagai kemenangan. Yang bisa diklaim: drawdown jauh lebih dangkal, eksposur maksimum 60% (4 &times; 15%), dan tidak pernah memakai leverage. Untuk investor yang tidak tahan melihat portofolio turun 49%, profil ini punya alasan; untuk yang mengejar return maksimum, BTC buy-and-hold lebih baik pada periode ini.</p></div>' +

    '<div class="archive"><h4>3. Win rate rendah bukan otomatis buruk</h4>' +
    '<p>Win rate hanya <b>' + pctRaw(bt.winRate) + '</b>, tetapi profit factor <b>' + num(bt.profitFactor, 2) + '</b>. Rata-rata trade menang <b>+' + num(bt.avgWinPct, 2) + '%</b> dan rata-rata rugi <b>' + num(bt.avgLossPct, 2) + '%</b>, sehingga payoff <b>' + num(x.payoff, 2) + 'x</b>. Trailing stop memotong kerugian cepat; sebagian kecil tren besar membayar semuanya. Konsekuensinya, secara psikologis strategi ini tidak nyaman: lebih dari 7 dari 10 trade rugi, dan pernah <b>' + num(bt.maxConsecutiveLosses) + ' kali</b> rugi beruntun. Itu bukan bug, melainkan karakter distribusinya.</p></div>' +

    '<div class="archive"><h4>4. Biaya adalah musuh utama</h4>' +
    '<p>Total biaya <b>' + idrShort(bt.totalCostsIdr) + '</b> atau <b>' + pctRaw(bt.costSharePct) + '</b> dari laba kotor. Fee menyumbang ' + idrShort(bt.feesIdr) + ', spread + slippage ' + idrShort(bt.spreadSlipIdr) + '. Artinya dari setiap rupiah laba kotor, sekitar ' + num(bt.costSharePct, 0) + ' sen kembali ke pasar. Kalau fee turun atau eksekusi memakai maker order, angka ini bisa membaik; tetapi aturan beku memakai taker karena bot membeli di ask dan menjual di bid sesuai PDF.</p></div>' +

    '<div class="archive"><h4>5. Forward test belum selesai — dan itu ditulis apa adanya</h4>' +
    '<p>Jendela forward test adalah 5–19 Nov 2026 12.00 WIB. Dashboard ini dibuat <b>' + dateWib(c.generatedAt) + '</b>, jadi baru <b>' + num(c.forwardProgress.daysElapsed, 1) + ' dari 14 hari</b>. Bot juga <b>belum di-deploy</b> karena mesin penyusunan tidak punya akun/kredensial Vercel. Log yang ada berasal dari uji lokal: ' + num(c.fwd.calls) + ' panggilan, ' + num(c.fwd.trades) + ' trade, return 0,00%. Replay backtest pada jendela yang sama juga 0 trade dalam 12 candle yang tersedia. Gap saat ini <b>0,00 pp</b>, tetapi itu bukan bukti kecocokan; itu hanya karena keduanya belum bergerak. Saya sengaja tidak mengisi angka forward dengan hasil karangan. Sesuai rubrik, hasil buruk yang bisa dibuktikan lebih bernilai daripada hasil bagus yang tidak bisa dipertanggungjawabkan.</p></div>' +

    '<div class="archive"><h4>6. Kecocokan sinyal: apa yang sudah terbukti</h4>' +
    '<p>Dari ' + num(c.match ? c.match.compared : 0) + ' pair-candle yang bisa dibandingkan, <b>' + num(c.match ? c.match.matched : 0) + '</b> cocok (<b>' + pctRaw(c.match ? c.match.matchRatePct : null, 1) + '</b>). Cakupannya baru ' + pctRaw(c.match ? c.match.coveragePct : null, 1) + ' karena bot hanya punya satu tick (5 pair &times; 1 candle), sedangkan replay punya 12 candle &times; 5 pair. Setelah bot berjalan penuh, target rubrik 100% kecocokan candle-demi-candle bisa diuji dengan pembanding yang setara.</p></div>' +

    '<div class="archive"><h4>7. Keterbatasan yang saya akui</h4>' +
    '<p>(a) Pemilihan parameter memakai data in-sample 2023–2026; belum ada out-of-sample murni. Backtest final sudah dipotong sebelum freeze date, tetapi eksplorasi varian tetap melihat data hingga 7 Nov. (b) Snapshot order book baru satu hari, tiga putaran; spread/slippage bisa berbeda pada jam sepi atau saat volatil. (c) Eksekusi dry run mengasumsikan fill langsung pada level book; partial fill dan antrean order tidak dimodelkan. (d) Data candle diambil dari API publik; kualitasnya sudah divalidasi (0 gap, 0 duplikat), tetapi bukan rekaman tick. (e) Bot belum di-deploy sehingga belum ada bukti uptime produksi.</p></div>' +

    '<div class="archive"><h4>8. Langkah berikutnya (setelah 19 Nov)</h4>' +
    '<p>Deploy, ekspor log produksi, jalankan ulang replay dengan data 14 hari penuh, lalu bandingkan return, MDD, jumlah trade, dan harga fill per trade. Selisih return akan didekomposisi menjadi: (i) perbedaan sinyal (target 0), (ii) perbedaan harga fill karena spread/slippage, (iii) keterlambatan cron sehingga entry terjadi di bar yang berbeda, dan (iv) downtime/error API. Tanpa dekomposisi itu, klaim apa pun tentang penyebab selisih tidak sah.</p></div>' +

    '<div class="card tight mt16" style="border-color:rgba(34,211,238,.35);background:rgba(34,211,238,.05)">' +
    '<h4 style="margin:0 0 4px">Pernyataan integritas</h4>' +
    '<p class="note" style="margin:0">Saya tidak memalsukan hasil forward test, tidak memakai data acak sebagai pengganti data Indodax, dan tidak mengetik angka dashboard secara manual. Semua angka berasal dari file di <span class="mono">data/</span> dan <span class="mono">logs/</span>, dihitung oleh <span class="mono">scripts/hitung_ulang.mjs</span>, lalu dirender oleh <span class="mono">scripts/build_dashboard.mjs</span>. Bila ada angka yang tidak dapat dihitung ulang, itu adalah kesalahan yang harus diperbaiki, bukan diratakan dengan narasi.</p>' +
    '</div>' +
    '</div>' +
    '</section>';
}
