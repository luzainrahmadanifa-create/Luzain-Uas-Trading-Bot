// Ambil snapshot order book mentah. Dijalankan berkala (minimal 3x sehari)
// selama masa persiapan; snapshot mentah ikut dikumpulkan.
// Contoh: node scripts/snapshot_orderbook.mjs
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { CONFIG } from '../lib/config.js';
import { getDepth, getServerTime, summarizeDepth } from '../lib/indodax.js';

const dir = path.resolve('data/snapshots');

async function main() {
  await fs.mkdir(dir, { recursive: true });
  const serverTime = await getServerTime();
  const nowIso = new Date().toISOString();
  const day = nowIso.slice(0, 10);
  const file = path.join(dir, `${day}.jsonl`);
  let written = 0;

  for (const u of CONFIG.universe) {
    try {
      const raw = await getDepth(u.pairId);
      const book = summarizeDepth(raw);
      if (!book.bestBid || !book.bestAsk) {
        console.log(`- ${u.symbol}: order book kosong, dilewati`);
        continue;
      }
      const rec = {
        ts: nowIso,
        serverTime,
        pair: u.symbol,
        pairId: u.pairId,
        bestBid: book.bestBid,
        bestAsk: book.bestAsk,
        mid: book.mid,
        spread: book.spread,
        spreadBps: (book.spread / book.mid) * 10000,
        depth: { buy: raw.buy, sell: raw.sell }
      };
      await fs.appendFile(file, JSON.stringify(rec) + '\n', 'utf8');
      written++;
      console.log(`- ${u.symbol}: bid=${book.bestBid} ask=${book.bestAsk} spread=${(rec.spreadBps).toFixed(2)} bps`);
    } catch (e) {
      console.log(`- ${u.symbol}: gagal ${e.message}`);
    }
  }
  console.log(`\n${written} snapshot ditulis ke ${file}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
