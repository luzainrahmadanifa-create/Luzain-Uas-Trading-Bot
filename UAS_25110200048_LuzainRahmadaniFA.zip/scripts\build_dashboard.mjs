// =====================================================================
// build_dashboard.mjs - merakit dashboard OFFLINE satu file HTML.
// Semua CSS/JS/grafik di-inline; tanpa CDN/internet.
// Sumber angka: data/recomputed.json + CSV/JSON mentah (di-embed).
//   node scripts/build_dashboard.mjs
// Output: dashboard/UAS_25110200048_LuzainRahmadaniFA.html (+ index.html)
// =====================================================================
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { CONFIG } from '../lib/config.js';
import { lineChart, histogram } from './dashboard/charts.mjs';
import { dateWib, monthName } from './dashboard/fmt.mjs';
import { renderRingkasan, renderBacktest, renderTrade } from './dashboard/sections_overview.mjs';
import { renderForward, renderValidasi } from './dashboard/sections_forward.mjs';
import { renderAturan, renderRefleksi } from './dashboard/sections_docs.mjs';

const ROOT = path.resolve('.');
const DATA = path.join(ROOT, 'data');
const DASH = path.join(ROOT, 'dashboard');
const TEMPLATE_DIR = path.join(ROOT, 'scripts', 'dashboard');
const OUT_FILE = path.join(DASH, 'UAS_25110200048_LuzainRahmadaniFA.html');

const IDENTITY = {
  name: 'Luzain Rahmadani F A',
  nim: '25110200048',
  kelas: 'Trad1',
  dosen: 'Pak Dwi'
};
const FWD_START = '2026-11-05T12:00:00+07:00';
const FWD_END = '2026-11-19T12:00:00+07:00';

async function exists(p) { try { await fs.access(p); return true; } catch { return false; } }
async function readJson(p, fb = null) { try { return JSON.parse(await fs.readFile(p, 'utf8')); } catch { return fb; } }
async function readText(p, fb = '') { try { return await fs.readFile(p, 'utf8'); } catch { return fb; } }
async function readJsonl(p) {
  const t = await readText(p, '');
  return t.split(/\r?\n/).filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
async function sha256File(rel) {
  try { return crypto.createHash('sha256').update(await fs.readFile(path.join(ROOT, rel))).digest('hex'); }
  catch { return null; }
}
function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length);
  if (!lines.length) return [];
  const head = lines[0].split(',');
  return lines.slice(1).map((line) => {
    const cells = line.split(',');
    const row = {};
    head.forEach((h, i) => { row[h] = cells[i]; });
    return row;
  });
}
function wibToMs(s) { return Date.parse(String(s).replace(' ', 'T') + '+07:00'); }
function n(v, fb = 0) { const x = Number(v); return Number.isFinite(x) ? x : fb; }
function sum(a) { return a.reduce((s, x) => s + x, 0); }
function mean(a) { return a.length ? sum(a) / a.length : 0; }
function stdev(a) {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(sum(a.map((x) => (x - m) ** 2)) / (a.length - 1));
}
function median(a) {
  if (!a.length) return null;
  const s = [...a].sort((x, y) => x - y);
  const i = Math.floor(s.length / 2);
  return s.length % 2 ? s[i] : (s[i - 1] + s[i]) / 2;
}
function clamp(v, a = 0, b = 100) { return Math.max(a, Math.min(b, v)); }
function monthKeyWib(ms) {
  const d = new Date(ms + 7 * 3600 * 1000);
  return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0');
}
function yearWib(ms) { return new Date(ms + 7 * 3600 * 1000).getUTCFullYear(); }

async function main() {
  const generatedAt = new Date().toISOString();
  const rec = await readJson(path.join(DATA, 'recomputed.json'));
  if (!rec || !rec.backtest) throw new Error('data/recomputed.json belum ada / tidak valid. Jalankan scripts/hitung_ulang.mjs dulu.');

  const summary = await readJson(path.join(DATA, 'backtest', 'summary.json'));
  const freeze = await readJson(path.join(DATA, 'freeze.json'), {});
  const universe = await readJson(path.join(DATA, 'universe.json'), { universe: [], allCandidates: [] });
  const costs = await readJson(path.join(DATA, 'costs.json'), { perPair: {} });
  const instrAll = await readJson(path.join(DATA, 'instruments.json'), { instruments: {} });
  const quality = await readJson(path.join(DATA, 'candles', 'quality.json'), { quality: [] });
  const variantsFile = await readJson(path.join(DATA, 'variants.json'), { variants: [] });

  const eqCsv = await readText(path.join(DATA, 'backtest', 'equity_daily.csv'));
  const benchCsv = await readText(path.join(DATA, 'backtest', 'benchmark_daily.csv'));
  const tradesCsv = await readText(path.join(DATA, 'backtest', 'trades.csv'));
  const signalsCsv = await readText(path.join(DATA, 'backtest', 'signals.csv'));

  // ---------- deret equity (prepend titik awal) ----------
  const startMs = Date.parse(CONFIG.backtestStart);
  const initial = CONFIG.startingEquityIdr;
  const equity = [{ t: startMs, e: initial, cash: initial, open: 0 }];
  for (const r of parseCsv(eqCsv)) {
    const t = wibToMs(r.time_wib);
    if (Number.isFinite(t)) equity.push({ t, e: n(r.equity_idr), cash: n(r.cash_idr), open: n(r.open_positions) });
  }
  equity.sort((a, b) => a.t - b.t);

  const bench = [{ t: startMs, e: initial }];
  for (const r of parseCsv(benchCsv)) {
    const t = wibToMs(r.time_wib);
    if (Number.isFinite(t)) bench.push({ t, e: n(r.equity_idr) });
  }
  bench.sort((a, b) => a.t - b.t);

  // ---------- trade ----------
  const tradesRaw = parseCsv(tradesCsv).map((r, i) => ({
    n: i + 1,
    pair: r.pair,
    et: Date.parse(r.entry_time),
    xt: Date.parse(r.exit_time),
    ep: n(r.entry_price),
    xp: n(r.exit_price),
    qty: n(r.qty),
    pnl: n(r.pnl_idr),
    pnlpct: n(r.pnl_pct),
    days: n(r.days),
    reason: r.reason,
    fee: n(r.fee_in_idr) + n(r.fee_out_idr),
    cost: n(r.fee_in_idr) + n(r.fee_out_idr) + n(r.spread_slip_cost_idr),
    fill: n(r.entry_fill_vs_signal_pct)
  }));

  // ---------- bulanan & tahunan ----------
  const monthLast = new Map();
  for (const p of equity) monthLast.set(monthKeyWib(p.t), p);
  const monthKeys = [...monthLast.keys()].sort();
  const currentMonth = monthKeyWib(Date.parse(generatedAt));
  const firstMonth = monthKeys[0];
  const monthly = [];
  let prev = initial;
  for (const k of monthKeys) {
    const p = monthLast.get(k);
    const [ys, ms] = k.split('-');
    const ret = prev > 0 ? (p.e / prev - 1) * 100 : 0;
    monthly.push({
      y: Number(ys), m: Number(ms),
      ret, end: p.e,
      partial: k === firstMonth || k === currentMonth
    });
    prev = p.e;
  }

  const yearLast = new Map();
  for (const p of equity) yearLast.set(yearWib(p.t), p);
  const yearKeys = [...yearLast.keys()].sort();
  const firstYear = yearKeys[0], lastYear = yearKeys[yearKeys.length - 1];
  const yearly = [];
  prev = initial;
  for (const y of yearKeys) {
    const p = yearLast.get(y);
    yearly.push({
      y, ret: prev > 0 ? (p.e / prev - 1) * 100 : 0, end: p.e,
      partial: y === firstYear || y === lastYear
    });
    prev = p.e;
  }

  // ---------- tantangan risiko tambahan ----------
  const rets = [];
  for (let i = 1; i < equity.length; i++) {
    if (equity[i - 1].e > 0) rets.push(equity[i].e / equity[i - 1].e - 1);
  }
  const mu = mean(rets);
  const sd = stdev(rets);
  const downside = Math.sqrt(sum(rets.map((r) => Math.min(0, r) ** 2)) / Math.max(1, rets.length));
  const sharpe = sd > 0 ? (mu / sd) * Math.sqrt(365) : null;
  const sortino = downside > 0 ? (mu / downside) * Math.sqrt(365) : null;
  const exposurePct = mean(equity.map((p) => (p.e > 0 ? (p.e - p.cash) / p.e : 0))) * 100;

  const holdDays = tradesRaw.map((t) => t.days);
  const extra = {
    sharpe, sortino,
    exposurePct,
    avgHoldDays: mean(holdDays),
    medianHoldDays: median(holdDays),
    payoff: summary.trades.payoff,
    expectancy: summary.trades.expectancy,
    bestTrade: summary.trades.bestTrade,
    worstTrade: summary.trades.worstTrade,
    positiveMonths: monthly.filter((m) => !m.partial && m.ret > 0).length,
    totalMonths: monthly.filter((m) => !m.partial).length,
    bestMonth: null,
    worstMonth: null,
    top5Share: 0
  };
  const fullMonths = monthly.filter((m) => !m.partial);
  const pool = fullMonths.length ? fullMonths : monthly;
  const best = [...pool].sort((a, b) => b.ret - a.ret)[0];
  const worst = [...pool].sort((a, b) => a.ret - b.ret)[0];
  extra.bestMonth = { ret: best ? best.ret : null, label: best ? monthName(best.m) + ' ' + best.y : '-' };
  extra.worstMonth = { ret: worst ? worst.ret : null, label: worst ? monthName(worst.m) + ' ' + worst.y : '-' };

  // ---------- per pair / alasan ----------
  function group(keyFn) {
    const m = new Map();
    for (const t of tradesRaw) {
      const k = keyFn(t);
      if (!m.has(k)) m.set(k, { key: k, trades: 0, wins: 0, pnl: 0, sumPct: 0 });
      const r = m.get(k);
      r.trades++;
      if (t.pnl > 0) r.wins++;
      r.pnl += t.pnl;
      r.sumPct += t.pnlpct;
    }
    return [...m.values()].map((r) => ({
      ...r,
      winRate: r.trades ? (r.wins / r.trades) * 100 : 0,
      avgPct: r.trades ? r.sumPct / r.trades : 0
    }));
  }
  const perPair = group((t) => t.pair).map((r) => ({ pair: r.key, ...r })).sort((a, b) => b.pnl - a.pnl);
  const perReason = group((t) => t.reason).map((r) => ({ reason: r.key, ...r }));

  const topWins = [...tradesRaw].sort((a, b) => b.pnl - a.pnl).slice(0, 5);
  const topLosses = [...tradesRaw].sort((a, b) => a.pnl - b.pnl).slice(0, 5);
  const grossProfit = summary.trades.grossProfit;
  extra.top5Share = grossProfit > 0 ? (sum(topWins.map((t) => Math.max(0, t.pnl))) / grossProfit) * 100 : 0;

  // ---------- histogram ----------
  const bins = [
    { label: '≤-10', min: -Infinity, max: -10, positive: false },
    { label: '-10..-7', min: -10, max: -7.5, positive: false },
    { label: '-7..-5', min: -7.5, max: -5, positive: false },
    { label: '-5..-2', min: -5, max: -2.5, positive: false },
    { label: '-2..0', min: -2.5, max: 0, positive: false },
    { label: '0..2', min: 0, max: 2.5, positive: true },
    { label: '2..5', min: 2.5, max: 5, positive: true },
    { label: '5..10', min: 5, max: 10, positive: true },
    { label: '10..20', min: 10, max: 20, positive: true },
    { label: '>20', min: 20, max: Infinity, positive: true }
  ];
  const hist = bins.map((b) => ({
    label: b.label,
    positive: b.positive,
    count: tradesRaw.filter((t) => t.pnlpct > b.min && t.pnlpct <= b.max).length
  }));

  // ---------- grafik ----------
  const equityChart = lineChart({
    series: [
      { name: 'Strategi', color: '#22d3ee', points: equity.map((p) => [p.t, (p.e / initial) * 100]) },
      { name: 'BTC', color: '#f59e0b', points: bench.map((p) => [p.t, (p.e / initial) * 100]), dash: true }
    ],
    width: 980, height: 340, label: 'Kurva ekuitas strategi vs BTC (indeks 100)',
    yFmt: (v) => v.toFixed(0),
    forceMin: 0
  });
  let peak = -Infinity;
  const ddPoints = equity.map((p) => {
    if (p.e > peak) peak = p.e;
    return [p.t, peak > 0 ? (p.e / peak - 1) * 100 : 0];
  });
  const ddMin = Math.min(...ddPoints.map((p) => p[1]));
  const ddChart = lineChart({
    series: [{ name: 'Drawdown', color: '#ef4444', points: ddPoints }],
    width: 980, height: 230, label: 'Drawdown harian',
    yFmt: (v) => v.toFixed(0) + '%',
    forceMax: 0, forceMin: ddMin * 1.12,
    fillFirst: true, baseline: 0
  });
  const histChart = histogram({
    bars: hist, width: 980, height: 250,
    label: 'Distribusi return per trade',
    xLabel: 'return per trade (%)'
  });

  // ---------- status & audit ----------
  const checksPass = rec.checks.filter((x) => x.ok === true).length;
  const configHash = await sha256File('lib/config.js');
  const frozenEntry = (freeze.files || []).find((f) => f.file === 'lib/config.js');
  const configHashMatches = Boolean(configHash && frozenEntry && frozenEntry.sha256 === configHash);
  const frozenMismatches = [];
  for (const f of freeze.files || []) {
    const h = await sha256File(f.file);
    if (h !== f.sha256) frozenMismatches.push({ file: f.file, expected: f.sha256, actual: h });
  }

  // ---------- log ringkas ----------
  let logDir = path.join(ROOT, 'logs', 'export');
  if (!(await exists(path.join(logDir, 'calls.jsonl')))) logDir = path.join(ROOT, 'logs', 'local');
  const calls = await readJsonl(path.join(logDir, 'calls.jsonl'));
  const orders = await readJsonl(path.join(logDir, 'orders.jsonl'));
  const equityLog = await readJsonl(path.join(logDir, 'equity.jsonl'));
  const signalsLog = await readJsonl(path.join(logDir, 'signals.jsonl'));
  const errorsLog = await readJsonl(path.join(logDir, 'errors.jsonl'));
  const killLog = await readJsonl(path.join(logDir, 'killswitch.jsonl'));
  const stateRaw = await readJson(path.join(logDir, 'state.json'), null);
  const logs = {
    mode: logDir.endsWith('export') ? 'export (produksi)' : 'lokal (uji coba)',
    dir: path.relative(ROOT, logDir).replaceAll('\\', '/'),
    calls: calls.length, orders: orders.length, equity: equityLog.length,
    signals: signalsLog.length, errors: errorsLog.length, killswitch: killLog.length,
    state: stateRaw ? {
      startingEquity: stateRaw.startingEquity,
      cash: stateRaw.cash,
      lastEquity: stateRaw.lastEquity,
      positions: Object.keys(stateRaw.positions || {}).length,
      runCount: stateRaw.runCount,
      lastRunAt: stateRaw.lastRunAt,
      killSwitch: stateRaw.killSwitch,
      dayKey: stateRaw.dayKey,
      dailyLossTripped: stateRaw.dailyLossTripped,
      lastCandle: stateRaw.lastCandle
    } : null
  };

  // ---------- forward progress ----------
  const nowMs = Date.parse(generatedAt);
  const fStart = Date.parse(FWD_START);
  const fEnd = Date.parse(FWD_END);
  const forwardProgress = {
    startIso: new Date(fStart).toISOString(),
    endIso: new Date(fEnd).toISOString(),
    pct: clamp(((nowMs - fStart) / (fEnd - fStart)) * 100),
    daysElapsed: Math.max(0, (nowMs - fStart) / 86400000),
    daysTotal: (fEnd - fStart) / 86400000
  };

  // ---------- instrumen 5 pair ----------
  const instruments = {};
  for (const u of CONFIG.universe) {
    const v = instrAll.instruments[u.pairId];
    if (v) instruments[u.pairId] = {
      symbol: v.symbol,
      tradeFeePercentTaker: v.tradeFeePercentTaker,
      tradeMinBaseCurrencyIdr: v.tradeMinBaseCurrencyIdr,
      quantityIncrement: v.quantityIncrement,
      priceIncrement: v.priceIncrement,
      isMaintenance: v.isMaintenance
    };
  }

  // ---------- bt (gabungan recomputed + summary) ----------
  const bt = {
    ...rec.backtest,
    wins: summary.trades.wins,
    losses: summary.trades.losses,
    mddPeakAt: summary.equity.mddPeakAt,
    mddTroughAt: summary.equity.mddTroughAt
  };

  const signalsExample = signalsCsv.split(/\r?\n/).slice(0, 201).join('\n');

  const ctx = {
    identity: IDENTITY,
    generatedAt,
    generatedWib: dateWib(generatedAt),
    version: CONFIG.version,
    frozenAt: CONFIG.frozenAt,
    frozenWib: dateWib(CONFIG.frozenAt),
    configHash,
    configHashShort: configHash ? configHash.slice(0, 12) : 'n/a',
    configHashMatches,
    frozenMismatches,
    bt,
    bench: rec.benchmark,
    fwd: rec.forward,
    replay: rec.replay,
    match: rec.signalMatch,
    gap: rec.gap,
    ops: rec.ops,
    checks: rec.checks,
    checksPass,
    extra,
    monthly, yearly, perPair, perReason, topWins, topLosses,
    charts: { equity: equityChart, drawdown: ddChart, hist: histChart },
    universe,
    costs,
    instruments,
    quality: quality.quality,
    qualityGeneratedAt: quality.generatedAt,
    variants: variantsFile.variants || [],
    freeze,
    logs,
    trades: tradesRaw,
    forwardProgress,
    downloads: {
      trades: { name: 'trades.csv', mime: 'text/csv', text: tradesCsv },
      equity: { name: 'equity_daily.csv', mime: 'text/csv', text: eqCsv },
      signalsExample: { name: 'signals_example_200.csv', mime: 'text/csv', text: signalsExample }
    }
  };

  const sections = [
    renderRingkasan(ctx),
    renderBacktest(ctx),
    renderTrade(ctx),
    renderForward(ctx),
    renderValidasi(ctx),
    renderAturan(ctx),
    renderRefleksi(ctx)
  ].join('\n');

  const payload = {
    meta: {
      generatedAt, generatedWib: ctx.generatedWib,
      identity: IDENTITY, version: CONFIG.version,
      frozenAt: CONFIG.frozenAt, configHash, configHashMatches,
      forward: forwardProgress, progressPct: forwardProgress.pct
    },
    bt, benchmark: rec.benchmark, forward: rec.forward, replay: rec.replay,
    gap: rec.gap, ops: rec.ops, signalMatch: rec.signalMatch, checks: rec.checks,
    monthly, yearly, perPair, perReason,
    trades: tradesRaw, downloads: ctx.downloads,
    logs, extra
  };

  const template = await readText(path.join(TEMPLATE_DIR, 'template.html'));
  const style = await readText(path.join(TEMPLATE_DIR, 'style.css'));
  const app = await readText(path.join(TEMPLATE_DIR, 'app.js'));
  const dataJson = JSON.stringify(payload).replace(/</g, '\\u003c');

  let html = template
    .replaceAll('/*__STYLE__*/', style)
    .replaceAll('/*__DATA__*/null', dataJson)
    .replaceAll('/*__APP__*/', app)
    .replaceAll('<!--SECTIONS-->', sections)
    .replaceAll('{{NAME}}', IDENTITY.name)
    .replaceAll('{{NIM}}', IDENTITY.nim)
    .replaceAll('{{KELAS}}', IDENTITY.kelas)
    .replaceAll('{{DOSEN}}', IDENTITY.dosen)
    .replaceAll('{{VERSION}}', CONFIG.version)
    .replaceAll('{{FROZEN}}', dateWib(CONFIG.frozenAt))
    .replaceAll('{{GENERATED}}', ctx.generatedWib)
    .replaceAll('{{CONFIG_HASH_SHORT}}', ctx.configHashShort);

  if (html.includes('{{') || html.includes('/*__')) {
    const left = html.match(/\{\{[A-Z_]+\}\}|\/\*__[A-Z]+__\*\//g);
    throw new Error('placeholder belum terisi: ' + [...new Set(left)].join(', '));
  }

  await fs.mkdir(DASH, { recursive: true });
  await fs.writeFile(OUT_FILE, html);
  await fs.writeFile(path.join(DASH, 'index.html'), html);

  const kb = Buffer.byteLength(html, 'utf8') / 1024;
  console.log('Dashboard offline dibuat:');
  console.log('  ' + path.relative(ROOT, OUT_FILE) + '  (' + kb.toFixed(0) + ' KB)');
  console.log('  dashboard/index.html (salinan untuk hosting statis)');
  console.log('  Audit: ' + checksPass + '/' + rec.checks.length + ' cek lolos; config hash ' + (configHashMatches ? 'COCOK' : 'BERUBAH') + ' dengan freeze.');
  console.log('  Forward: ' + rec.forward.calls + ' panggilan, ' + rec.forward.trades + ' trade; progres ' + forwardProgress.pct.toFixed(1) + '%.');
}

main().catch((e) => { console.error(e); process.exit(1); });
