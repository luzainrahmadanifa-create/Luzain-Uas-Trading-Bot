// =====================================================================
// record_deploy.mjs - catat link repo, commit hash, dan URL Vercel.
// Menulis data/deploy.json, memperbarui blok git di data/freeze.json,
// dan mengisi tabel link di README.md (di antara marker DEPLOY_LINKS).
//
//   node scripts/record_deploy.mjs \
//     --repo https://github.com/user/repo \
//     --commit 0123456789abcdef0123456789abcdef01234567 \
//     --url https://project.vercel.app
//
// Catatan kejujuran: commit yang dibuat setelah 5 Nov 2026 BUKAN commit beku.
// Script ini menulis tanggal commit apa adanya dan memverifikasi bahwa hash
// file inti masih sama dengan yang dibekukan. Kalau berbeda, akan diberi tanda.
// =====================================================================
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = path.resolve('.');
const README = path.join(ROOT, 'README.md');
const FREEZE = path.join(ROOT, 'data', 'freeze.json');
const OUT = path.join(ROOT, 'data', 'deploy.json');

function arg(name, fallback = null) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

function fail(msg) {
  console.error('GAGAL: ' + msg);
  process.exit(1);
}

function wib(iso) {
  return new Date(iso).toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  }).replace(/\./g, ':') + ' WIB';
}

const repo = (arg('repo') || '').replace(/\/$/, '');
const commit = (arg('commit') || '').trim().toLowerCase();
const url = (arg('url') || '').replace(/\/$/, '');
const note = arg('note', '');

if (!repo) fail('--repo wajib, contoh https://github.com/user/uas-algo-indodax');
if (!/^https?:\/\/(www\.)?github\.com\/[^/]+\/[^/]+$/i.test(repo)) fail('--repo harus URL repo GitHub, contoh https://github.com/user/repo');
if (!/^[0-9a-f]{7,40}$/.test(commit)) fail('--commit harus hash git (7-40 karakter hex), ambil dari `git rev-parse HEAD`');
if (!/^https:\/\/[^/]+$/i.test(url)) fail('--url harus URL Vercel tanpa garis miring di akhir, contoh https://project.vercel.app');

async function sha256(rel) {
  const buf = await fs.readFile(path.join(ROOT, rel));
  return crypto.createHash('sha256').update(buf).digest('hex');
}

async function main() {
  const recordedAt = new Date().toISOString();

  const deploy = {
    recordedAt,
    repoUrl: repo,
    commit,
    vercelUrl: url,
    dashboardUrl: url + '/api/dashboard',
    note: note || 'Commit dibuat setelah tanggal beku resmi; isi file inti diverifikasi lewat SHA-256 di data/freeze.json.'
  };

  // 1. Verifikasi hash file inti masih sama dengan yang dibekukan.
  let freeze = null;
  let hashesMatch = null;
  try {
    freeze = JSON.parse(await fs.readFile(FREEZE, 'utf8'));
  } catch {
    console.warn('[peringatan] data/freeze.json tidak ditemukan; blok git tidak diperbarui.');
  }

  if (freeze && Array.isArray(freeze.files)) {
    const mismatched = [];
    for (const f of freeze.files) {
      try {
        const now = await sha256(f.file);
        if (now !== f.sha256) mismatched.push(f.file);
      } catch {
        mismatched.push(f.file + ' (hilang)');
      }
    }
    hashesMatch = mismatched.length === 0;
    if (!hashesMatch) {
      console.warn('[peringatan] file inti berubah sejak freeze: ' + mismatched.join(', '));
      console.warn('             Jangan lanjutkan kalau perubahan menyentuh logika strategi/risiko.');
    } else {
      console.log('Hash file inti: COCOK dengan data/freeze.json (' + freeze.files.length + ' file).');
    }
    deploy.hashesMatch = hashesMatch;
  }

  await fs.writeFile(OUT, JSON.stringify(deploy, null, 2));
  console.log('Ditulis: data/deploy.json');

  // 2. Perbarui blok git di freeze.json (tanpa mengubah parameter/hash).
  if (freeze) {
    freeze.git = {
      available: true,
      commit,
      repoUrl: repo,
      commitRecordedAt: recordedAt,
      note: deploy.note,
      hashesMatchAtRecord: hashesMatch
    };
    freeze.deployment = {
      vercelUrl: url,
      dashboardUrl: deploy.dashboardUrl,
      recordedAt
    };
    await fs.writeFile(FREEZE, JSON.stringify(freeze, null, 2));
    console.log('Diperbarui: data/freeze.json (blok git + deployment)');
  }

  // 3. Isi tabel link + perbarui pernyataan status di README.
  const start = '<!-- DEPLOY_LINKS_START -->';
  const end = '<!-- DEPLOY_LINKS_END -->';
  let readme = await fs.readFile(README, 'utf8');

  function replaceBlock(text, open, close, body) {
    const a = text.indexOf(open);
    const b = text.indexOf(close);
    if (a < 0 || b < 0) return null;
    return text.slice(0, a) + open + '\n' + body + '\n' + close + text.slice(b + close.length);
  }

  const table = [
    '| Item | Nilai |',
    '|---|---|',
    `| Repo GitHub | ${repo} |`,
    `| Commit hash | \`${commit}\` |`,
    `| URL Vercel | ${url} |`,
    `| Dashboard live | ${deploy.dashboardUrl} |`,
    `| Dicatat pada | ${wib(recordedAt)} |`
  ].join('\n');

  let nextReadme = replaceBlock(readme, start, end, table);
  if (nextReadme === null) {
    console.warn('[peringatan] marker DEPLOY_LINKS tidak ada di README; tabel tidak diisi.');
  } else {
    readme = nextReadme;
  }

  const status = [
    '> **Status jujur:** backtest 3 tahun **selesai** dan dapat dihitung ulang. ' +
    'Forward test live **berjalan sejak ' + wib(recordedAt) + '** — hanya sebagian jendela 5–19 Nov, bukan 14 hari penuh. ' +
    'Log produksi tersimpan di Redis dan akan diekspor ke `logs/export/` pada 19 Nov, lalu dihitung ulang dari file mentah. ' +
    'Tidak ada angka yang dikarang.'
  ].join('\n');

  nextReadme = replaceBlock(readme, '<!-- STATUS_START -->', '<!-- STATUS_END -->', status);
  if (nextReadme === null) {
    console.warn('[peringatan] marker STATUS tidak ada di README; status atas tidak diperbarui.');
  } else {
    readme = nextReadme;
  }

  const deployStatus = [
    `**Status deployment:** live di ${url} (dashboard ${deploy.dashboardUrl}). ` +
    `Snapshot kode: commit \`${commit}\` di ${repo}. ` +
    'Commit dibuat setelah tanggal beku dan hanya menambah dokumentasi; hash file inti diverifikasi cocok dengan `data/freeze.json`.'
  ].join('\n');

  nextReadme = replaceBlock(readme, '<!-- DEPLOY_STATUS_START -->', '<!-- DEPLOY_STATUS_END -->', deployStatus);
  if (nextReadme === null) {
    console.warn('[peringatan] marker DEPLOY_STATUS tidak ada di README.');
  } else {
    readme = nextReadme;
  }

  await fs.writeFile(README, readme);
  console.log('Diperbarui: README.md (tabel link + status)');

  console.log('\nRingkasan:');
  console.log('  repo    ' + repo);
  console.log('  commit  ' + commit + (hashesMatch === false ? '  [HASH TIDAK COCOK]' : ''));
  console.log('  url     ' + url);
  console.log('\nLangkah berikutnya: cek ' + deploy.dashboardUrl + ' dan panggil /api/tick dua kali.');
}

main().catch((e) => { console.error(e); process.exit(1); });
