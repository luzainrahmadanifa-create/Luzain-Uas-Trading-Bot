// Menjalankan uji ketahanan parameter (pra-freeze) dan menyimpan hasilnya.
//   node scripts/run_variants.mjs
// Output: data/variants/*/summary.json + data/variants.json
import { spawnSync } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const VARIANTS = [
  { id: 'v0', label: '1 jam · ATR 3 · tanpa slope', tf: '60', atrMult: 3, trendSlopeBars: 0, maxPositions: 5, alloc: 0.20 },
  { id: 'v1', label: '4 jam · ATR 3 · tanpa slope', tf: '240', atrMult: 3, trendSlopeBars: 0, maxPositions: 5, alloc: 0.20 },
  { id: 'v2', label: '4 jam · ATR 3 · slope 12', tf: '240', atrMult: 3, trendSlopeBars: 12, maxPositions: 5, alloc: 0.20 },
  { id: 'v3', label: '4 jam · ATR 4 · tanpa slope', tf: '240', atrMult: 4, trendSlopeBars: 0, maxPositions: 5, alloc: 0.20 },
  { id: 'v4', label: '4 jam · ATR 4 · slope 12', tf: '240', atrMult: 4, trendSlopeBars: 12, maxPositions: 5, alloc: 0.20 },
  { id: 'v5', label: '4 jam · ATR 3 · slope 6 · maks 5 posisi', tf: '240', atrMult: 3, trendSlopeBars: 6, maxPositions: 5, alloc: 0.20 },
  { id: 'v6', label: '4 jam · ATR 3 · slope 6 · maks 4 posisi', tf: '240', atrMult: 3, trendSlopeBars: 6, maxPositions: 4, alloc: 0.20 },
  { id: 'v7', label: '4 jam · ATR 3 · slope 6 · maks 4 posisi · 15%', tf: '240', atrMult: 3, trendSlopeBars: 6, maxPositions: 4, alloc: 0.15 }
];

async function main() {
  const out = [];
  for (const v of VARIANTS) {
    const overrides = {
      timeframe: v.tf,
      tfMinutes: Number(v.tf),
      atrMult: v.atrMult,
      trendSlopeBars: v.trendSlopeBars,
      maxPositions: v.maxPositions,
      allocPctPerPosition: v.alloc
    };
    process.stdout.write(`- ${v.id} ${v.label} ... `);
    const r = spawnSync(process.execPath, ['scripts/backtest.mjs'], {
      encoding: 'utf8',
      env: { ...process.env, BT_OVERRIDES: JSON.stringify(overrides), BT_OUT: 'variants/' + v.id }
    });
    if (r.status !== 0) {
      console.log('GAGAL');
      console.log(r.stderr || r.stdout);
      continue;
    }
    const s = JSON.parse(await fs.readFile(path.resolve('data/variants', v.id, 'summary.json'), 'utf8'));
    const row = {
      id: v.id, label: v.label, params: overrides,
      returnPct: s.equity.totalReturnPct,
      cagrPct: s.equity.cagrPct,
      mddPct: s.equity.maxDrawdownPct,
      trades: s.trades.trades,
      winRate: s.trades.winRate,
      profitFactor: s.trades.profitFactor,
      costSharePct: s.trades.costSharePct,
      benchmarkPct: s.benchmark.returnPct,
      period: s.period
    };
    out.push(row);
    console.log(`return ${row.returnPct.toFixed(2)}% | MDD ${row.mddPct.toFixed(2)}% | PF ${row.profitFactor.toFixed(2)} | trade ${row.trades}`);
  }
  await fs.writeFile(path.resolve('data/variants.json'), JSON.stringify({
    generatedAt: new Date().toISOString(),
    note: 'Uji ketahanan pra-freeze. Backtest berhenti sebelum freeze date 5 Nov 2026 12.00 WIB. Varian v7 dipilih dan dibekukan.',
    variants: out
  }, null, 2));
  console.log('\nDitulis: data/variants.json');
}

main().catch((e) => { console.error(e); process.exit(1); });
