// Simpan metadata instrumen (fee, minimum order, increment) sebagai bukti audit.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { getPairs, getPriceIncrements, getServerTime } from '../lib/indodax.js';

async function main() {
  const [pairs, inc, serverTime] = await Promise.all([getPairs(), getPriceIncrements(), getServerTime()]);
  const byId = new Map(pairs.map((p) => [p.id, p]));
  const out = {
    fetchedAt: new Date().toISOString(),
    serverTime,
    serverTimeIso: new Date(serverTime * 1000).toISOString(),
    sources: {
      pairs: 'https://indodax.com/api/pairs',
      priceIncrements: 'https://indodax.com/api/price_increments'
    },
    instruments: {}
  };
  for (const [id, p] of byId) {
    if (!id.endsWith('idr')) continue;
    out.instruments[id] = {
      symbol: p.symbol,
      description: p.description,
      tradeFeePercentTaker: p.trade_fee_percent_taker,
      tradeFeePercentMaker: p.trade_fee_percent_maker,
      tradeMinBaseCurrencyIdr: p.trade_min_base_currency,
      quantityIncrement: p.quantity_increment,
      priceRound: p.price_round,
      priceIncrement: inc[p.ticker_id] ?? inc[id] ?? null,
      volumePrecision: p.volume_precision,
      isMaintenance: p.is_maintenance,
      isMarketSuspended: p.is_market_suspended
    };
  }
  await fs.mkdir(path.resolve('data'), { recursive: true });
  await fs.writeFile(path.resolve('data/instruments.json'), JSON.stringify(out, null, 2));
  console.log(`instruments.json: ${Object.keys(out.instruments).length} pasangan IDR`);
}

main().catch((e) => { console.error(e); process.exit(1); });
