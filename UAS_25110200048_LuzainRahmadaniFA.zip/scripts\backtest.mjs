// Backtest portofolio multi-aset untuk strategi beku.
// - Sinyal dari lib/strategy.js (fungsi yang SAMA dengan bot).
// - Eksekusi di open bar berikutnya, dengan spread & slippage hasil ukur.
// - Long-only, maks 5 posisi, 20% ekuitas/posisi, daily loss limit 3% (WIB).
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { CONFIG as BASE_CONFIG } from '../lib/config.js';
import { computeSignals } from '../lib/strategy.js';
import { backtestFillPrice, feeFor } from '../lib/execution.js';
import { dayKeyWIB } from '../lib/risk.js';
import {
  totalReturnPct, cagrPct, maxDrawdown, tradeStats, costSharePct,
  buyAndHold, dailyEquity, maxConsecutiveLosses
} from '../lib/metrics.js';

const DATA = path.resolve('data');
const OUT = path.join(DATA, process.env.BT_OUT || 'backtest');

// Override hanya untuk eksperimen pra-freeze (dijalankan manual).
const OVERRIDES = process.env.BT_OVERRIDES ? JSON.parse(process.env.BT_OVERRIDES) : {};
const CFG = { ...BASE_CONFIG, ...OVERRIDES };
const TF_SEC = (Number(CFG.timeframe) || 60) * 60;

function floorTo(v, inc) {
  if (!inc || inc <= 0) return v;
  return Math.floor(v / inc + 1e-9) * inc;
}

async function loadJson(p) { return JSON.parse(await fs.readFile(p, 'utf8')); }

async function main() {
  const costsAll = await loadJson(path.join(DATA, 'costs.json'));
  const instrAll = await loadJson(path.join(DATA, 'instruments.json'));
  const start = Math.floor(Date.parse(CFG.backtestStart) / 1000);
  const end = Math.floor(Date.parse(CFG.backtestEnd) / 1000);

  const pairs = [];
  for (const u of CFG.universe) {
    const file = path.join(DATA, 'candles', `${u.symbol}_${CFG.timeframe}.json`);
    const raw = await loadJson(file);
    const candles = raw.candles.filter((c) => c.t >= start - 400 * TF_SEC && c.t <= end);
    const { rows } = computeSignals(candles, CFG);
    const byTime = new Map();
    rows.forEach((r, i) => byTime.set(r.t, { row: r, i }));
    const cost = costsAll.perPair[u.symbol] || { medianSpreadBps: 10, slippageBps: 5 };
    const inst = instrAll.instruments[u.pairId] || {};
    pairs.push({
      ...u,
      rows, byTime,
      cost: {
        spreadBps: cost.medianSpreadBps ?? 10,
        slippageBps: cost.slippageBps ?? 5
      },
      qInc: Number(inst.quantityIncrement ?? 1e-8) || 1e-8
    });
    console.log(`- ${u.symbol}: ${rows.length} bar, spread ${cost.medianSpreadBps} bps, slip ${cost.slippageBps} bps`);
  }

  // timeline gabungan (hanya dalam periode backtest)
  const times = new Set();
  for (const p of pairs) for (const r of p.rows) if (r.t >= start && r.t <= end) times.add(r.t);
  const timeline = [...times].sort((a, b) => a - b);
  console.log(`\nTimeline: ${timeline.length} bar unik, ${new Date(timeline[0] * 1000).toISOString()} .. ${new Date(timeline.at(-1) * 1000).toISOString()}`);

  const state = {
    cash: CFG.startingEquityIdr,
    positions: new Map(),
    pending: new Map(),
    trades: [],
    equity: [],
    dailyAnchor: { dayKey: null, equity: null, tripped: false },
    haltedDays: new Set()
  };
  let lastEquity = CFG.startingEquityIdr;

  const equityAt = (t) => {
    let posVal = 0;
    for (const [symbol, pos] of state.positions) {
      const p = pairs.find((x) => x.symbol === symbol);
      const bar = p?.byTime.get(t)?.row;
      if (!bar) continue;
      // nilai likuidasi: best bid ~ close - setengah spread
      posVal += pos.qty * bar.c * (1 - p.cost.spreadBps / 2 / 10000);
    }
    return state.cash + posVal;
  };

  for (const t of timeline) {
    const wibDay = dayKeyWIB(t * 1000);

    // --- 1. eksekusi order pending (diputuskan pada bar sebelumnya) ---
    for (const [symbol, order] of [...state.pending]) {
      if (order.dueT > t) continue;
      const p = pairs.find((x) => x.symbol === symbol);
      const cur = p?.byTime.get(t);
      if (!cur) {
        if (t - order.dueT > 3 * TF_SEC) state.pending.delete(symbol);
        continue;
      }
      if (t - order.dueT > 3 * TF_SEC) { state.pending.delete(symbol); continue; }
      const bar = cur.row;

      if (order.side === 'buy') {
        // batas harian
        if (state.dailyAnchor.dayKey !== wibDay) {
          state.dailyAnchor = { dayKey: wibDay, equity: lastEquity, tripped: false, anchorAt: t };
        }
        const dayEquity = state.dailyAnchor.equity ?? lastEquity;
        if (lastEquity < dayEquity * (1 - CFG.dailyLossLimitPct)) {
          state.dailyAnchor.tripped = true;
          state.haltedDays.add(wibDay);
        }
        const canTrade = !state.dailyAnchor.tripped && !state.haltedDays.has(wibDay)
          && state.positions.size < CFG.maxPositions;

        if (canTrade) {
          const fill = backtestFillPrice(bar.o, 'buy', p.cost);
          let budget = Math.min(lastEquity * CFG.allocPctPerPosition, state.cash / (1 + CFG.feeTakerPct));
          let qty = floorTo(budget / fill, p.qInc);
          let notional = qty * fill;
          let fee = feeFor(notional);
          if (notional < CFG.minOrderIdr) {
            // coba naikkan ke minimum order bila kas cukup
            const minQty = floorTo(CFG.minOrderIdr / fill, p.qInc);
            if (minQty * fill * (1 + CFG.feeTakerPct) <= state.cash) {
              qty = minQty; notional = qty * fill; fee = feeFor(notional);
            } else { qty = 0; }
          }
          if (qty > 0) {
            state.cash -= notional + fee;
            const stop = fill - CFG.atrMult * (order.signalRow.atr ?? 0);
            state.positions.set(symbol, {
              qty, entryPrice: fill, entryT: t, entryNotional: notional, entryFee: fee,
              stop, signalT: order.signalT, signalClose: order.signalClose,
              spreadSlipCost: notional * ((p.cost.spreadBps / 2 + p.cost.slippageBps) / 10000)
            });
          }
        }
      } else if (order.side === 'sell') {
        const pos = state.positions.get(symbol);
        if (pos) {
          const fill = backtestFillPrice(bar.o, 'sell', p.cost);
          const notional = pos.qty * fill;
          const fee = feeFor(notional);
          state.cash += notional - fee;
          const pnl = notional - fee - pos.entryNotional - pos.entryFee;
          state.trades.push({
            pair: symbol,
            entryT: pos.entryT, exitT: t,
            entryPrice: pos.entryPrice, exitPrice: fill,
            qty: pos.qty,
            entryNotional: pos.entryNotional, exitNotional: notional,
            feeIn: pos.entryFee, feeOut: fee,
            grossPnl: notional - pos.entryNotional,
            pnl, pnlPct: (pnl / (pos.entryNotional + pos.entryFee)) * 100,
            days: (t - pos.entryT) / 86400,
            reason: order.reason,
            spreadSlipCost: pos.spreadSlipCost + notional * ((p.cost.spreadBps / 2 + p.cost.slippageBps) / 10000),
            signalEntryT: pos.signalT, signalExitT: order.signalT,
            entryFillVsSignalPct: pos.signalClose ? (pos.entryPrice / pos.signalClose - 1) * 100 : null
          });
          state.positions.delete(symbol);
        }
      }
      state.pending.delete(symbol);
    }

    // --- 2. evaluasi sinyal pada close bar t ---
    for (const p of pairs) {
      const cur = p.byTime.get(t);
      if (!cur) continue;
      const row = cur.row;
      if (!row.ready) continue;
      const pos = state.positions.get(p.symbol);

      if (pos) {
        const prevStop = pos.stop;
        // exit bila close di bawah stop sebelumnya, atau death cross
        const stopHit = row.c < prevStop;
        if (stopHit || row.exitSignal) {
          if (!state.pending.has(p.symbol)) {
            state.pending.set(p.symbol, {
              side: 'sell', dueT: t + TF_SEC,
              reason: stopHit ? 'trailing_stop' : 'death_cross',
              signalT: t
            });
          }
        } else {
          // ratchet stop
          pos.stop = Math.max(prevStop, row.c - CFG.atrMult * row.atr);
        }
      } else if (row.entrySignal && !state.pending.has(p.symbol)) {
        if (state.positions.size < CFG.maxPositions && !state.haltedDays.has(wibDay)) {
          state.pending.set(p.symbol, {
            side: 'buy', dueT: t + TF_SEC, signalT: t,
            signalRow: row, signalClose: row.c
          });
        }
      }
    }

    // --- 3. tandai equity ---
    lastEquity = equityAt(t);
    state.equity.push({ t, equity: lastEquity, cash: state.cash, open: state.positions.size });
    if (state.dailyAnchor.dayKey !== wibDay) {
      state.dailyAnchor = { dayKey: wibDay, equity: lastEquity, tripped: false, anchorAt: t };
    }
  }

  // --- ringkasan ---
  const lastT = timeline.at(-1);
  const finalEquity = state.equity.at(-1).equity;
  // equity harian mengikuti batas hari WIB (00.00 WIB)
  const dailyMap = new Map();
  for (const p of state.equity) dailyMap.set(dayKeyWIB(p.t * 1000), p);
  const daily = [...dailyMap.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)).map(([, v]) => v);
  const mdd = maxDrawdown(daily);
  const stats = tradeStats(state.trades);
  const fees = state.trades.reduce((s, t) => s + t.feeIn + t.feeOut, 0);
  const spreadSlip = state.trades.reduce((s, t) => s + t.spreadSlipCost, 0);
  const totalCosts = fees + spreadSlip;
  const days = (lastT - timeline[0]) / 86400;

  const openPositions = [...state.positions.entries()].map(([symbol, pos]) => {
    const p = pairs.find((x) => x.symbol === symbol);
    const lastBar = [...p.byTime.values()].filter((x) => x.row.t <= lastT).at(-1)?.row;
    const mark = lastBar ? lastBar.c * (1 - p.cost.spreadBps / 2 / 10000) : pos.entryPrice;
    return {
      pair: symbol, qty: pos.qty, entryPrice: pos.entryPrice, entryT: pos.entryT,
      markPrice: mark,
      unrealizedPnl: pos.qty * mark - pos.entryNotional - pos.entryFee,
      entrySignalT: pos.signalT
    };
  });

  // benchmark BTC buy & hold pada periode yang sama
  const btcPair = pairs.find((p) => p.symbol === CFG.benchmarkSymbol) || pairs[0];
  const btcCandles = btcPair.rows.filter((r) => r.t >= timeline[0] && r.t <= lastT)
    .map((r) => ({ t: r.t, o: r.o, h: r.h, l: r.l, c: r.c, v: r.v }));
  const bench = buyAndHold(btcCandles, CFG.startingEquityIdr, CFG.feeTakerPct);

  // kurva benchmark harian (WIB) + MDD
  const benchMap = new Map();
  for (const c of btcCandles) {
    const eq = bench.qty * c.c * (1 - CFG.feeTakerPct);
    benchMap.set(dayKeyWIB(c.t * 1000), { t: c.t, equity: eq });
  }
  const benchDaily = [...benchMap.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)).map(([, v]) => v);
  const benchMdd = maxDrawdown(benchDaily);

  const summary = {
    engine: 'backtest.mjs',
    generatedAt: new Date().toISOString(),
    strategyVersion: CFG.version,
    period: {
      start: new Date(timeline[0] * 1000).toISOString(),
      end: new Date(lastT * 1000).toISOString(),
      days: Number(days.toFixed(2)),
      bars: timeline.length,
      timeframe: CFG.timeframe
    },
    universe: CFG.universe.map((u) => u.symbol),
    costs: {
      feeTakerPctPerSide: CFG.feeTakerPct * 100,
      feeSource: CFG.feeSource,
      spreadSlippagePerPair: Object.fromEntries(pairs.map((p) => [p.symbol, p.cost])),
      totalFeesIdr: fees,
      totalSpreadSlipIdr: spreadSlip,
      totalCostsIdr: totalCosts
    },
    equity: {
      initial: CFG.startingEquityIdr,
      final: finalEquity,
      totalReturnPct: totalReturnPct(CFG.startingEquityIdr, finalEquity),
      cagrPct: cagrPct(CFG.startingEquityIdr, finalEquity, days),
      maxDrawdownPct: mdd.mddPct,
      mddPeakAt: mdd.peakAt ? new Date(mdd.peakAt * 1000).toISOString() : null,
      mddTroughAt: mdd.troughAt ? new Date(mdd.troughAt * 1000).toISOString() : null
    },
    trades: {
      ...stats,
      maxConsecutiveLosses: maxConsecutiveLosses(state.trades),
      costSharePct: costSharePct(totalCosts, stats.grossProfit)
    },
    benchmark: {
      symbol: CFG.benchmarkSymbol,
      initial: CFG.startingEquityIdr,
      final: bench?.final ?? null,
      returnPct: bench?.returnPct ?? null,
      cagrPct: bench ? cagrPct(CFG.startingEquityIdr, bench.final, days) : null,
      maxDrawdownPct: benchMdd.mddPct
    },
    openPositions,
    signalCounts: pairs.map((p) => ({
      pair: p.symbol,
      entries: p.rows.filter((r) => r.entrySignal).length,
      exits: p.rows.filter((r) => r.exitSignal).length
    }))
  };

  // --- tulis output ---
  await fs.mkdir(OUT, { recursive: true });
  await fs.writeFile(path.join(OUT, 'summary.json'), JSON.stringify(summary, null, 2));

  const tradeHeader = 'no,pair,entry_time,exit_time,entry_price,exit_price,qty,entry_notional_idr,exit_notional_idr,fee_in_idr,fee_out_idr,pnl_idr,pnl_pct,days,reason,spread_slip_cost_idr,entry_fill_vs_signal_pct';
  const tradeLines = state.trades.map((t, i) => [
    i + 1, t.pair,
    new Date(t.entryT * 1000).toISOString(), new Date(t.exitT * 1000).toISOString(),
    t.entryPrice, t.exitPrice, t.qty,
    t.entryNotional.toFixed(2), t.exitNotional.toFixed(2),
    t.feeIn.toFixed(2), t.feeOut.toFixed(2),
    t.pnl.toFixed(2), t.pnlPct.toFixed(4), t.days.toFixed(3), t.reason,
    t.spreadSlipCost.toFixed(2), (t.entryFillVsSignalPct ?? 0).toFixed(5)
  ].join(','));
  await fs.writeFile(path.join(OUT, 'trades.csv'), [tradeHeader, ...tradeLines].join('\n'));

  const eqHeader = 'time_wib,equity_idr,cash_idr,open_positions';
  const eqLines = daily.map((p) => [
    new Date(p.t * 1000).toLocaleString('sv-SE', { timeZone: 'Asia/Jakarta' }),
    p.equity.toFixed(2), p.cash.toFixed(2), p.open
  ].join(','));
  await fs.writeFile(path.join(OUT, 'equity_daily.csv'), [eqHeader, ...eqLines].join('\n'));

  const benchHeader = 'time_wib,equity_idr';
  const benchLines = benchDaily.map((p) => [
    new Date(p.t * 1000).toLocaleString('sv-SE', { timeZone: 'Asia/Jakarta' }),
    p.equity.toFixed(2)
  ].join(','));
  await fs.writeFile(path.join(OUT, 'benchmark_daily.csv'), [benchHeader, ...benchLines].join('\n'));

  await fs.writeFile(path.join(OUT, 'equity_bars.json'), JSON.stringify(
    state.equity.map((p) => ({ t: p.t, e: Math.round(p.equity) }))
  ));

  // log sinyal mentah (untuk mencocokkan bot vs backtest candle-demi-candle)
  const sigHeader = 'pair,candle_time_wib,candle_unix,close,ema_fast,ema_slow,ema_trend,atr,entry_signal,exit_signal';
  const sigLines = [];
  for (const p of pairs) {
    for (const r of p.rows) {
      if (r.t < start || r.t > end) continue;
      sigLines.push([
        p.symbol,
        new Date(r.t * 1000).toLocaleString('sv-SE', { timeZone: 'Asia/Jakarta' }),
        r.t, r.c, r.emaFast ?? '', r.emaSlow ?? '', r.emaTrend ?? '', r.atr ?? '',
        r.entrySignal ? 1 : 0, r.exitSignal ? 1 : 0
      ].join(','));
    }
  }
  await fs.writeFile(path.join(OUT, 'signals.csv'), [sigHeader, ...sigLines].join('\n'));

  console.log('\n=== HASIL BACKTEST ===');
  console.log(`Ekuitas akhir : Rp${finalEquity.toLocaleString('id-ID', { maximumFractionDigits: 0 })}`);
  console.log(`Total return  : ${summary.equity.totalReturnPct.toFixed(2)}%`);
  console.log(`CAGR          : ${summary.equity.cagrPct?.toFixed(2)}%`);
  console.log(`Max drawdown  : ${summary.equity.maxDrawdownPct.toFixed(2)}%`);
  console.log(`Trade tertutup: ${stats.trades} (win rate ${stats.winRate.toFixed(2)}%, PF ${stats.profitFactor.toFixed(2)})`);
  console.log(`Avg win/loss  : +${stats.avgWinPct.toFixed(2)}% / ${stats.avgLossPct.toFixed(2)}%`);
  console.log(`Porsi biaya   : ${summary.trades.costSharePct === null || summary.trades.costSharePct === undefined ? 'n/a' : summary.trades.costSharePct.toFixed(2) + '%'} dari laba kotor`);
  console.log(`Benchmark BTC : ${bench?.returnPct.toFixed(2)}%`);
  console.log(`Posisi terbuka: ${openPositions.length}`);
  console.log('\nOutput: ' + OUT + '/{summary.json,trades.csv,equity_daily.csv,benchmark_daily.csv,signals.csv}');
}

main().catch((e) => { console.error(e); process.exit(1); });
