// =====================================================================
// hitung_ulang.mjs - Menghasilkan ulang SEMUA angka dashboard dari log mentah.
// Sumber:
//   - data/backtest/*.csv          (hasil backtest mentah)
//   - data/forward_replay/*.csv    (replay backtest jendela forward)
//   - logs/<dir>/*.jsonl           (log mentah forward test dari bot)
// Output: data/recomputed.json (dipakai build_dashboard.mjs)
// =====================================================================
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { CONFIG } from '../lib/config.js';
import {
  totalReturnPct, cagrPct, maxDrawdown, tradeStats, costSharePct, maxConsecutiveLosses
} from '../lib/metrics.js';
import { dayKeyWIB } from '../lib/risk.js';

const ROOT = path.resolve('.');
const DATA = path.join(ROOT, 'data');

function arg(name, fallback) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}
const LOG_DIR_ARG = path.resolve(arg('log-dir', process.env.LOG_DIR || 'logs/export'));

async function exists(p) { try { await fs.access(p); return true; } catch { return false; } }

async function sha256File(p) {
  const buf = await fs.readFile(p);
  return { path: path.relative(ROOT, p).replaceAll('\\', '/'), bytes: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex') };
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length);
  if (!lines.length) return [];
  const header = lines[0].split(',');
  return lines.slice(1).map((line) => {
    const cells = line.split(',');
    const row = {};
    header.forEach((h, i) => { row[h] = cells[i]; });
    return row;
  });
}

/** "2026-11-07 12:00:00" (WIB) -> epoch ms */
function wibToMs(s) {
  return Date.parse(s.replace(' ', 'T') + '+07:00');
}

function num(v, d = 0) { const n = Number(v); return Number.isFinite(n) ? n : d; }

async function readJsonl(file) {
  if (!(await exists(file))) return [];
  const txt = await fs.readFile(file, 'utf8');
  return txt.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}

function metricsFromEquity(rows, valueKey = 'equity', opts = {}) {
  const series = rows
    .map((r) => ({ t: r.__t, equity: num(r[valueKey]) }))
    .filter((r) => Number.isFinite(r.t))
    .sort((a, b) => a.t - b.t);
  if (series.length < 1) return null;
  const initial = opts.initial ?? series[0].equity;
  const final = series.at(-1).equity;
  const startMs = opts.startMs ?? series[0].t;
  const days = (series.at(-1).t - startMs) / 86400000;
  const mdd = maxDrawdown(series);
  return {
    initial, final,
    totalReturnPct: totalReturnPct(initial, final),
    cagrPct: days > 0 ? cagrPct(initial, final, days) : null,
    mddPct: mdd.mddPct,
    points: series.length,
    days: Number(days.toFixed(3)),
    start: new Date(series[0].t).toISOString(),
    end: new Date(series.at(-1).t).toISOString()
  };
}

async function analyzeBacktest(dir, opts = {}) {
  const eqPath = path.join(dir, 'equity_daily.csv');
  const trPath = path.join(dir, 'trades.csv');
  if (!(await exists(eqPath)) || !(await exists(trPath))) return null;

  const eqRows = parseCsv(await fs.readFile(eqPath, 'utf8'))
    .map((r) => ({ ...r, __t: wibToMs(r.time_wib) }));
  const eq = metricsFromEquity(eqRows, 'equity_idr', {
    initial: CONFIG.startingEquityIdr,
    startMs: opts.startMs
  });

  const trades = parseCsv(await fs.readFile(trPath, 'utf8')).map((t) => ({
    pair: t.pair,
    entryT: Date.parse(t.entry_time),
    exitT: Date.parse(t.exit_time),
    pnl: num(t.pnl_idr),
    pnlPct: num(t.pnl_pct),
    feeIn: num(t.fee_in_idr),
    feeOut: num(t.fee_out_idr),
    spreadSlipCost: num(t.spread_slip_cost_idr)
  }));
  const stats = tradeStats(trades);
  const fees = trades.reduce((s, t) => s + t.feeIn + t.feeOut, 0);
  const spreadSlip = trades.reduce((s, t) => s + t.spreadSlipCost, 0);
  const totalCosts = fees + spreadSlip;

  let bench = null;
  const bPath = path.join(dir, 'benchmark_daily.csv');
  if (await exists(bPath)) {
    const bRows = parseCsv(await fs.readFile(bPath, 'utf8')).map((r) => ({ ...r, __t: wibToMs(r.time_wib) }));
    bench = metricsFromEquity(bRows, 'equity_idr', {
      initial: CONFIG.startingEquityIdr,
      startMs: opts.startMs
    });
  }

  return {
    ...eq,
    trades: stats.trades,
    winRate: stats.winRate,
    profitFactor: Number.isFinite(stats.profitFactor) ? stats.profitFactor : null,
    avgWinPct: stats.avgWinPct,
    avgLossPct: stats.avgLossPct,
    avgWinIdr: stats.avgWin,
    avgLossIdr: stats.avgLoss,
    feesIdr: fees,
    spreadSlipIdr: spreadSlip,
    totalCostsIdr: totalCosts,
    costSharePct: costSharePct(totalCosts, stats.grossProfit),
    maxConsecutiveLosses: maxConsecutiveLosses(trades),
    grossProfitIdr: stats.grossProfit,
    grossLossIdr: stats.grossLoss,
    sourceFiles: [
      await sha256File(eqPath), await sha256File(trPath),
      ...(await exists(bPath) ? [await sha256File(bPath)] : [])
    ],
    benchmark: bench ? {
      returnPct: bench.totalReturnPct,
      mddPct: bench.mddPct,
      final: bench.final
    } : null
  };
}

async function analyzeForward(dir) {
  const callsPath = path.join(dir, 'calls.jsonl');
  const ordersPath = path.join(dir, 'orders.jsonl');
  const equityPath = path.join(dir, 'equity.jsonl');
  const errorsPath = path.join(dir, 'errors.jsonl');

  if (!(await exists(callsPath)) && !(await exists(ordersPath))) return null;

  const calls = await readJsonl(callsPath);
  const orders = await readJsonl(ordersPath);
  const equityLog = await readJsonl(equityPath);
  const errorLog = await readJsonl(errorsPath);

  // deret ekuitas: pakai equity harian bila >=2 titik, jika tidak pakai equity per call
  const equityRows = equityLog.map((e) => ({ __t: Date.parse(e.at), equity: num(e.equity) }));
  const callEquity = calls.filter((c) => Number.isFinite(num(c.equity, NaN)))
    .map((c) => ({ __t: Date.parse(c.ts), equity: num(c.equity) }));
  const seriesUsed = equityRows.length >= 2 ? equityRows : callEquity;
  const eq = metricsFromEquity(seriesUsed);

  const sells = orders.filter((o) => o.side === 'sell' && Number.isFinite(o.pnl));
  const trades = sells.map((o) => ({
    pair: o.pair, pnl: o.pnl, pnlPct: o.pnlPct,
    feeIn: 0, feeOut: num(o.fee), spreadSlipCost: 0
  }));
  // fee masuk tercatat pada order buy yang berpasangan; jumlahkan semua fee order
  const fees = orders.reduce((s, o) => s + num(o.fee), 0);
  const spreadSlip = orders.reduce((s, o) => {
    if (!o.bestBid || !o.bestAsk) return s;
    const half = (o.bestAsk - o.bestBid) / 2;
    return s + half * num(o.qty);
  }, 0);
  const stats = tradeStats(trades);

  // uptime: panggilan terlaksana vs slot 4 jam sejak awal jendela forward.
  // Log lokal (belum deploy) akan menunjukkan uptime rendah; itu memang
  // keadaan sebenarnya, bukan angka produksi.
  const times = calls.map((c) => Date.parse(c.ts)).filter(Number.isFinite).sort((a, b) => a - b);
  const interval = CONFIG.tfMinutes * 60000;
  const FWD_START_MS = Date.parse('2026-11-05T12:00:00+07:00');
  const FWD_END_MS = Date.parse('2026-11-19T12:00:00+07:00');
  const windowEnd = Math.min(Date.now(), FWD_END_MS);
  const expected = Math.max(1, Math.floor((windowEnd - FWD_START_MS) / interval) + 1);
  const uptimePct = Math.min(100, (times.length / expected) * 100);

  return {
    available: true,
    sourceDir: path.relative(ROOT, dir).replaceAll('\\', '/'),
    equity: eq,
    points: seriesUsed.length,
    trades: stats.trades,
    winRate: stats.winRate,
    profitFactor: Number.isFinite(stats.profitFactor) ? stats.profitFactor : null,
    avgWinPct: stats.avgWinPct,
    avgLossPct: stats.avgLossPct,
    grossProfitIdr: stats.grossProfit,
    grossLossIdr: stats.grossLoss,
    feesIdr: fees,
    spreadSlipIdr: spreadSlip,
    totalCostsIdr: fees + spreadSlip,
    costSharePct: costSharePct(fees + spreadSlip, stats.grossProfit),
    orders: orders.length,
    buys: orders.filter((o) => o.side === 'buy').length,
    sells: sells.length,
    openPositions: calls.at(-1)?.positions ?? null,
    calls: calls.length,
    expectedCalls: expected,
    uptimePct,
    apiErrors: errorLog.length,
    killSwitchCalls: calls.filter((c) => c.killSwitch).length,
    firstCall: times.length ? new Date(times[0]).toISOString() : null,
    lastCall: times.length ? new Date(times.at(-1)).toISOString() : null,
    sourceFiles: [
      ...(await exists(callsPath) ? [await sha256File(callsPath)] : []),
      ...(await exists(ordersPath) ? [await sha256File(ordersPath)] : []),
      ...(await exists(equityPath) ? [await sha256File(equityPath)] : []),
      ...(await exists(errorsPath) ? [await sha256File(errorsPath)] : [])
    ]
  };
}

async function signalMatch(forwardDir, replayDir) {
  const botPath = path.join(forwardDir, 'signals.jsonl');
  const replayPath = path.join(replayDir, 'signals.csv');
  if (!(await exists(botPath)) || !(await exists(replayPath))) return null;

  const bot = await readJsonl(botPath);
  const replay = parseCsv(await fs.readFile(replayPath, 'utf8'));
  const find = new Map();
  for (const r of replay) {
    find.set(`${r.pair}|${r.candle_unix}`, {
      entry: r.entry_signal === '1', exit: r.exit_signal === '1'
    });
  }
  // satu candle bisa tercatat beberapa kali; ambil yang terakhir per pair|candle
  const botMap = new Map();
  for (const b of bot) botMap.set(`${b.pair}|${b.candleT}`, b);

  let compared = 0, matched = 0;
  const mismatches = [];
  for (const [key, b] of botMap) {
    const r = find.get(key);
    if (!r) continue;
    compared++;
    const ok = Boolean(b.entrySignal) === r.entry && Boolean(b.exitSignal) === r.exit;
    if (ok) matched++;
    else if (mismatches.length < 50) {
      mismatches.push({ key, bot: { entry: !!b.entrySignal, exit: !!b.exitSignal }, replay: r });
    }
  }
  const coveragePct = find.size ? (compared / find.size) * 100 : null;
  return {
    available: compared > 0,
    compared, matched,
    matchRatePct: compared ? (matched / compared) * 100 : null,
    coveragePct,
    botSignals: botMap.size,
    replaySignals: find.size,
    mismatches
  };
}

function diffCheck(name, a, b, tol = 0.01) {
  if (a == null || b == null) return { name, ok: null, note: 'tidak tersedia' };
  const ok = Math.abs(a - b) <= tol;
  return { name, ok, note: `recomputed=${Number(a).toFixed(4)} summary=${Number(b).toFixed(4)}` };
}

async function main() {
  const btDir = path.join(DATA, 'backtest');
  const replayDir = path.join(DATA, 'forward_replay');

  // pakai log export bila ada, jika tidak fallback ke log lokal
  let LOG_DIR = LOG_DIR_ARG;
  if (!(await exists(path.join(LOG_DIR, 'calls.jsonl')))) {
    const local = path.resolve('logs/local');
    if (await exists(path.join(local, 'calls.jsonl'))) {
      LOG_DIR = local;
      console.log(`[info] logs/export tidak ada, memakai ${path.relative(ROOT, local)}`);
    }
  }

  const backtest = await analyzeBacktest(btDir, { startMs: Date.parse(CONFIG.backtestStart) });
  const replay = await analyzeBacktest(replayDir);
  const forward = await analyzeForward(LOG_DIR);
  const match = forward ? await signalMatch(LOG_DIR, replayDir) : null;

  const summary = JSON.parse(await fs.readFile(path.join(btDir, 'summary.json'), 'utf8'));

  const checks = backtest ? [
    diffCheck('Total return backtest', backtest.totalReturnPct, summary.equity.totalReturnPct, 0.02),
    diffCheck('CAGR backtest', backtest.cagrPct, summary.equity.cagrPct, 0.02),
    diffCheck('Max drawdown backtest', backtest.mddPct, summary.equity.maxDrawdownPct, 0.02),
    diffCheck('Profit factor backtest', backtest.profitFactor, summary.trades.profitFactor, 0.01),
    diffCheck('Win rate backtest', backtest.winRate, summary.trades.winRate, 0.02),
    diffCheck('Jumlah trade backtest', backtest.trades, summary.trades.trades, 0)
  ] : [];

  const gap = forward && replay ? {
    forwardReturnPct: forward.equity?.totalReturnPct ?? null,
    replayReturnPct: replay.totalReturnPct,
    diffPct: (forward.equity?.totalReturnPct ?? 0) - replay.totalReturnPct,
    forwardTrades: forward.trades,
    replayTrades: replay.trades
  } : null;

  const out = {
    generatedAt: new Date().toISOString(),
    strategyVersion: CONFIG.version,
    timezone: 'Asia/Jakarta',
    backtest: backtest ? {
      ...backtest,
      periodDays: summary.period.days,
      universe: summary.universe,
      feeTakerPctPerSide: summary.costs.feeTakerPctPerSide,
      spreadSlippagePerPair: summary.costs.spreadSlippagePerPair
    } : null,
    benchmark: backtest?.benchmark ? {
      symbol: summary.benchmark.symbol,
      ...backtest.benchmark
    } : null,
    forward,
    replay: replay ? {
      available: true,
      totalReturnPct: replay.totalReturnPct,
      mddPct: replay.mddPct,
      cagrPct: replay.cagrPct,
      trades: replay.trades,
      winRate: replay.winRate,
      profitFactor: replay.profitFactor,
      avgWinPct: replay.avgWinPct,
      avgLossPct: replay.avgLossPct,
      costSharePct: replay.costSharePct,
      benchmark: replay.benchmark,
      start: replay.start,
      end: replay.end,
      note: 'REPLAY BACKTEST jendela forward, bukan forward test live'
    } : null,
    signalMatch: match,
    gap,
    ops: forward ? {
      calls: forward.calls,
      expectedCalls: forward.expectedCalls,
      uptimePct: forward.uptimePct,
      apiErrors: forward.apiErrors,
      killSwitchCalls: forward.killSwitchCalls,
      firstCall: forward.firstCall,
      lastCall: forward.lastCall
    } : null,
    checks
  };

  await fs.writeFile(path.join(DATA, 'recomputed.json'), JSON.stringify(out, null, 2));

  console.log('=== REKOM PUTASI DARI LOG MENTAH ===');
  if (out.backtest) {
    console.log(`Backtest: return ${out.backtest.totalReturnPct.toFixed(2)}%, CAGR ${out.backtest.cagrPct?.toFixed(2)}%, MDD ${out.backtest.mddPct.toFixed(2)}%, trade ${out.backtest.trades}, PF ${out.backtest.profitFactor?.toFixed(2)}`);
  }
  if (out.forward) {
    console.log(`Forward : return ${out.forward.equity?.totalReturnPct?.toFixed(2)}%, trade ${out.forward.trades}, call ${out.forward.calls}, uptime ${out.forward.uptimePct?.toFixed(1)}%`);
  } else {
    console.log('Forward : belum ada log (bot belum di-deploy / belum ada panggilan).');
  }
  if (out.signalMatch) {
    console.log(`Sinyal  : ${out.signalMatch.matched}/${out.signalMatch.compared} cocok (${out.signalMatch.matchRatePct?.toFixed(1)}%)`);
  }
  const failed = out.checks.filter((c) => c.ok === false);
  console.log(`Cek konsistensi: ${out.checks.length - failed.length}/${out.checks.length} lolos`);
  for (const f of failed) console.log('  ! ' + f.name + ' -> ' + f.note);
  console.log('\nDitulis: data/recomputed.json');
}

main().catch((e) => { console.error(e); process.exit(1); });
