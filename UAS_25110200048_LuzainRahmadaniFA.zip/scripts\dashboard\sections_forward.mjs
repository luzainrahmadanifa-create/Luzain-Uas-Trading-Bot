// Bagian 4-5 dashboard: Forward Test dan Validasi/Audit.
import { idr, idrShort, pct, pctRaw, num, cls, dateWib, dateShortWib } from './fmt.mjs';
import { esc } from './charts.mjs';

function card(title, sub, body, extra = '') {
  return '<div class="card ' + extra + '">' +
    '<div class="card-head"><h3>' + title + '</h3></div>' +
    (sub ? '<p class="sub">' + sub + '</p>' : '') + body + '</div>';
}
function kpi(label, value, hint, tone, color) {
  return '<div class="card kpi" style="--kc:' + (color || 'var(--accent)') + '">' +
    '<div class="label">' + label + '</div>' +
    '<div class="value ' + (tone || 'neutral') + '">' + value + '</div>' +
    '<div class="hint">' + hint + '</div></div>';
}
function okBadge(ok) {
  if (ok === true) return '<span class="badge ok">LOLOS</span>';
  if (ok === false) return '<span class="badge bad">GAGAL</span>';
  return '<span class="badge warn">N/A</span>';
}

export function renderForward(c) {
  const f = c.fwd || {};
  const r = c.replay || {};
  const eq = f.equity || {};
  const p = c.forwardProgress;
  const isLocalLog = !c.logs || String(c.logs.mode || '').indexOf('lokal') >= 0;
  const live = !isLocalLog && f.calls > 1;
  const statusClass = live ? 'warn' : 'bad';
  const statusTitle = live
    ? 'Forward test live sedang mengumpulkan data'
    : (isLocalLog ? 'Uji lokal — forward test live BELUM berjalan' : 'Forward test live BELUM berjalan');
  const statusText = live
    ? 'Bot sudah tercatat ' + num(f.calls) + ' kali dipanggil di produksi. Hasil masih sangat awal; belum ada kesimpulan.'
    : 'Sumber log: ' + (c.logs ? c.logs.mode : 'lokal') + '. Log yang ada berasal dari uji lokal (' + num(f.calls) + ' panggilan, ' + num(f.trades) + ' trade) dan belum ada deployment. Dashboard tidak mengisi angka forward dengan karangan.';

  const gapRows = [
    ['Return total', pct(f.equity ? f.equity.totalReturnPct : null), pct(r.totalReturnPct), pct(c.gap ? c.gap.diffPct : null) + ' pp'],
    ['Maximum drawdown', pct(f.equity ? f.equity.mddPct : null), pct(r.mddPct), num(((f.equity ? f.equity.mddPct : 0) - (r.mddPct || 0)), 2) + ' pp'],
    ['Jumlah trade', num(f.trades), num(r.trades), num((f.trades || 0) - (r.trades || 0))],
    ['Win rate', pctRaw(f.winRate), pctRaw(r.winRate), num((f.winRate || 0) - (r.winRate || 0), 2) + ' pp'],
    ['Profit factor', num(f.profitFactor, 2), num(r.profitFactor, 2), num((f.profitFactor || 0) - (r.profitFactor || 0), 2)],
    ['Porsi biaya', pctRaw(f.costSharePct), pctRaw(r.costSharePct), 'n/a']
  ].map((x) => '<tr><td>' + x[0] + '</td><td class="num">' + x[1] + '</td><td class="num">' + x[2] + '</td><td class="num">' + x[3] + '</td></tr>').join('');

  const opsRows = [
    ['Panggilan terjadwal (estimasi)', num(c.ops ? c.ops.expectedCalls : 0)],
    ['Panggilan terlaksana', num(c.ops ? c.ops.calls : 0)],
    ['Uptime', pctRaw(c.ops ? c.ops.uptimePct : null, 1)],
    ['Error API / fetch', num(c.ops ? c.ops.apiErrors : 0)],
    ['Kill switch aktif', num(c.ops ? c.ops.killSwitchCalls : 0) + ' panggilan'],
    ['Panggilan pertama', dateWib(c.ops ? c.ops.firstCall : null)],
    ['Panggilan terakhir', dateWib(c.ops ? c.ops.lastCall : null)]
  ].map((x) => '<tr><td>' + x[0] + '</td><td class="num">' + x[1] + '</td></tr>').join('');

  const sourceFiles = (f.sourceFiles || []).map((s) =>
    '<tr><td class="mono">' + s.path + '</td><td class="num">' + num(s.bytes) + '</td><td class="hash">' + s.sha256 + '</td></tr>').join('');

  const match = c.match;
  const mismatchRows = match && match.mismatches && match.mismatches.length
    ? match.mismatches.map((m) => '<tr><td class="mono">' + esc(m.key) + '</td><td>bot: ' + JSON.stringify(m.bot) + '</td><td>replay: ' + JSON.stringify(m.replay) + '</td></tr>').join('')
    : '';

  return '' +
    '<section class="tab-panel" id="panel-forward" data-panel="forward">' +
    '<div class="banner ' + statusClass + '">' +
    '<div><h3>' + statusTitle + '</h3><p>' + statusText + '</p></div>' +
    '<div class="big">' + num(p.pct, 0) + '%<div class="note tiny">' + num(p.daysElapsed, 1) + ' / ' + p.daysTotal + ' hari</div></div>' +
    '</div>' +

    '<div class="grid g4 mt16">' +
    kpi(isLocalLog ? 'Return uji lokal' : 'Return forward (live)', pct(eq.totalReturnPct), 'Dari ' + idrShort(eq.initial || c.bt.initial) + ' · bukan hasil final', 'neutral', 'var(--muted)') +
    kpi(isLocalLog ? 'Max drawdown uji lokal' : 'Max drawdown forward', pct(eq.mddPct), 'Mark-to-market best bid', 'neutral', 'var(--muted)') +
    kpi('Trade forward', num(f.trades), num(f.orders) + ' order simulasi', 'neutral', 'var(--muted)') +
    kpi('Uptime', pctRaw(c.ops ? c.ops.uptimePct : null, 0), num(c.ops ? c.ops.calls : 0) + ' panggilan tercatat', 'neutral', 'var(--accent)') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Jadwal & status jendela',
      'Sesuai PDF: freeze Kamis 5 Nov 2026 12.00 WIB, forward test 14 hari sampai 19 Nov 2026 12.00 WIB.',
      '<div class="kv">' +
      '<dt>Freeze date</dt><dd><b>' + dateWib(c.frozenAt) + '</b></dd>' +
      '<dt>Mulai forward</dt><dd>' + dateWib(p.startIso) + '</dd>' +
      '<dt>Selesai forward</dt><dd>' + dateWib(p.endIso) + '</dd>' +
      '<dt>Dashboard dibuat</dt><dd>' + dateWib(c.generatedAt) + '</dd>' +
      '<dt>Progress waktu</dt><dd>' + num(p.daysElapsed, 1) + ' dari ' + p.daysTotal + ' hari (' + num(p.pct, 1) + '%)</dd>' +
      '</div>' +
      '<div class="bar-track mt16"><div class="bar-fill ' + (p.pct < 100 ? 'warn' : '') + '" style="width:' + Math.max(2, Math.min(100, p.pct)).toFixed(1) + '%"></div></div>' +
      '<p class="note tiny mt8">Data candle yang tersedia untuk replay berhenti di <b>' + dateWib(r.end) + '</b>. Sisa jendela belum terjadi saat file ini dibuat.</p>') +
    card('Panel operasional',
      'Angka dari log panggilan bot. Uptime = terlaksana / terjadwal (estimasi slot 4 jam).',
      '<div class="table-wrap"><table><tbody>' + opsRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Sumber log: <span class="mono">' + esc(f.sourceDir || 'logs/local') + '</span>. Setelah deploy, jalankan <span class="mono">scripts/export_logs.mjs</span> lalu <span class="mono">scripts/hitung_ulang.mjs</span> agar angka berasal dari log produksi.</p>') +
    '</div>' +

    '<h2 class="section-title">Perbandingan pada jendela yang sama <small>replay backtest vs forward live</small></h2>' +
    '<div class="grid g2">' +
    card('Forward test live (log bot)',
      'Apa yang benar-benar tercatat. Jika kosong, berarti belum ada.',
      '<div class="kv">' +
      '<dt>Ekuitas awal</dt><dd>' + idr(eq.initial || c.bt.initial) + '</dd>' +
      '<dt>Ekuitas akhir</dt><dd>' + idr(eq.final) + '</dd>' +
      '<dt>Return total</dt><dd class="' + cls(eq.totalReturnPct) + '">' + pct(eq.totalReturnPct) + '</dd>' +
      '<dt>Max drawdown</dt><dd>' + pct(eq.mddPct) + '</dd>' +
      '<dt>Trade tertutup</dt><dd>' + num(f.trades) + '</dd>' +
      '<dt>Profit factor / win rate</dt><dd>' + num(f.profitFactor, 2) + ' / ' + pctRaw(f.winRate) + '</dd>' +
      '<dt>Avg win / avg loss</dt><dd>' + pct(f.avgWinPct) + ' / ' + pct(f.avgLossPct) + '</dd>' +
      '<dt>Porsi biaya</dt><dd>' + pctRaw(f.costSharePct) + '</dd>' +
      '<dt>Posisi terbuka</dt><dd>' + num(f.openPositions) + '</dd>' +
      '</div>') +
    card('Replay backtest jendela forward',
      'BUKAN forward test live. Backtest dijalankan ulang dengan candle yang sama pada jendela 5–19 Nov (data tersedia sampai 7 Nov).',
      '<div class="kv">' +
      '<dt>Periode data</dt><dd>' + dateWib(r.start) + ' &rarr; ' + dateWib(r.end) + '</dd>' +
      '<dt>Return total</dt><dd>' + pct(r.totalReturnPct) + '</dd>' +
      '<dt>Benchmark BTC/IDR</dt><dd>' + pct(r.benchmark ? r.benchmark.returnPct : null) + ' (MDD ' + pct(r.benchmark ? r.benchmark.mddPct : null) + ')</dd>' +
      '<dt>Max drawdown</dt><dd>' + pct(r.mddPct) + '</dd>' +
      '<dt>Trade tertutup</dt><dd>' + num(r.trades) + '</dd>' +
      '<dt>Profit factor / win rate</dt><dd>' + num(r.profitFactor, 2) + ' / ' + pctRaw(r.winRate) + '</dd>' +
      '<dt>Avg win / avg loss</dt><dd>' + pct(r.avgWinPct) + ' / ' + pct(r.avgLossPct) + '</dd>' +
      '<dt>Porsi biaya</dt><dd>' + pctRaw(r.costSharePct) + '</dd>' +
      '</div>' +
      '<p class="note tiny mt8">CAGR tidak ditampilkan untuk jendela 14 hari karena tidak bermakna (sesuai PDF).</p>') +
    '</div>' +

    '<div class="card mt16">' +
    '<div class="card-head"><h3>Gap backtest vs forward</h3><span class="badge warn">belum final</span></div>' +
    '<p class="sub">Selisih pada jendela yang sama. Karena forward baru berjalan ' + num(p.daysElapsed, 1) + ' hari dan 0 trade, gap ini <b>belum bisa</b> dipakai untuk menyimpulkan apa pun.</p>' +
    '<div class="table-wrap"><table><thead><tr><th>Metrik</th><th class="num">Forward live</th><th class="num">Replay backtest</th><th class="num">Selisih</th></tr></thead><tbody>' + gapRows + '</tbody></table></div>' +
    '<p class="note tiny mt8">Setelah 19 Nov: ekspor log produksi, jalankan ulang replay dengan data penuh, lalu bandingkan. Selisih fill per trade dijelaskan dengan spread, slippage, dan keterlambatan jadwal cron.</p>' +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Kecocokan sinyal candle-demi-candle',
      'Target rubrik: 100%. Pembanding adalah signals.csv dari replay dengan fungsi sinyal yang sama.',
      '<div class="grid g3" style="gap:10px">' +
      '<div><div class="label note tiny">Dibandingkan</div><div style="font-size:22px;font-weight:800">' + num(match ? match.compared : 0) + '</div></div>' +
      '<div><div class="label note tiny">Cocok</div><div style="font-size:22px;font-weight:800;color:#4ade80">' + num(match ? match.matched : 0) + '</div></div>' +
      '<div><div class="label note tiny">Match rate</div><div style="font-size:22px;font-weight:800;color:#4ade80">' + pctRaw(match ? match.matchRatePct : null, 1) + '</div></div>' +
      '</div>' +
      '<div class="table-wrap mt16"><table><tbody>' +
      '<tr><td>Cakupan candle bot vs replay</td><td class="num">' + pctRaw(match ? match.coveragePct : null, 1) + '</td></tr>' +
      '<tr><td>Sinyal bot (pair-candle unik)</td><td class="num">' + num(match ? match.botSignals : 0) + '</td></tr>' +
      '<tr><td>Sinyal replay (pair-candle)</td><td class="num">' + num(match ? match.replaySignals : 0) + '</td></tr>' +
      '</tbody></table></div>' +
      '<p class="note tiny mt8">Cakupan rendah wajar: bot baru 1 tick (5 pair &times; 1 candle) sedangkan replay mencakup 12 candle &times; 5 pair. Setelah bot berjalan penuh, cakupan akan mendekati 100%.</p>' +
      (mismatchRows ? '<div class="table-wrap mt8"><table><thead><tr><th>Pair|candle</th><th>Bot</th><th>Replay</th></tr></thead><tbody>' + mismatchRows + '</tbody></table></div>' : '<p class="note tiny mt8">Tidak ada ketidakcocokan sinyal.</p>')) +
    card('Log mentah yang tersedia',
      'Setiap angka di atas harus bisa ditelusuri ke file ini.',
      '<div class="table-wrap"><table><thead><tr><th>File</th><th class="num">Byte</th><th>SHA-256</th></tr></thead><tbody>' + sourceFiles + '</tbody></table></div>' +
      '<p class="note tiny mt8">Log ditulis append-only (JSONL). Satu baris = satu kejadian. File state tidak memuat secret.</p>' +
      '<details class="mt8"><summary>Lihat ringkasan state terakhir</summary><div class="code-box mt8">' + esc(JSON.stringify(c.logs.state || {}, null, 2)) + '</div></details>') +
    '</div>' +

    '<h2 class="section-title">Yang harus dilakukan agar forward test sah <small>checklist jujur</small></h2>' +
    '<div class="grid g2">' +
    card('Urutan deploy & pengumpulan',
      'Tidak ada satu pun langkah ini yang bisa digantikan dengan angka karangan.',
      '<ol class="rule-list">' +
      '<li><b>Deploy</b> ke Vercel dengan storage Upstash dan <span class="mono">CRON_SECRET</span>.</li>' +
      '<li><b>Uji koneksi</b>: panggil <span class="mono">/api/tick</span> manual, pastikan 5 pasangan OK.</li>' +
      '<li><b>Jadwalkan</b> GitHub Actions tiap jam (4 jam timeframe; panggilan ekstra idempoten).</li>' +
      '<li><b>Biarkan 14 hari</b> sampai 19 Nov 12.00 WIB tanpa mengubah aturan/parameter/universe.</li>' +
      '<li><b>Ekspor log</b> dengan <span class="mono">scripts/export_logs.mjs</span>.</li>' +
      '<li><b>Jalankan ulang</b> <span class="mono">hitung_ulang.mjs</span> dan <span class="mono">build_dashboard.mjs</span>.</li>' +
      '<li><b>Ganti</b> angka forward di dashboard secara otomatis dari log, bukan diedit manual.</li>' +
      '</ol>') +
    card('Perintah deploy',
      'Semua perintah dijalankan dari folder proyek.',
      '<div class="code-box">npm i -g vercel\nvercel login\nvercel link\n\nvercel env add CRON_SECRET production\nvercel env add UPSTASH_REDIS_REST_URL production\nvercel env add UPSTASH_REDIS_REST_TOKEN production\nvercel env add KILL_SWITCH production   # isi 0\n\nvercel --prod\n\n# uji manual\ncurl -H "Authorization: Bearer $CRON_SECRET" https://<project>.vercel.app/api/tick</div>' +
      '<button class="btn mt8" data-copy="vercel --prod" type="button">Salin perintah deploy</button>' +
      '<p class="note tiny mt8">Vercel Cron paket Hobby hanya 1&times;/hari. Karena itu penjadwal utama memakai GitHub Actions (<span class="mono">.github/workflows/tick.yml</span>) yang memanggil endpoint tiap jam.</p>') +
    '</div>' +
    '</section>';
}

export function renderValidasi(c) {
  const checksRows = c.checks.map((x) =>
    '<tr><td>' + x.name + '</td><td>' + okBadge(x.ok) + '</td><td class="mono note">' + esc(x.note) + '</td></tr>').join('');

  const sourceRows = (c.bt.sourceFiles || []).map((s) =>
    '<tr><td class="mono">' + s.path + '</td><td class="num">' + num(s.bytes) + '</td><td class="hash">' + s.sha256 + '</td></tr>').join('');

  const qualityRows = c.quality.map((q) =>
    '<tr><td><span class="pair-tag">' + q.symbol + '</span></td><td class="num">' + num(q.count) + '</td><td class="num">' + num(q.gaps) + '</td><td class="num">' + num(q.dupes) + '</td><td class="num">' + num(q.zeros) + '</td><td>' + (q.issues.length ? '<span class="badge warn">' + esc(q.issues.join('; ')) + '</span>' : '<span class="badge ok">bersih</span>') + '</td></tr>').join('');

  const cand = (c.universe.allCandidates || []).slice().sort((a, b) => (b.turnover30d || 0) - (a.turnover30d || 0));
  const universeRows = cand.map((u) => {
    const picked = c.universe.universe.some((x) => x.symbol === u.symbol);
    return '<tr' + (picked ? ' style="background:rgba(34,211,238,.05)"' : '') + '><td><span class="pair-tag">' + u.symbol + '</span>' + (picked ? ' <span class="badge info">dipakai</span>' : '') + '</td>' +
      '<td class="num">' + num(u.days) + '</td>' +
      '<td class="num">' + num((u.coverage || 0) * 100, 0) + '%</td>' +
      '<td class="num">' + (u.turnover30d ? idrShort(u.turnover30d) : '-') + '</td>' +
      '<td class="num">' + (u.avgDailyTurnoverIdr ? idrShort(u.avgDailyTurnoverIdr) : '-') + '</td>' +
      '<td>' + (u.ok ? '<span class="badge ok">layak</span>' : '<span class="badge bad">tidak</span>') + '</td></tr>';
  }).join('');

  const costRows = Object.entries(c.costs.perPair || {}).map(([pair, v]) =>
    '<tr><td>' + pair + '</td><td class="num">' + num(v.snapshots) + '</td><td class="num">' + num(v.medianSpreadBps, 3) + '</td><td class="num">' + num(v.medianBuySlippageBps, 3) + '</td><td class="num">' + num(v.medianSellSlippageBps, 3) + '</td><td class="num">' + num(v.slippageBps, 3) + '</td></tr>').join('');

  const instrRows = Object.entries(c.instruments).map(([id, v]) =>
    '<tr><td><span class="pair-tag">' + id.toUpperCase() + '</span></td><td class="num">' + num(v.tradeFeePercentTaker, 2) + '%</td><td class="num">' + idr(v.tradeMinBaseCurrencyIdr) + '</td><td class="num mono">' + v.quantityIncrement + '</td><td class="num mono">' + (v.priceIncrement || '-') + '</td></tr>').join('');

  return '' +
    '<section class="tab-panel" id="panel-validasi" data-panel="validasi">' +
    '<div class="banner ' + (c.checksPass === c.checks.length ? 'ok' : 'bad') + '">' +
    '<div><h3>Audit hitung ulang: ' + c.checksPass + ' / ' + c.checks.length + ' cek lolos</h3>' +
    '<p><span class="mono">scripts/hitung_ulang.mjs</span> membaca CSV/JSONL mentah dan menghitung ulang semua metrik. Dashboard ini memakai output <span class="mono">data/recomputed.json</span>, bukan angka yang diketik manual.</p></div>' +
    '<div class="big">' + (c.checksPass === c.checks.length ? '100%' : num(c.checksPass / c.checks.length * 100, 0) + '%') + '</div>' +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Cek konsistensi angka',
      'Bandingkan hasil hitung ulang dari CSV dengan summary.json yang ditulis mesin backtest.',
      '<div class="table-wrap"><table><thead><tr><th>Cek</th><th>Status</th><th>Nilai</th></tr></thead><tbody>' + checksRows + '</tbody></table></div>') +
    card('Integritas pembekuan aturan',
      'Hash file konfigurasi dibandingkan dengan yang tercatat di data/freeze.json.',
      '<div class="kv">' +
      '<dt>Strategy version</dt><dd>' + c.version + '</dd>' +
      '<dt>Freeze date</dt><dd><b>' + dateWib(c.frozenAt) + '</b></dd>' +
      '<dt>Hash dicatat</dt><dd>' + dateWib(c.freeze.recordedAt) + '</dd>' +
      '<dt>Hash config sekarang</dt><dd class="hash">' + c.configHash + '</dd>' +
      '<dt>Status hash</dt><dd>' + (c.configHashMatches ? '<span class="badge ok">COCOK</span>' : '<span class="badge bad">BERUBAH</span>') + '</dd>' +
      '<dt>Commit git</dt><dd>' + (c.freeze.git && c.freeze.git.commit ? '<span class="mono">' + c.freeze.git.commit + '</span>' : '<span class="badge warn">belum ada (git tidak tersedia)</span>') + '</dd>' +
      '</div>' +
      '<p class="note tiny mt8">' + esc(c.freeze.integrityNote || c.freeze.note || '') + '</p>' +
      '<p class="note tiny mt8">File yang di-freeze: ' + (c.freeze.files || []).map((f) => f.file).join(', ') + '.</p>') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Mutu data candle',
      'Diunduh dari <span class="mono">history_v2</span> (tf=240) pada ' + dateWib(c.qualityGeneratedAt) + '.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th class="num">Bar</th><th class="num">Gap</th><th class="num">Duplikat</th><th class="num">Nol</th><th>Status</th></tr></thead><tbody>' + qualityRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Jumlah bar per pair ' + num(c.quality[0] ? c.quality[0].count : 0) + '. Rentang: ' + dateShortWib(c.quality[0] ? c.quality[0].first : null) + ' – ' + dateShortWib(c.quality[0] ? c.quality[0].last : null) + '. Tidak ada gap pada jendela indikator.</p>') +
    card('Sumber file backtest',
      'File mentah yang dihitung ulang. SHA-256 membuktikan isi tidak berubah setelah audit.',
      '<div class="table-wrap"><table><thead><tr><th>File</th><th class="num">Byte</th><th>SHA-256</th></tr></thead><tbody>' + sourceRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Arsip lengkap ada di ZIP deliverable: <span class="mono">data/backtest/</span>, <span class="mono">data/forward_replay/</span>, <span class="mono">logs/</span>.</p>') +
    '</div>' +

    '<h2 class="section-title">Pemilihan universe <small>point-in-time, bukan likuiditas hari ini</small></h2>' +
    '<div class="card">' +
    '<p class="sub">' + esc(c.universe.method || '') + ' Kandidat: ' + cand.length + ' aset besar yang sudah terdaftar sebelum November 2023.</p>' +
    '<div class="table-wrap"><table><thead><tr><th>Pair</th><th class="num">Hari data</th><th class="num">Coverage</th><th class="num">Turnover 30 hari</th><th class="num">Rata-rata/hari</th><th>Status</th></tr></thead><tbody>' + universeRows + '</tbody></table></div>' +
    '<p class="note tiny mt8">Cutoff: ' + (c.universe.cutoff || '2023-11-07') + '. Turnover diukur 1–31 Okt 2023, sebelum periode backtest dimulai. Dengan begitu aset yang baru populer belakangan tidak otomatis masuk universe.</p>' +
    '</div>' +

    '<h2 class="section-title">Pengukuran biaya & instrumen <small>sumber dan tanggal akses</small></h2>' +
    '<div class="grid g2">' +
    card('Spread & slippage terukur',
      'Order referensi ' + idr(c.costs.referenceOrderIdr || 25000000) + '. ' + num(Object.values(c.costs.perPair || {}).reduce((s, x) => s + x.snapshots, 0)) + ' observasi dari ' + (Object.values(c.costs.perPair || {})[0] ? dateWib(Object.values(c.costs.perPair)[0].firstSnapshot) : '-') + '.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th class="num">Snapshot</th><th class="num">Spread bps</th><th class="num">Slip beli</th><th class="num">Slip jual</th><th class="num">Slip dipakai</th></tr></thead><tbody>' + costRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Metode: median spread (ask&minus;bid)/mid dan slippage dari menyapu level order book. Backtest membebankan setengah spread + slippage pada setiap sisi.</p>' +
      '<p class="note tiny mt8"><b>Keterbatasan:</b> snapshot baru diambil pada satu hari (3 putaran) pada 7 Nov 2026, bukan 3&times; sehari selama berhari-hari. Ini dinyatakan terbuka di refleksi.</p>') +
    card('Fee & minimum order',
      'Sumber: /api/pairs dan halaman resmi Indodax, diakses 7 Nov 2026.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th class="num">Fee taker</th><th class="num">Min order (API)</th><th class="num">Qty increment</th><th class="num">Price increment</th></tr></thead><tbody>' + instrRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Fee taker API: 0,20%. Halaman resmi juga 0,20%; dipakai angka yang lebih mahal. Minimum order yang dipakai di kode: <b>Rp25.000</b> (mode Pro), lebih ketat dari Rp10.000 di API.</p>' +
      '<p class="note tiny mt8">Sumber: <a href="https://indodax.com/api/pairs" target="_blank" rel="noopener">indodax.com/api/pairs</a> · <a href="https://indodax.com/api/price_increments" target="_blank" rel="noopener">/api/price_increments</a> · <a href="https://help.indodax.com" target="_blank" rel="noopener">help.indodax.com — Rincian Biaya Transaksi</a>.</p>') +
    '</div>' +

    '<h2 class="section-title">Metodologi &amp; batasan <small>yang perlu diketahui auditor</small></h2>' +
    '<div class="grid g2">' +
    card('Keputusan metodologis',
      'Ringkas, bisa diverifikasi di kode.',
      '<ul class="rule-list">' +
      '<li><b>Candle tertutup saja.</b> Bar dengan <span class="mono">Time + durasi &gt; server_time</span> dibuang sebelum sinyal dihitung.</li>' +
      '<li><b>Eksekusi backtest</b> di open bar berikutnya setelah sinyal, lalu disesuaikan setengah spread + slippage. Bukan mid, bukan close.</li>' +
      '<li><b>Eksekusi bot</b> menyapu level ask (beli) dan bid (jual) dari order book live; harga rata-rata tertimbang.</li>' +
      '<li><b>Equity</b> posisi terbuka dinilai di best bid. Equity harian dicatat pada panggilan pertama setelah 00.00 WIB.</li>' +
      '<li><b>Idempotency</b> per pair+candle; panggilan kedua tidak membeli lagi.</li>' +
      '<li><b>Universe</b> dipilih dari turnover 30 hari yang berakhir 1 Nov 2023 (point-in-time).</li>' +
      '</ul>') +
    card('Batasan yang diakui',
      'Tidak disembunyikan; ini memengaruhi tafsir angka.',
      '<ul class="rule-list">' +
      '<li><b>Forward test belum selesai.</b> Per ' + dateWib(c.generatedAt) + ' baru ' + num(c.forwardProgress.daysElapsed, 1) + ' hari dari 14 hari dan belum ada deployment.</li>' +
      '<li><b>Pemilihan parameter in-sample.</b> Varian dipilih pada data 2023–2026 yang sama; belum ada out-of-sample murni. Backtest final dipotong sebelum freeze, tetapi eksplorasi parameter tetap melihat data hingga 7 Nov.</li>' +
      '<li><b>Snapshot order book terbatas.</b> Satu hari, 3 putaran; spread/slippage bisa berubah pada jam sepi atau saat volatil.</li>' +
      '<li><b>Tidak ada antrean order.</b> Dry run mengasumsikan order taker langsung tereksekusi pada level book saat itu; di pasar nyata bisa partial fill.</li>' +
      '<li><b>Biaya pendanaan/withdrawal tidak relevan</b> karena tidak ada transfer aset nyata.</li>' +
      '</ul>') +
    '</div>' +

    '<div class="card mt16">' +
    '<div class="card-head"><h3>Perintah reproduksi</h3><button class="btn" data-copy="node scripts/hitung_ulang.mjs && node scripts/build_dashboard.mjs" type="button">Salin</button></div>' +
    '<p class="sub">Semua dari folder proyek. Butuh Node.js &ge; 20 (tanpa dependensi npm).</p>' +
    '<div class="code-box"># 1. pilih universe (point-in-time)\nnode scripts/select_universe.mjs\n\n# 2. unduh candle asli Indodax (di laptop, bukan di Vercel)\nnode scripts/fetch_history.mjs --tf 240 --from 2023-10-15 --to 2026-11-07\n\n# 3. ukur spread & slippage dari snapshot order book\nnode scripts/snapshot_orderbook.mjs   # minimal 3x sehari saat persiapan\nnode scripts/measure_costs.mjs\n\n# 4. backtest 3 tahun + uji ketahanan\nnode scripts/backtest.mjs\nnode scripts/run_variants.mjs\n\n# 5. replay jendela forward (pembanding, bukan live)\nnode scripts/replay_forward.mjs\n\n# 6. hitung ulang SEMUA angka dari log mentah\nnode scripts/hitung_ulang.mjs\n\n# 7. buat dashboard offline\nnode scripts/build_dashboard.mjs</div>' +
    '</div>' +
    '</section>';
}
