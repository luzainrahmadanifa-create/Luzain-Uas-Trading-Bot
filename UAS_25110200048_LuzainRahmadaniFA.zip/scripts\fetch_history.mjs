// Unduh candle historis asli Indodax untuk backtest (dijalankan di laptop, bukan di Vercel).
// Contoh:
//   node scripts/fetch_history.mjs --tf 60 --from 2023-10-28 --to 2026-11-07
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { CONFIG, TF_SECONDS } from '../lib/config.js';
import { getCandles, getServerTime } from '../lib/indodax.js';

function arg(name, fallback) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

const tf = String(arg('tf', CONFIG.timeframe));
const fromIso = arg('from', CONFIG.backtestStart);
const toIso = arg('to', new Date().toISOString());
const symbolsArg = arg('symbols', CONFIG.universe.map((u) => u.symbol).join(','));
const symbols = symbolsArg.split(',').map((s) => s.trim()).filter(Boolean);

const fromSec = Math.floor(Date.parse(fromIso) / 1000);
const toSec = Math.floor(Date.parse(toIso) / 1000);
const dur = TF_SECONDS[tf];
const outDir = path.resolve('data/candles');

function audit(symbol, candles) {
  const issues = [];
  const expected = Math.floor((toSec - fromSec) / dur);
  if (candles.length < expected * 0.9) issues.push(`hanya ${candles.length}/${expected} bar`);
  let gaps = 0, zeros = 0, dupes = 0;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (!(c.o > 0 && c.h > 0 && c.l > 0 && c.c > 0)) zeros++;
    if (c.v < 0) zeros++;
    if (i > 0) {
      if (c.t === candles[i - 1].t) dupes++;
      else if (c.t - candles[i - 1].t > dur * 1.5) gaps++;
    }
  }
  if (gaps) issues.push(`${gaps} gap`);
  if (zeros) issues.push(`${zeros} bar harga/volume tidak valid`);
  if (dupes) issues.push(`${dupes} duplikat`);
  return {
    symbol, count: candles.length, expected,
    first: candles[0] ? new Date(candles[0].t * 1000).toISOString() : null,
    last: candles[candles.length - 1] ? new Date(candles[candles.length - 1].t * 1000).toISOString() : null,
    gaps, zeros, dupes, issues
  };
}

async function main() {
  await fs.mkdir(outDir, { recursive: true });
  const serverTime = await getServerTime();
  console.log(`Server Indodax: ${new Date(serverTime * 1000).toISOString()}`);
  console.log(`Mengunduh ${symbols.length} pasangan, tf=${tf}, ${fromIso} .. ${toIso}\n`);

  const quality = [];
  for (const symbol of symbols) {
    process.stdout.write(`- ${symbol} ... `);
    const t0 = Date.now();
    const candles = await getCandles(symbol, tf, fromSec, toSec);
    const meta = {
      symbol, tf, from: fromIso, to: toIso,
      fetchedAt: new Date().toISOString(),
      serverTime,
      count: candles.length,
      candles
    };
    await fs.writeFile(path.join(outDir, `${symbol}_${tf}.json`), JSON.stringify(meta));
    const q = audit(symbol, candles);
    quality.push(q);
    console.log(`${candles.length} bar (${((Date.now() - t0) / 1000).toFixed(1)}s)${q.issues.length ? ' -> ' + q.issues.join('; ') : ' OK'}`);
  }

  await fs.writeFile(path.join(outDir, 'quality.json'), JSON.stringify({
    generatedAt: new Date().toISOString(), tf, from: fromIso, to: toIso, quality
  }, null, 2));
  console.log('\nSelesai. Ringkasan mutu data: data/candles/quality.json');
}

main().catch((e) => { console.error(e); process.exit(1); });
