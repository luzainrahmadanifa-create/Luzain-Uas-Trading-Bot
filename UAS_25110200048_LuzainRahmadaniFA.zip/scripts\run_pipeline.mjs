// =====================================================================
// run_pipeline.mjs - jalankan rantai reproduksi yang tidak butuh
// keputusan manual. Semua langkah memakai Node yang sama (process.execPath).
//
//   node scripts/run_pipeline.mjs                  # backtest + varian + replay + audit + dashboard
//   node scripts/run_pipeline.mjs --with-data      # + pilih universe, unduh candle & instrumen
//   node scripts/run_pipeline.mjs --with-snapshots # + snapshot order book & ukur biaya
//   node scripts/run_pipeline.mjs --all            # semua di atas
//
// Catatan: freeze TIDAK dijalankan otomatis. Pembekuan adalah tindakan
// sadar; jalankan `node scripts/freeze.mjs --force` hanya bila memang
// ingin mencatat ulang hash setelah perubahan kode yang sah.
// =====================================================================
import { spawnSync } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const args = new Set(process.argv.slice(2));
const ALL = args.has('--all');
const WITH_DATA = ALL || args.has('--with-data');
const WITH_SNAPSHOTS = ALL || args.has('--with-snapshots');

async function exists(p) {
  try { await fs.access(path.resolve(p)); return true; } catch { return false; }
}

function step(label, script, extra = []) {
  process.stdout.write(`\n=== ${label} ===\n`);
  const r = spawnSync(process.execPath, [script, ...extra], { stdio: 'inherit' });
  if (r.status !== 0) {
    console.error(`\nGAGAL: ${script} (exit ${r.status})`);
    process.exit(r.status || 1);
  }
}

async function main() {
  const started = Date.now();
  console.log('Pipeline UAS Algorithmic Trading');
  console.log('Node: ' + process.version);
  console.log('Mode: ' + (ALL ? 'all' : (WITH_DATA || WITH_SNAPSHOTS ? 'sebagian' : 'offline standar')));

  if (WITH_DATA) {
    step('Pilih universe (point-in-time)', 'scripts/select_universe.mjs');
    step('Unduh candle 4 jam', 'scripts/fetch_history.mjs', ['--tf', '240', '--from', '2023-10-15', '--to', '2026-11-07']);
    step('Unduh instrumen', 'scripts/fetch_instruments.mjs');
  } else if (!(await exists('data/candles/quality.json'))) {
    console.error('data/candles/quality.json tidak ada. Jalankan dengan --with-data lebih dulu.');
    process.exit(1);
  }

  if (WITH_SNAPSHOTS) {
    step('Snapshot order book', 'scripts/snapshot_orderbook.mjs');
    step('Ukur biaya', 'scripts/measure_costs.mjs');
  } else if (!(await exists('data/costs.json'))) {
    console.error('data/costs.json tidak ada. Jalankan dengan --with-snapshots lebih dulu.');
    process.exit(1);
  }

  step('Backtest 3 tahun', 'scripts/backtest.mjs');
  step('Uji ketahanan parameter', 'scripts/run_variants.mjs');
  step('Replay jendela forward', 'scripts/replay_forward.mjs');
  step('Hitung ulang dari log mentah', 'scripts/hitung_ulang.mjs');
  step('Dashboard offline', 'scripts/build_dashboard.mjs');

  const sec = ((Date.now() - started) / 1000).toFixed(1);
  console.log(`\nPipeline selesai dalam ${sec} detik.`);
  console.log('Dashboard: dashboard/UAS_25110200048_LuzainRahmadaniFA.html');
}

main().catch((e) => { console.error(e); process.exit(1); });
