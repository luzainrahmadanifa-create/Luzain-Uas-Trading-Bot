// Server lokal untuk menguji handler Vercel tanpa `vercel dev`.
//   node scripts/serve_api.mjs [port]
// Endpoint: /api/tick, /api/dashboard, /api/admin
// Memakai storage lokal (logs/local) bila Upstash tidak diset.
import http from 'node:http';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const PORT = Number(process.argv[2] || 3000);
const ROOT = path.resolve('.');

const ROUTES = {
  '/api/tick': 'api/tick.js',
  '/api/dashboard': 'api/dashboard.js',
  '/api/admin': 'api/admin.js'
};

function makeRes(res) {
  res.status = (code) => { res.statusCode = code; return res; };
  res.json = (obj) => {
    if (!res.getHeader('content-type')) res.setHeader('content-type', 'application/json; charset=utf-8');
    res.end(JSON.stringify(obj));
    return res;
  };
  res.send = (body) => {
    if (typeof body === 'object' && !Buffer.isBuffer(body)) return res.json(body);
    res.end(body);
    return res;
  };
  return res;
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (c) => { data += c; });
    req.on('end', () => {
      if (!data) return resolve(undefined);
      try { resolve(JSON.parse(data)); } catch { resolve(data); }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const file = ROUTES[url.pathname];
  if (!file) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('not found');
    return;
  }
  try {
    req.body = await readBody(req);
    const mod = await import(pathToFileURL(path.join(ROOT, file)).href);
    await mod.default(req, makeRes(res));
  } catch (e) {
    if (!res.headersSent) res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: false, error: e.message }));
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('API lokal: http://127.0.0.1:' + PORT);
  console.log('  GET  /api/dashboard        (tambah ?json=1 untuk JSON)');
  console.log('  GET  /api/tick             (butuh header Authorization: Bearer CRON_SECRET)');
  console.log('  POST /api/admin            (butuh header yang sama)');
  console.log('Storage: ' + (process.env.UPSTASH_REDIS_REST_URL ? 'upstash' : 'lokal (logs/local)'));
});
