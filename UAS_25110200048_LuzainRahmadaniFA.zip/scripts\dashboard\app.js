/* Dashboard client - tanpa dependensi. Semua data sudah di-embed. */
(function () {
  'use strict';

  var D = window.__DATA__ || {};
  var idr = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 });
  var idr2 = new Intl.NumberFormat('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var pct = function (v, d) {
    if (v === null || v === undefined || !isFinite(v)) return 'n/a';
    return (v >= 0 ? '+' : '') + Number(v).toFixed(d === undefined ? 2 : d) + '%';
  };

  function fmtIdr(v) { return v === null || v === undefined ? 'n/a' : 'Rp ' + idr.format(Math.round(v)); }
  function fmtDate(ms) {
    if (!ms) return '-';
    try {
      return new Date(ms).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
      }).replace(/\./g, ':');
    } catch (e) { return new Date(ms).toISOString(); }
  }
  function cls(v) { return v > 0 ? 'pos' : (v < 0 ? 'neg' : ''); }

  /* ---------------- tabs ---------------- */
  var buttons = Array.prototype.slice.call(document.querySelectorAll('.tab-btn'));
  var panels = Array.prototype.slice.call(document.querySelectorAll('.tab-panel'));
  function show(name) {
    var found = false;
    buttons.forEach(function (b) {
      var on = b.getAttribute('data-tab') === name;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      if (on) found = true;
    });
    panels.forEach(function (p) { p.classList.toggle('active', p.getAttribute('data-panel') === name); });
    if (!found) { show('ringkasan'); return; }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  buttons.forEach(function (b) {
    b.addEventListener('click', function () {
      var n = b.getAttribute('data-tab');
      history.replaceState(null, '', '#' + n);
      show(n);
    });
  });
  show((location.hash || '#ringkasan').slice(1));

  /* ---------------- trades ---------------- */
  var T = D.trades || [];
  var st = { page: 1, per: 25, pair: 'ALL', reason: 'ALL', q: '' };
  var pairSel = document.getElementById('f-pair');
  var reasonSel = document.getElementById('f-reason');
  var search = document.getElementById('f-search');
  var tbody = document.getElementById('trades-body');
  var pager = document.getElementById('trades-pager');
  var countEl = document.getElementById('trades-count');

  function uniq(key) {
    var seen = {};
    var out = [];
    T.forEach(function (t) { if (!seen[t[key]]) { seen[t[key]] = 1; out.push(t[key]); } });
    return out.sort();
  }
  if (pairSel) {
    uniq('pair').forEach(function (p) {
      var o = document.createElement('option'); o.value = p; o.textContent = p; pairSel.appendChild(o);
    });
  }
  if (reasonSel) {
    uniq('reason').forEach(function (p) {
      var o = document.createElement('option'); o.value = p;
      o.textContent = p === 'trailing_stop' ? 'trailing stop' : (p === 'death_cross' ? 'death cross' : p);
      reasonSel.appendChild(o);
    });
  }

  function filtered() {
    return T.filter(function (t) {
      if (st.pair !== 'ALL' && t.pair !== st.pair) return false;
      if (st.reason !== 'ALL' && t.reason !== st.reason) return false;
      if (st.q && (t.pair + ' ' + t.reason).toLowerCase().indexOf(st.q) < 0) return false;
      return true;
    });
  }

  function renderTrades() {
    if (!tbody) return;
    var rows = filtered();
    var pages = Math.max(1, Math.ceil(rows.length / st.per));
    if (st.page > pages) st.page = pages;
    var start = (st.page - 1) * st.per;
    var page = rows.slice(start, start + st.per);
    var html = '';
    page.forEach(function (t) {
      html += '<tr>' +
        '<td class="mono">' + t.n + '</td>' +
        '<td><span class="pair-tag">' + t.pair + '</span></td>' +
        '<td class="nowrap mono">' + fmtDate(t.et) + '</td>' +
        '<td class="nowrap mono">' + fmtDate(t.xt) + '</td>' +
        '<td class="num">' + Number(t.days).toFixed(1) + '</td>' +
        '<td class="num mono">' + idr.format(Math.round(t.ep)) + ' &rarr; ' + idr.format(Math.round(t.xp)) + '</td>' +
        '<td class="num ' + cls(t.pnl) + '">' + fmtIdr(t.pnl) + '</td>' +
        '<td class="num ' + cls(t.pnlpct) + '">' + pct(t.pnlpct) + '</td>' +
        '<td>' + (t.reason === 'trailing_stop' ? 'Trailing stop' : 'Death cross') + '</td>' +
        '<td class="num mono">' + fmtIdr(t.cost) + '</td>' +
        '<td class="num ' + cls(t.fill) + '">' + pct(t.fill, 3) + '</td>' +
        '</tr>';
    });
    if (!page.length) html = '<tr><td colspan="11" class="center note">Tidak ada trade yang cocok dengan filter.</td></tr>';
    tbody.innerHTML = html;
    if (countEl) countEl.textContent = idr.format(rows.length) + ' trade';
    if (pager) {
      pager.innerHTML =
        '<span>Halaman ' + st.page + ' / ' + pages + '</span>' +
        '<button class="btn" data-page="prev" ' + (st.page <= 1 ? 'disabled' : '') + '>&larr; Sebelumnya</button>' +
        '<button class="btn" data-page="next" ' + (st.page >= pages ? 'disabled' : '') + '>Berikutnya &rarr;</button>';
    }
  }
  if (pager) {
    pager.addEventListener('click', function (e) {
      var b = e.target.closest('[data-page]');
      if (!b) return;
      st.page += b.getAttribute('data-page') === 'next' ? 1 : -1;
      renderTrades();
    });
  }
  if (pairSel) pairSel.addEventListener('change', function () { st.pair = pairSel.value; st.page = 1; renderTrades(); });
  if (reasonSel) reasonSel.addEventListener('change', function () { st.reason = reasonSel.value; st.page = 1; renderTrades(); });
  if (search) search.addEventListener('input', function () { st.q = search.value.toLowerCase(); st.page = 1; renderTrades(); });
  var reset = document.getElementById('f-reset');
  if (reset) reset.addEventListener('click', function () {
    st = { page: 1, per: 25, pair: 'ALL', reason: 'ALL', q: '' };
    if (pairSel) pairSel.value = 'ALL';
    if (reasonSel) reasonSel.value = 'ALL';
    if (search) search.value = '';
    renderTrades();
  });
  renderTrades();

  /* ---------------- downloads ---------------- */
  function download(name, text, mime) {
    var blob = new Blob([text], { type: mime + ';charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 600);
  }
  Array.prototype.forEach.call(document.querySelectorAll('[data-dl]'), function (b) {
    b.addEventListener('click', function () {
      var k = b.getAttribute('data-dl');
      var f = D.downloads && D.downloads[k];
      if (!f) return;
      download(f.name, f.text, f.mime);
    });
  });

  /* ---------------- copy command ---------------- */
  Array.prototype.forEach.call(document.querySelectorAll('[data-copy]'), function (b) {
    b.addEventListener('click', function () {
      var txt = b.getAttribute('data-copy');
      var done = function () {
        var old = b.textContent;
        b.textContent = 'Tersalin';
        setTimeout(function () { b.textContent = old; }, 1400);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, function () {});
      } else {
        var ta = document.createElement('textarea');
        ta.value = txt; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        ta.remove();
      }
    });
  });

  /* ---------------- print ---------------- */
  var pr = document.getElementById('btn-print');
  if (pr) pr.addEventListener('click', function () { window.print(); });
})();
