// =====================================================================
// freeze.mjs - catat "beku"-nya strategi: parameter + hash file + commit.
// Dijalankan sekali saat freeze. Menulis data/freeze.json.
//   node scripts/freeze.mjs            (gagal bila sudah ada)
//   node scripts/freeze.mjs --force    (tulis ulang; akan mengubah hash)
// =====================================================================
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { CONFIG } from '../lib/config.js';

const ROOT = path.resolve('.');
const OUT = path.join(ROOT, 'data', 'freeze.json');
const FORCE = process.argv.includes('--force');

const FILES = [
  'lib/config.js',
  'lib/strategy.js',
  'lib/indicators.js',
  'lib/execution.js',
  'lib/risk.js',
  'lib/indodax.js',
  'api/tick.js',
  'scripts/backtest.mjs'
];

async function sha256(rel) {
  const buf = await fs.readFile(path.join(ROOT, rel));
  return { file: rel, bytes: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex') };
}

async function main() {
  try {
    await fs.access(OUT);
    if (!FORCE) {
      console.log('data/freeze.json sudah ada. Pakai --force bila memang ingin freeze ulang.');
      process.exit(1);
    }
  } catch { /* belum ada */ }

  const hashes = [];
  for (const f of FILES) hashes.push(await sha256(f));

  const freeze = {
    strategyVersion: CONFIG.version,
    frozenAt: CONFIG.frozenAt,
    frozenAtUtc: new Date(CONFIG.frozenAt).toISOString(),
    recordedAt: new Date().toISOString(),
    timezone: CONFIG.timezone,
    note: 'File ini adalah bukti pembekuan aturan. freeze date mengikuti jadwal PDF: 5 Nov 2026 12.00 WIB. Parameter tidak diubah selama forward test. Hash file dicatat saat file dibuat; commit git harus diisi setelah repo di-push.',
    integrityNote: 'Pencatatan hash dilakukan pada recordedAt. Penyusunan berlangsung setelah tanggal beku resmi (keterbatasan jadwal), sehingga backtest final dipotong tepat sebelum freeze date agar data setelah freeze tidak masuk evaluasi. Eksplorasi parameter tetap melihat data hingga 7 Nov 2026; lihat refleksi.',
    git: {
      available: false,
      commit: null,
      note: 'git tidak tersedia di mesin penyusunan. Ganti nilai commit dengan hasil `git rev-parse HEAD` setelah repo di-push; hash file di bawah tetap menjadi bukti isi.'
    },
    parameters: {
      timeframe: CONFIG.timeframe,
      tfMinutes: CONFIG.tfMinutes,
      universe: CONFIG.universe.map((u) => u.symbol),
      emaFast: CONFIG.emaFast,
      emaSlow: CONFIG.emaSlow,
      emaTrend: CONFIG.emaTrend,
      atrPeriod: CONFIG.atrPeriod,
      atrMult: CONFIG.atrMult,
      maxAtrPct: CONFIG.maxAtrPct,
      trendSlopeBars: CONFIG.trendSlopeBars,
      minTurnover24hIdr: CONFIG.minTurnover24hIdr,
      startingEquityIdr: CONFIG.startingEquityIdr,
      maxPositions: CONFIG.maxPositions,
      allocPctPerPosition: CONFIG.allocPctPerPosition,
      minOrderIdr: CONFIG.minOrderIdr,
      feeTakerPctPerSide: CONFIG.feeTakerPct * 100,
      dailyLossLimitPct: CONFIG.dailyLossLimitPct * 100,
      maxSpreadPct: CONFIG.maxSpreadPct * 100
    },
    files: hashes
  };

  await fs.mkdir(path.dirname(OUT), { recursive: true });
  await fs.writeFile(OUT, JSON.stringify(freeze, null, 2));
  console.log('Ditulis: data/freeze.json');
  for (const h of hashes) console.log(`  ${h.sha256.slice(0, 12)}  ${h.file}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
