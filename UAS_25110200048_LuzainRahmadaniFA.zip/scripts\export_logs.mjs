// =====================================================================
// export_logs.mjs - tarik log dari Upstash Redis ke ./logs/export (JSONL).
// Dipakai setelah forward test supaya dashboard bisa dihitung ulang offline.
//   UPSTASH_REDIS_REST_URL=... UPSTASH_REDIS_REST_TOKEN=... \
//     node scripts/export_logs.mjs
//   node scripts/export_logs.mjs --out logs/export-2026-11-19
// =====================================================================
import { promises as fs } from 'node:fs';
import path from 'node:path';

const KINDS = ['calls', 'orders', 'equity', 'signals', 'errors', 'killswitch'];
const OUT = path.resolve(process.argv.includes('--out')
  ? process.argv[process.argv.indexOf('--out') + 1]
  : 'logs/export');

const URL_BASE = (process.env.UPSTASH_REDIS_REST_URL || '').replace(/\/$/, '');
const TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN || '';

async function upstash(cmd) {
  const res = await fetch(URL_BASE, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      'content-type': 'application/json'
    },
    body: JSON.stringify(cmd)
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`upstash HTTP ${res.status}: ${text.slice(0, 160)}`);
  const data = JSON.parse(text);
  if (data && data.error) throw new Error(`upstash: ${data.error}`);
  return data;
}

async function main() {
  if (!URL_BASE || !TOKEN) {
    console.error('UPSTASH_REDIS_REST_URL dan UPSTASH_REDIS_REST_TOKEN wajib diisi.');
    process.exit(1);
  }
  await fs.mkdir(OUT, { recursive: true });

  const counts = {};
  for (const kind of KINDS) {
    const r = await upstash(['LRANGE', `uas:log:${kind}`, '0', '-1']);
    const lines = r.result || [];
    await fs.writeFile(path.join(OUT, `${kind}.jsonl`), lines.length ? lines.join('\n') + '\n' : '');
    counts[kind] = lines.length;
    console.log(`${kind.padEnd(10)} ${String(lines.length).padStart(6)} baris`);
  }

  const state = await upstash(['GET', 'uas:state']);
  if (state.result) {
    await fs.writeFile(path.join(OUT, 'state.json'), JSON.stringify(JSON.parse(state.result), null, 2));
    console.log('state      tersimpan');
  }

  // Jangan pernah menulis URL/token Upstash ke file yang ikut dikumpulkan.
  const files = [];
  for (const f of await fs.readdir(OUT)) {
    const st = await fs.stat(path.join(OUT, f));
    files.push({ file: f, bytes: st.size });
  }

  const manifest = {
    exportedAt: new Date().toISOString(),
    source: 'upstash-redis (URL dirahasiakan)',
    kinds: KINDS,
    counts,
    files
  };
  await fs.writeFile(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 2));
  console.log(`\nSelesai -> ${OUT}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
