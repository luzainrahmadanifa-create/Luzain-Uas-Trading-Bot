# Strategi UAS — Golden Cross + ATR Trailing Stop (Kripto IDR, 4 Jam)

Dokumen ini menjelaskan aturan strategi yang dijalankan bot **dan** backtest. Sumber parameter tunggal: `lib/config.js` (dibekukan 5 November 2026 12.00 WIB). Implementasi sinyal: `lib/strategy.js` — fungsi yang sama dipakai bot dan backtest, sehingga tidak ada dua versi aturan.

---

## 1. Dasar: strategi UTS

Di UTS, strategi diuji pada **saham Kompas100, data harian, 10 tahun**:

- Golden cross **EMA 9 / EMA 21** dengan filter **close > EMA 50**.
- **Trailing stop 3,0 × ATR(14)**.
- Biaya: fee beli 0,15%, fee jual 0,25% (termasuk PPh final 0,10%), plus spread 1 fraksi harga BEI.

Inti yang dipertahankan di UAS: **trend following dengan golden cross dan trailing stop ATR**. Yang berubah adalah pasar (kripto IDR 24/7), timeframe (4 jam), filter tambahan, sizing portofolio, model biaya, dan otomasi.

---

## 2. Universe: 5 pasangan IDR, dipilih point-in-time

Universe **tidak** dipilih dari likuiditas hari ini (itu menyebabkan survivorship/look-ahead bias). Prosedur di `scripts/select_universe.mjs`:

1. Kandidat: pasangan IDR besar yang sudah terdaftar sebelum November 2023.
2. Ukur **turnover 30 hari** yang berakhir **1 November 2023** dari candle harian (`close × volume`).
3. Peringkat teratas yang lolos filter kualitas data dan turnover minimum.

Hasil: **BTCIDR, ETHIDR, XRPIDR, DOGEIDR, SOLIDR**. Audit lengkap (semua kandidat, coverage, turnover) ada di `data/universe.json` dan tab Validasi dashboard.

Konsekuensi yang diterima: aset yang populer setelah 2023 (misalnya token baru) tidak masuk universe, sehingga hasil tidak "memilih pemenang di masa depan".

---

## 3. Timeframe: 4 jam

Timeframe yang diuji: 1 jam, 4 jam, harian. Yang dipakai: **4 jam** (`tf=240`).

Alasannya terukur, bukan selera:

| Timeframe | Return | MDD | PF | Trade |
|---|---:|---:|---:|---:|
| 1 jam | **−74,18%** | −79,11% | 0,84 | 2.359 |
| 4 jam | **+44,75%** | −21,22% | 1,42 | 252 |

Pada 1 jam, fee taker 0,20%/sisi (0,40% bolak-balik) jauh melebihi edge per trade. Semakin sering trading, semakin besar biaya yang menggerus hasil. 4 jam cukup jarang untuk bertahan terhadap biaya, tetapi cukup sering untuk mengikuti tren kripto. Timeframe harian diuji secara konseptual, tetapi jumlah sinyal dalam 14 hari forward terlalu sedikit untuk evaluasi yang bermakna.

---

## 4. Indikator

Semua dihitung pada **candle tertutup**; candle yang belum selesai dibuang (`dropUnclosed`).

- **EMA 9, EMA 21, EMA 50** — `EMA_t = α·close_t + (1−α)·EMA_{t−1}`, `α = 2/(n+1)`. Nilai awal: SMA dari n bar pertama.
- **ATR 14** — True Range `TR = max(high−low, |high−prevClose|, |low−prevClose|)`; ATR = rata-rata Wilder 14 periode.
- **Turnover 24 jam** — jumlah `close × volume` dari 6 bar 4 jam terakhir (setara 24 jam).
- **Slope EMA 50** — `EMA50_t > EMA50_{t−6}` (naik dibanding 6 bar lalu).

---

## 5. Aturan entry

Semua kondisi berikut harus benar pada candle tertutup yang sama:

1. **Golden cross:** `EMA9_t > EMA21_t` dan `EMA9_{t−1} ≤ EMA21_{t−1}`.
2. **Tren:** `close_t > EMA50_t`.
3. **Slope:** `EMA50_t > EMA50_{t−6}`.
4. **Volatilitas wajar:** `ATR14_t / close_t ≤ 0,06` (6%).
5. **Likuiditas:** turnover 24 jam ≥ **Rp 250.000.000**.
6. **Risiko portofolio:**
   - posisi terbuka < **4**;
   - daily loss limit **3%** belum tersentuh (anchor ekuitas 00.00 WIB);
   - kill switch mati;
   - spread bid-ask ≤ **2%**.
7. **Eksekusi:** beli di **ask** (menyapu level order book), fee taker 0,20%, ukuran posisi = **15% ekuitas berjalan**, minimum order **Rp 25.000**.

Ukuran posisi aktual:

```
notional = min(0.15 × equity, cash)
qty      = floor(notional / ask_price / quantity_increment) × quantity_increment
biaya    = qty × ask_price × (1 + fee_taker)
```

Jika `qty × ask_price < Rp 25.000`, entry dibatalkan.

---

## 6. Aturan exit

Dievaluasi setiap candle tertutup untuk setiap posisi:

1. **Trailing stop ATR:**
   - saat entry: `stop = entry_fill − 3,0 × ATR14`
   - setiap candle: `stop = max(stop_lama, close_t − 3,0 × ATR14_t)`
   - stop **hanya naik**, tidak pernah turun.
2. **Stop kena:** `close_t < stop` → jual di **bid** pada candle berikutnya.
3. **Death cross:** `EMA9_t < EMA21_t` dan `EMA9_{t−1} ≥ EMA21_{t−1}` → jual.
4. Tidak ada short. Setelah keluar, dana menjadi kas sampai sinyal entry berikutnya.

Alasan keluar dicatat di `trades.csv` (`trailing_stop` atau `death_cross`) dan direkap di dashboard.

---

## 7. Risiko portofolio

| Kontrol | Aturan | Bukti |
|---|---|---|
| Maks posisi | 4 | `entry_blocked` di respons tick |
| Maks ukuran | 15% ekuitas/posisi | notional di `orders.jsonl` |
| Daily loss limit | 3% dari ekuitas anchor 00.00 WIB; tidak ada entry baru sampai hari berikutnya | `dailyLossTripped` di state |
| Kill switch | `KILL_SWITCH=1` atau `POST /api/admin {"killSwitch":true}` | `killswitch.jsonl` |
| Retry | 3 percobaan, backoff eksponensial, timeout 12 detik; error 4xx tidak di-retry | `errors.jsonl` |
| Idempotency | satu candle hanya diproses sekali per pair (`lastCandle[pair]`) | `signals.jsonl` (`newCandle:false`) |
| Validasi data | buang candle berjalan; tolak gap, duplikat, harga/volume nol, data basi > 2× tf, book kosong, spread > 2% | `issues` di log sinyal |

Tidak ada leverage, margin, futures, atau short selling.

---

## 8. Model biaya dan eksekusi

### Backtest

- **Fee:** 0,20% per sisi (taker), dibebankan pada beli dan jual.
- **Spread:** setengah spread terukur per pair, dibebankan di setiap sisi.
- **Slippage:** diukur dari kedalaman order book untuk order referensi Rp 25.000.000, dibebankan di setiap sisi.
- **Harga eksekusi:** open bar **berikutnya** setelah sinyal, lalu disesuaikan setengah spread + slippage. Bukan close candle sinyal, bukan mid.
- **Equity:** posisi terbuka dinilai di **best bid**; equity harian dicatat sekali per hari (pengambilan pertama setelah 00.00 WIB).

Nilai spread/slippage (bps) yang dipakai:

| Pair | Spread | Slippage | Biaya/sisi |
|---|---:|---:|---:|
| BTCIDR | 0,007 | 2,070 | 2,073 |
| ETHIDR | 2,467 | 4,985 | 6,218 |
| XRPIDR | 3,349 | 2,146 | 3,821 |
| DOGEIDR | 15,396 | 0 | 7,698 |
| SOLIDR | 10,490 | 0 | 5,245 |

Slippage 0 berarti order referensi tidak menembus level terbaik pada snapshot tersebut; order tetap dibebani setengah spread.

### Bot live (dry run)

- Beli: menyapu level **ask** sampai notional terpenuhi; harga rata-rata tertimbang.
- Jual: menyapu level **bid**.
- Fee taker 0,20% per sisi.
- Tidak ada order nyata; hanya state dan log.

**Keterbatasan:** snapshot order book hanya 3 putaran pada satu hari (7 Nov 2026). Spread dan slippage bisa berbeda pada jam sepi atau saat volatil. Partial fill dan antrean order tidak dimodelkan.

---

## 9. Uji ketahanan parameter

Dijalankan dengan `scripts/run_variants.mjs`, hasil di `data/variants.json`. Semua varian memakai data dan biaya yang sama.

| Varian | Return | MDD | PF | Trade | Keputusan |
|---|---:|---:|---:|---:|---|
| 1 jam · ATR 3 · tanpa slope | −74,18% | −79,11% | 0,84 | 2.359 | Ditolak (fee drag) |
| 4 jam · ATR 3 · tanpa slope | +74,56% | −45,87% | 1,16 | 566 | MDD terlalu besar |
| 4 jam · ATR 3 · slope 12 | +13,18% | −26,72% | 1,14 | 189 | Return kecil |
| 4 jam · ATR 4 · tanpa slope | +77,26% | −48,12% | 1,15 | 566 | MDD terlalu besar |
| 4 jam · ATR 4 · slope 12 | +10,45% | −28,79% | 1,11 | 189 | Return kecil |
| 4 jam · ATR 3 · slope 6 · maks 5 | +61,22% | −29,21% | 1,37 | 258 | Kandidat |
| 4 jam · ATR 3 · slope 6 · maks 4 | +59,87% | −27,17% | 1,38 | 252 | Kandidat |
| **4 jam · ATR 3 · slope 6 · maks 4 · 15%** | **+44,75%** | **−21,22%** | **1,42** | **252** | **DIPILIH** |

Kriteria: profit factor ≥ 1,3, MDD ≤ 25%, return wajar, dan biaya tidak mendominasi. Varian dengan return lebih tinggi tetapi MDD ~−46% sampai −48% ditolak karena tidak sesuai profil risiko yang bisa dipertanggungjawabkan. Varian final mengorbankan sebagian return untuk memotong drawdown.

**Catatan overfitting:** pemilihan parameter memakai data in-sample yang sama dengan periode backtest. Hasil ini **tidak** diklaim out-of-sample. Penyusunan berlangsung 7 Nov 2026, sehingga eksplorasi parameter melihat data hingga tanggal itu; backtest final dipotong tepat sebelum freeze date. Forward test disiapkan untuk menguji aturan beku pada data baru.

---

## 10. Perubahan dari UTS ke UAS

| Aspek | UTS | UAS | Alasan |
|---|---|---|---|
| Pasar | Saham BEI (Kompas100), harian | Kripto IDR Indodax, 4 jam | Pasar 24/7, volatilitas lebih tinggi, fee lebih besar |
| Universe | 10 tahun, saham Kompas100 | 5 pasangan IDR likuid | Dipilih point-in-time dari turnover 30 hari |
| Entry | Golden cross EMA 9/21 + close > EMA50 | Sama + slope EMA50 + filter ATR% + filter turnover | Mengurangi whipsaw dan entry di aset sepi |
| Exit | Trailing stop ATR 3,0 | Trailing stop ATR 3,0 **atau** death cross EMA 9/21 | Exit lebih cepat saat momentum berbalik |
| Sizing | Alokasi per saham | Maks 4 posisi × 15% ekuitas | Kontrol eksposur portofolio kripto |
| Biaya | Fee beli 0,15%, jual 0,25% + spread 1 tick | Fee taker 0,20%/sisi + spread & slippage terukur | Fee kripto jauh lebih besar; diukur dari order book |
| Eksekusi | Backtest saham | Bot dry run di Vercel, fill dari bid/ask live | Latensi, cron, dan ketersediaan API harus ditangani |
| Risiko | Trailing stop per posisi | + daily loss limit 3% WIB, kill switch, retry, idempotency | Wajib sesuai PDF |
| Otomasi | Tidak ada | `/api/tick` + GitHub Actions tiap jam | Fungsi Vercel tidak berjalan terus-menerus |

---

## 11. Mengapa hasilnya kalah dari BTC

BTC/IDR buy & hold pada periode yang sama: **+163,46%** dengan MDD **−49,21%**. Strategi: **+44,75%** dengan MDD **−21,22%**. Secara return, strategi kalah. Yang bisa diklaim:

- drawdown kurang dari setengah benchmark;
- eksposur maksimum 60% (4 × 15%), sisanya kas;
- tidak ada leverage;
- win rate rendah (26,19%) tetapi payoff besar (rata-rata menang +12,01% vs rugi −2,72%), sehingga profit factor 1,42.

Untuk investor yang tidak tahan drawdown 49%, profil ini punya alasan. Untuk yang mengejar return maksimum, BTC buy-and-hold lebih baik pada periode ini. Ini dilaporkan terbuka.

---

## 12. Batasan dan arah perbaikan

1. **In-sample parameter selection** — belum ada out-of-sample murni. Forward test adalah uji out-of-sample yang disiapkan.
2. **Snapshot order book terbatas** — satu hari, tiga putaran. Perbaikan: snapshot otomatis beberapa kali sehari selama beberapa minggu.
3. **Tidak ada antrean order / partial fill** — model eksekusi mengasumsikan fill langsung. Perbaikan: simulasi limit order dan antrean.
4. **Forward live belum berjalan** — belum ada bukti uptime produksi. Perbaikan: deploy, biarkan 14 hari, ekspor log, hitung ulang.
5. **Data candle, bukan tick** — cukup untuk timeframe 4 jam, tetapi tidak menangkap intrabar stop dengan presisi tinggi.

Semua batasan ini juga tertulis di tab **Refleksi** dashboard dan di README.
