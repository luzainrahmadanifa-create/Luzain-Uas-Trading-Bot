// Bagian 1-3 dashboard: Ringkasan, Backtest, Log Trade.
import { idr, idrShort, pct, pctRaw, num, cls, dateWib, dateShortWib, monthName } from './fmt.mjs';
import { heatColor, esc } from './charts.mjs';

function card(title, sub, body, extra = '') {
  return '<div class="card ' + extra + '">' +
    '<div class="card-head"><h3>' + title + '</h3></div>' +
    (sub ? '<p class="sub">' + sub + '</p>' : '') + body + '</div>';
}
function kpi(label, value, hint, tone, color) {
  return '<div class="card kpi" style="--kc:' + (color || 'var(--accent)') + '">' +
    '<div class="label">' + label + '</div>' +
    '<div class="value ' + (tone || 'neutral') + '">' + value + '</div>' +
    '<div class="hint">' + hint + '</div></div>';
}
function checkItem(status, title, desc, tag) {
  const ic = status === 'ok' ? '&#10003;' : (status === 'warn' ? '!' : '&times;');
  return '<div class="check"><div class="ic ' + status + '">' + ic + '</div>' +
    '<div><div class="t">' + title + '</div><div class="d">' + desc + '</div></div>' +
    '<div class="s"><span class="badge ' + status + '">' + tag + '</span></div></div>';
}

export function renderRingkasan(c) {
  const bt = c.bt;
  const fwd = c.fwd;
  const localOnly = !c.logs || String(c.logs.mode || '').indexOf('lokal') >= 0;
  const banner = !localOnly
    ? '<div class="banner warn"><div><h3>Forward test live sedang berjalan</h3><p>' + num(fwd.calls) + ' panggilan produksi tercatat sejak ' + dateWib(fwd.firstCall) + '. Hasil masih awal dan belum final.</p></div><div class="big">' + pct(fwd.equity ? fwd.equity.totalReturnPct : 0) + '</div></div>'
    : '<div class="banner bad"><div><h3>Forward test live belum berjalan</h3><p>Sumber log saat ini: <b>' + (c.logs ? c.logs.mode : 'lokal') + '</b> — baru <b>' + num(fwd ? fwd.calls : 0) + ' panggilan uji lokal, ' + num(fwd ? fwd.trades : 0) + ' trade</b>. Bot belum di-deploy ke Vercel karena mesin penyusunan tidak memiliki akun/kredensial Vercel. <b>Tidak ada hasil forward yang dikarang</b>; seluruh angka forward di dashboard ini berasal dari log apa adanya.</p></div><div class="big">' + num(c.forwardProgress.pct, 0) + '%<div class="note tiny">jendela 14 hari</div></div></div>';

  const kpis = '<div class="grid g4 mt16">' +
    kpi('Return backtest (3 th)', pct(bt.totalReturnPct), 'Ekuitas akhir <b>' + idrShort(bt.final) + '</b> dari ' + idrShort(bt.initial), bt.totalReturnPct >= 0 ? 'pos' : 'neg', 'var(--green)') +
    kpi('CAGR', pct(bt.cagrPct), 'Majemuk tahunan, ' + num(bt.periodDays) + ' hari', bt.cagrPct >= 0 ? 'pos' : 'neg', 'var(--accent)') +
    kpi('Max drawdown', pct(bt.mddPct), 'Puncak ' + dateShortWib(bt.mddPeakAt) + ' &rarr; palung ' + dateShortWib(bt.mddTroughAt), 'neg', 'var(--red)') +
    kpi('Profit factor', num(bt.profitFactor, 2), 'Win rate <b>' + pctRaw(bt.winRate) + '</b> dari ' + num(bt.trades) + ' trade', 'neutral', 'var(--purple)') +
    kpi('Trade', num(bt.trades), 'Avg win <b>' + pct(bt.avgWinPct) + '</b> · avg loss <b>' + pct(bt.avgLossPct) + '</b>', 'neutral', 'var(--accent2)') +
    kpi('Porsi biaya', pctRaw(bt.costSharePct), idrShort(bt.totalCostsIdr) + ' dari laba kotor', 'neutral', 'var(--amber)') +
    kpi('Benchmark BTC/IDR', pct(c.bench.returnPct), 'Buy &amp; hold, MDD <b>' + pct(c.bench.mddPct) + '</b>', c.bench.returnPct >= 0 ? 'pos' : 'neg', 'var(--amber)') +
    kpi('Forward test', fwd ? pct(fwd.equity ? fwd.equity.totalReturnPct : 0) : 'n/a', num(c.forwardProgress.daysElapsed, 1) + ' / ' + c.forwardProgress.daysTotal + ' hari · ' + num(fwd ? fwd.calls : 0) + ' panggilan · ' + num(fwd ? fwd.trades : 0) + ' trade', 'neutral', 'var(--muted)') +
    '</div>';

  const integrity = card('Cara membaca hasil ini',
    'Angka backtest bukan janji return. Ini hasil simulasi pada data historis dengan biaya yang diukur.',
    '<ul class="rule-list">' +
    '<li><b>Backtest</b> memakai 3 tahun data asli Indodax (5 Nov 2023 – 5 Nov 2026, berhenti tepat sebelum freeze date), timeframe 4 jam, 5 pasangan IDR, dan fungsi sinyal yang <b>sama persis</b> dengan bot.</li>' +
    '<li><b>Biaya</b> = fee taker 0,20% per sisi + setengah spread + slippage hasil pengukuran order book. Total biaya ' + idrShort(bt.totalCostsIdr) + ' atau ' + pctRaw(bt.costSharePct) + ' dari laba kotor.</li>' +
    '<li><b>Benchmark</b> BTC/IDR beli-dan-tahan menghasilkan ' + pct(c.bench.returnPct) + ' dengan MDD ' + pct(c.bench.mddPct) + '. Strategi <b>tidak mengalahkan</b> BTC dalam return; keunggulannya adalah MDD jauh lebih kecil (' + pct(bt.mddPct) + ') dan eksposur yang terbatas. Ini dilaporkan apa adanya.</li>' +
    '<li><b>Forward test</b> belum selesai. Jendela 5–19 Nov 2026 baru berjalan ' + num(c.forwardProgress.daysElapsed, 1) + ' hari saat dashboard dibuat. Angka replay pada jendela yang sama ditampilkan terpisah sebagai pembanding, bukan sebagai hasil live.</li>' +
    '<li>Semua metrik dapat dihitung ulang: <span class="mono">node scripts/hitung_ulang.mjs</span> &rarr; ' + c.checksPass + '/' + c.checks.length + ' cek konsistensi lolos.</li>' +
    '</ul>');

  const list = [
    ['warn', 'Bot dry run di Vercel', 'Kode <span class="mono">api/tick.js</span> + <span class="mono">vercel.json</span> siap dan sudah diuji lokal. <b>Belum di-deploy</b>: tidak ada akun/kredensial Vercel di mesin ini. Langkah deploy ada di tab Aturan &amp; Perubahan.', 'KODE SIAP'],
    ['ok', 'Hanya API publik, tanpa API key, tanpa uang asli', 'Endpoint: <span class="mono">/api/server_time</span>, <span class="mono">/api/pairs</span>, <span class="mono">/api/depth</span>, <span class="mono">/api/ticker_all</span>, <span class="mono">/tradingview/history_v2</span>. Tidak ada endpoint privat yang dipanggil.', 'TERPENUHI'],
    ['ok', 'Long-only, tanpa short / margin / leverage', 'Order hanya BUY lalu SELL aset yang dimiliki. Tidak ada pinjaman, futures, atau short selling.', 'TERPENUHI'],
    ['ok', 'Timeframe 1 jam / 4 jam / harian', 'Dipakai <b>4 jam</b> (tf=240). Timeframe 1 jam diuji dan ditolak karena fee drag (lihat tab Backtest).', 'TERPENUHI'],
    ['ok', 'Universe 3–10 pasangan likuid, dipilih di awal backtest', '5 pasangan: BTC, ETH, XRP, DOGE, SOL (IDR). Peringkat turnover 30 hari yang berakhir 1 Nov 2023 — bukan likuiditas hari ini.', 'TERPENUHI'],
    ['ok', 'Backtest minimal 3 tahun dengan data asli', num(bt.periodDays) + ' hari, ' + num(c.quality.reduce((s, q) => s + q.count, 0)) + ' bar 4 jam, 0 gap / 0 duplikat / 0 harga nol.', 'TERPENUHI'],
    ['ok', 'Biaya: fee + spread + slippage terukur', 'Fee taker 0,20%/sisi dari <span class="mono">/api/pairs</span>; spread &amp; slippage dari 3 putaran snapshot order book untuk order referensi Rp25 juta.', 'TERPENUHI'],
    ['ok', 'Risk: max posisi, max size, daily loss, kill switch, retry terbatas', 'Maks 4 posisi, 15% ekuitas/posisi, daily loss 3% (anchor 00.00 WIB), kill switch via env/state, retry 3x dengan backoff.', 'TERPENUHI'],
    ['warn', 'Forward test 14 hari dengan aturan beku', 'Jendela 5 Nov 12.00 WIB – 19 Nov 12.00 WIB. Per ' + dateShortWib(c.generatedAt) + ' baru ' + num(c.forwardProgress.pct, 0) + '% dan belum ada deployment. Hasil live belum tersedia; tidak dipalsukan.', 'BELUM SELESAI'],
    ['ok', 'Dashboard offline + halaman Vercel, metrik bisa dihitung ulang', 'File HTML ini mandiri (tanpa CDN). <span class="mono">api/dashboard.js</span> menyajikan versi server-rendered untuk Vercel.', 'TERPENUHI'],
    ['ok', 'Deliverable ZIP + README + strategi + hash freeze + log mentah + refleksi', 'ZIP berisi source, README, strategy.md, data/freeze.json, log mentah, scripts/hitung_ulang.mjs, dashboard offline, dan <span class="mono">.env.example</span> tanpa secret.', 'TERPENUHI'],
    ['ok', 'Integritas: tidak memalsukan hasil', 'Tidak ada angka forward fiktif. Keterbatasan, kegagalan varian 1 jam, dan underperformance vs BTC ditulis terbuka.', 'TERPENUHI']
  ].map((x) => checkItem(x[0], x[1], x[2], x[3])).join('');

  return '' +
    '<section class="tab-panel active" id="panel-ringkasan" data-panel="ringkasan">' +
    banner + kpis +
    '<h2 class="section-title">Kepatuhan terhadap perintah PDF <small>status apa adanya, bukan klaim</small></h2>' +
    '<div class="checklist">' + list + '</div>' +
    '<div class="grid g2 mt24">' + integrity +
    card('Ringkasan eksekusi',
      'Alur satu siklus bot (setiap candle 4 jam ditutup).',
      '<div class="kv">' +
      '<dt>1. Ambil data</dt><dd>Candle 4 jam + order book publik untuk 5 pasangan. Candle yang belum tertutup dibuang.</dd>' +
      '<dt>2. Validasi</dt><dd>Cek jumlah bar, gap, duplikat, harga nol, dan data basi (&gt; 2&times; timeframe). Bila gagal, pasangan dilewati.</dd>' +
      '<dt>3. Sinyal</dt><dd>Fungsi <span class="mono">computeSignals()</span> yang sama dengan backtest: EMA 9/21/50, ATR 14, filter slope &amp; turnover.</dd>' +
      '<dt>4. Risiko</dt><dd>Kill switch, daily loss limit 3% (00.00 WIB), maks 4 posisi, maks 15% ekuitas/posisi.</dd>' +
      '<dt>5. Eksekusi</dt><dd>Beli menyapu level ask; jual menyapu level bid. Fee taker 0,2%. Tidak ada order nyata.</dd>' +
      '<dt>6. Simpan</dt><dd>State + log JSONL (calls, orders, signals, equity, errors). Satu candle hanya diproses sekali per pasangan.</dd>' +
      '</div>') +
    '</div>' +
    '</section>';
}

export function renderBacktest(c) {
  const bt = c.bt;
  const yearlyRows = c.yearly.map((y) =>
    '<tr><td>' + y.y + (y.partial ? ' <span class="badge warn">sebagian</span>' : '') + '</td>' +
    '<td class="num ' + cls(y.ret) + '">' + pct(y.ret) + '</td>' +
    '<td class="num mono">' + idr(y.end) + '</td></tr>').join('');

  const monthHead = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']
    .map((m) => '<th>' + m + '</th>').join('');
  const years = [...new Set(c.monthly.map((m) => m.y))];
  const heatRows = years.map((y) => {
    let cells = '';
    for (let m = 1; m <= 12; m++) {
      const row = c.monthly.find((x) => x.y === y && x.m === m);
      if (!row) { cells += '<td class="empty"></td>'; continue; }
      cells += '<td style="' + heatColor(row.ret) + '" title="' + y + '-' + String(m).padStart(2, '0') + '">' +
        (row.ret >= 0 ? '+' : '') + row.ret.toFixed(1) + (row.partial ? '*' : '') + '</td>';
    }
    const yy = c.yearly.find((x) => x.y === y);
    return '<tr><td class="year">' + y + '</td>' + cells + '<td style="' + heatColor(yy ? yy.ret : null) + ';font-weight:800">' + (yy ? pct(yy.ret, 1) : '') + '</td></tr>';
  }).join('');

  const pairRows = c.perPair.map((p) => {
    const maxAbs = Math.max(...c.perPair.map((x) => Math.abs(x.pnl)), 1);
    const w = Math.abs(p.pnl) / maxAbs * 100;
    return '<tr><td><span class="pair-tag">' + p.pair + '</span></td>' +
      '<td class="num">' + p.trades + '</td>' +
      '<td class="num">' + pctRaw(p.winRate) + '</td>' +
      '<td class="num ' + cls(p.pnl) + '">' + idr(p.pnl) + '</td>' +
      '<td class="num ' + cls(p.avgPct) + '">' + pct(p.avgPct) + '</td>' +
      '<td><div class="mini-bar"><span style="width:' + w.toFixed(1) + '%;background:' + (p.pnl >= 0 ? '#22c55e' : '#ef4444') + '"></span></div></td></tr>';
  }).join('');

  const reasonRows = c.perReason.map((r) =>
    '<tr><td>' + (r.reason === 'trailing_stop' ? 'Trailing stop ATR' : 'Death cross EMA 9/21') + '</td>' +
    '<td class="num">' + r.trades + '</td>' +
    '<td class="num ' + cls(r.pnl) + '">' + idr(r.pnl) + '</td>' +
    '<td class="num ' + cls(r.avgPct) + '">' + pct(r.avgPct) + '</td></tr>').join('');

  const variantRows = (c.variants || []).map((v) => {
    const chosen = v.id === 'v7';
    const cells = [
      (chosen ? '<b>' : '') + v.label + (chosen ? '</b>' : ''),
      '<span class="' + cls(v.returnPct) + '">' + pct(v.returnPct) + '</span>',
      pct(v.mddPct),
      num(v.profitFactor, 2),
      num(v.trades),
      chosen ? '<b>DIPILIH &amp; DIBEKUKAN</b>' : (v.id === 'v0' ? 'Ditolak: fee drag' : (v.mddPct < -40 ? 'MDD terlalu besar' : (v.returnPct < 20 ? 'Return kecil' : 'Kandidat')))
    ];
    return '<tr' + (chosen ? ' style="background:rgba(34,211,238,.06)"' : '') + '>' +
      cells.map((x, i) => '<td' + (i >= 1 && i <= 4 ? ' class="num"' : (i === 5 ? ' class="note"' : '')) + '>' + x + '</td>').join('') +
      '</tr>';
  }).join('');

  const costRows = Object.entries(bt.spreadSlippagePerPair).map(([pair, v]) =>
    '<tr><td>' + pair + '</td><td class="num">' + num(v.spreadBps, 3) + '</td><td class="num">' + num(v.slippageBps, 3) + '</td>' +
    '<td class="num">' + num(v.spreadBps / 2 + v.slippageBps, 3) + '</td></tr>').join('');

  return '' +
    '<section class="tab-panel" id="panel-backtest" data-panel="backtest">' +
    '<div class="grid g2">' +
    card('Kurva ekuitas vs benchmark',
      'Indeks 100 = awal periode (5 Nov 2023). Garis penuh = strategi; garis putus-putus = BTC/IDR beli-dan-tahan.',
      '<div class="legend"><span style="color:#22d3ee"><i style="background:#22d3ee"></i>Strategi</span><span style="color:#f59e0b"><i class="dash" style="color:#f59e0b"></i>BTC/IDR buy &amp; hold</span></div>' + c.charts.equity) +
    card('Drawdown harian',
      'Penurunan dari puncak ekuitas. MDD strategi ' + pct(bt.mddPct) + ' vs BTC ' + pct(c.bench.mddPct) + '.',
      '<div class="legend"><span style="color:#ef4444"><i style="background:#ef4444"></i>Drawdown strategi</span></div>' + c.charts.drawdown) +
    '</div>' +

    '<h2 class="section-title">Metrik utama <small>semua dihitung ulang dari equity_daily.csv</small></h2>' +
    '<div class="grid g4">' +
    kpi('Ekuitas awal', idrShort(bt.initial), 'Modal simulasi, bukan uang asli', 'neutral', 'var(--muted)') +
    kpi('Ekuitas akhir', idrShort(bt.final), pct(bt.totalReturnPct) + ' total', 'pos', 'var(--green)') +
    kpi('Calmar ratio', num(bt.cagrPct / Math.abs(bt.mddPct), 2), 'CAGR / |MDD|', 'neutral', 'var(--purple)') +
    kpi('Sharpe harian (annualized)', num(c.extra.sharpe, 2), 'Risk-free 0%', 'neutral', 'var(--accent)') +
    kpi('Sortino', num(c.extra.sortino, 2), 'Hanya volatilitas negatif', 'neutral', 'var(--accent2)') +
    kpi('Exposure rata-rata', num(c.extra.exposurePct, 1) + '%', 'Porsi ekuitas yang terinvestasi', 'neutral', 'var(--amber)') +
    kpi('Rata-rata simpan', num(c.extra.avgHoldDays, 1) + ' hari', 'Median ' + num(c.extra.medianHoldDays, 1) + ' hari', 'neutral', 'var(--muted)') +
    kpi('Kalah beruntun terpanjang', num(bt.maxConsecutiveLosses) + 'x', 'Uji mental &amp; sizing', 'neutral', 'var(--red)') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Return bulanan (WIB)',
      'Angka % perubahan ekuitas. Hijau = positif, merah = negatif. Tanda * = bulan berjalan (data belum penuh).',
      '<div class="table-wrap" style="border:0"><table class="heat"><thead><tr><th>Tahun</th>' + monthHead + '<th>Total</th></tr></thead><tbody>' + heatRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Bulan positif: <b>' + c.extra.positiveMonths + ' / ' + c.extra.totalMonths + '</b>. Terbaik ' + pct(c.extra.bestMonth.ret) + ' (' + c.extra.bestMonth.label + '), terburuk ' + pct(c.extra.worstMonth.ret) + ' (' + c.extra.worstMonth.label + ').</p>') +
    card('Return tahunan',
      'Tahun pertama dan terakhir bersifat sebagian (periode backtest tidak setahun penuh).',
      '<div class="table-wrap"><table><thead><tr><th>Tahun</th><th class="num">Return</th><th class="num">Ekuitas akhir</th></tr></thead><tbody>' + yearlyRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">2023 dan 2026 hanya mencakup sebagian tahun karena periode backtest 5 Nov 2023 – 5 Nov 2026.</p>') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Kontribusi per pasangan',
      'Net P&amp;L sesudah fee, spread, dan slippage. Bar menunjukkan besaran relatif.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th class="num">Trade</th><th class="num">Win rate</th><th class="num">Net P&amp;L</th><th class="num">Rata-rata</th><th>Proporsi</th></tr></thead><tbody>' + pairRows + '</tbody></table></div>') +
    card('Alasan keluar posisi',
      'Trailing stop ATR memotong kerugian; death cross keluar saat momentum berbalik.',
      '<div class="table-wrap"><table><thead><tr><th>Alasan</th><th class="num">Trade</th><th class="num">Net P&amp;L</th><th class="num">Rata-rata</th></tr></thead><tbody>' + reasonRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Rata-rata trade menang +' + num(bt.avgWinPct, 2) + '% dan trade rugi ' + num(bt.avgLossPct, 2) + '%. Payoff ' + num(c.extra.payoff, 2) + 'x, expectancy ' + idrShort(c.extra.expectancy) + ' per trade.</p>') +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('Distribusi hasil trade',
      'Sebagian besar trade rugi kecil; sebagian kecil menang besar. Ini karakter trend following.',
      c.charts.hist) +
    card('Rincian biaya',
      'Fee taker 0,20% per sisi (beli &amp; jual). Spread &amp; slippage diukur dari order book publik.',
      '<div class="kv">' +
      '<dt>Total fee</dt><dd>' + idr(bt.feesIdr) + '</dd>' +
      '<dt>Total spread + slippage</dt><dd>' + idr(bt.spreadSlipIdr) + '</dd>' +
      '<dt>Total biaya</dt><dd><b>' + idr(bt.totalCostsIdr) + '</b></dd>' +
      '<dt>Porsi dari laba kotor</dt><dd><b>' + pctRaw(bt.costSharePct) + '</b></dd>' +
      '<dt>Rata-rata biaya/trade</dt><dd>' + idrShort(bt.totalCostsIdr / bt.trades) + '</dd>' +
      '<dt>Sumber fee</dt><dd><a href="https://indodax.com/api/pairs" target="_blank" rel="noopener">/api/pairs</a> taker 0,2% · halaman resmi help.indodax.com (diakses 7 Nov 2026)</dd>' +
      '</div>' +
      '<div class="table-wrap mt16"><table><thead><tr><th>Pair</th><th class="num">Spread (bps)</th><th class="num">Slippage (bps)</th><th class="num">Biaya/sisi (bps)</th></tr></thead><tbody>' + costRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Order referensi Rp25.000.000; 3 putaran snapshot. Slippage 0 berarti order tidak menembus level terbaik pada snapshot tersebut (tetap dibebani setengah spread).</p>') +
    '</div>' +

    '<h2 class="section-title">Uji ketahanan &amp; pemilihan parameter <small>in-sample, lalu dibekukan</small></h2>' +
    '<div class="card">' +
    '<p class="sub">Semua varian dijalankan pada data dan biaya yang sama. Kriteria pemilihan: profit factor &ge; 1,3, MDD &le; 25%, dan return wajar. Varian 1 jam ditolak karena fee drag. Parameter akhir dibekukan 5 Nov 2026 12.00 WIB.</p>' +
    '<div class="table-wrap"><table><thead><tr><th>Varian</th><th class="num">Return</th><th class="num">MDD</th><th class="num">PF</th><th class="num">Trade</th><th>Catatan</th></tr></thead><tbody>' + variantRows + '</tbody></table></div>' +
    '<p class="note tiny mt8">Catatan overfitting: pemilihan parameter memakai data in-sample yang sama dengan periode backtest. Karena itu hasil ini <b>tidak</b> diklaim sebagai out-of-sample. Forward test disiapkan untuk menguji aturan beku pada data baru. Penyusunan berlangsung 7 Nov 2026, sehingga eksplorasi parameter melihat data hingga tanggal itu; backtest final dipotong tepat sebelum freeze date.</p>' +
    '</div>' +

    '<div class="grid g2 mt24">' +
    card('5 trade terbaik', 'Bukan outliers yang mendominasi: total kontribusi 5 trade terbaik ' + pct(c.extra.top5Share, 1) + ' dari laba kotor.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th>Keluar</th><th class="num">P&amp;L</th><th class="num">%</th></tr></thead><tbody>' +
      c.topWins.map((t) => '<tr><td><span class="pair-tag">' + t.pair + '</span></td><td class="mono">' + dateShortWib(new Date(t.xt).toISOString()) + '</td><td class="num pos">' + idr(t.pnl) + '</td><td class="num pos">' + pct(t.pnlpct) + '</td></tr>').join('') +
      '</tbody></table></div>') +
    card('5 trade terburuk', 'Kerugian dipotong oleh trailing stop; tidak ada satu trade yang menghapus modal.',
      '<div class="table-wrap"><table><thead><tr><th>Pair</th><th>Keluar</th><th class="num">P&amp;L</th><th class="num">%</th></tr></thead><tbody>' +
      c.topLosses.map((t) => '<tr><td><span class="pair-tag">' + t.pair + '</span></td><td class="mono">' + dateShortWib(new Date(t.xt).toISOString()) + '</td><td class="num neg">' + idr(t.pnl) + '</td><td class="num neg">' + pct(t.pnlpct) + '</td></tr>').join('') +
      '</tbody></table></div>') +
    '</div>' +
    '</section>';
}

export function renderTrade(c) {
  const yearMap = new Map();
  for (const t of c.trades) {
    const y = new Date(t.xt + 7 * 3600 * 1000).getUTCFullYear();
    if (!yearMap.has(y)) yearMap.set(y, { y, trades: 0, wins: 0, pnl: 0 });
    const r = yearMap.get(y);
    r.trades++; if (t.pnl > 0) r.wins++; r.pnl += t.pnl;
  }
  const yearRows = [...yearMap.values()].sort((a, b) => a.y - b.y).map((r) =>
    '<tr><td>' + r.y + '</td><td class="num">' + r.trades + '</td><td class="num">' + pctRaw(r.wins / r.trades * 100) + '</td><td class="num ' + cls(r.pnl) + '">' + idr(r.pnl) + '</td></tr>').join('');

  return '' +
    '<section class="tab-panel" id="panel-trade" data-panel="trade">' +
    '<div class="grid g2">' +
    card('Statistik trade',
      'Trade tertutup saja; posisi terbuka di akhir backtest tidak ada.',
      '<div class="kv">' +
      '<dt>Total trade</dt><dd><b>' + num(c.bt.trades) + '</b> (' + num(c.bt.wins) + ' menang / ' + num(c.bt.losses) + ' rugi)</dd>' +
      '<dt>Win rate</dt><dd>' + pctRaw(c.bt.winRate) + '</dd>' +
      '<dt>Profit factor</dt><dd>' + num(c.bt.profitFactor, 2) + '</dd>' +
      '<dt>Avg win</dt><dd class="pos">' + pct(c.bt.avgWinPct) + ' · ' + idrShort(c.bt.avgWinIdr) + '</dd>' +
      '<dt>Avg loss</dt><dd class="neg">' + pct(c.bt.avgLossPct) + ' · ' + idrShort(c.bt.avgLossIdr) + '</dd>' +
      '<dt>Payoff ratio</dt><dd>' + num(c.extra.payoff, 2) + 'x</dd>' +
      '<dt>Expectancy</dt><dd>' + idrShort(c.extra.expectancy) + ' per trade</dd>' +
      '<dt>Trade terbaik / terburuk</dt><dd class="pos">' + idrShort(c.extra.bestTrade) + '</dd>' +
      '<dt></dt><dd class="neg">' + idrShort(c.extra.worstTrade) + '</dd>' +
      '</div>') +
    card('Trade per tahun',
      'Distribusi aktivitas dan hasil per tahun kalender (berdasarkan tanggal keluar).',
      '<div class="table-wrap"><table><thead><tr><th>Tahun</th><th class="num">Trade</th><th class="num">Win rate</th><th class="num">Net P&amp;L</th></tr></thead><tbody>' + yearRows + '</tbody></table></div>' +
      '<p class="note tiny mt8">Jumlah trade relatif stabil. Tahun 2023 dan 2026 hanya sebagian tahun.</p>') +
    '</div>' +

    '<h2 class="section-title">Log trade lengkap <small id="trades-count"></small></h2>' +
    '<div class="card">' +
    '<div class="controls">' +
    '<select id="f-pair" aria-label="Filter pair"><option value="ALL">Semua pair</option></select>' +
    '<select id="f-reason" aria-label="Filter alasan keluar"><option value="ALL">Semua alasan</option></select>' +
    '<input id="f-search" class="grow" type="search" placeholder="Cari pair / alasan...">' +
    '<button class="btn" id="f-reset" type="button">Reset</button>' +
    '<button class="btn primary" data-dl="trades" type="button">Unduh trades.csv</button>' +
    '<button class="btn" data-dl="equity" type="button">Unduh equity_daily.csv</button>' +
    '<button class="btn" data-dl="signalsExample" type="button">Contoh signals.csv</button>' +
    '</div>' +
    '<div class="table-wrap" style="max-height:640px">' +
    '<table><thead><tr><th>#</th><th>Pair</th><th>Masuk (WIB)</th><th>Keluar (WIB)</th><th class="num">Hari</th><th class="num">Harga masuk &rarr; keluar</th><th class="num">P&amp;L (Rp)</th><th class="num">P&amp;L %</th><th>Alasan</th><th class="num">Biaya</th><th class="num">Fill vs sinyal</th></tr></thead>' +
    '<tbody id="trades-body"></tbody></table>' +
    '<div class="pager" id="trades-pager"></div>' +
    '</div>' +
    '<p class="note tiny mt8">Harga fill backtest = open bar berikutnya setelah sinyal, disesuaikan setengah spread + slippage. Kolom &ldquo;fill vs sinyal&rdquo; menunjukkan selisih harga eksekusi terhadap close candle sinyal.</p>' +
    '</div>' +
    '</section>';
}
